# Switch Excalidraw Export to Line Elements

## Context

### Original Request
Switch Excalidraw export from `freedraw` elements to `line` elements to achieve more faithful rendering that matches the preview. Currently, freedraw elements look "rougher" due to perfect-freehand post-processing.

### Interview Summary
**Key Discussions**:
- Root cause identified: `freedraw` elements use perfect-freehand library (0.5 smoothing, 0.5 streamline, 0.6 thinning)
- `line` elements use RoughJS `linearPath()` which respects `roughness: 0`
- Research confirmed line elements render points more faithfully
- **Verification approach**: Playwright MCP first for manual comparison, then automate with Stagehand visual grader using LLM comparison

**Research Findings**:
- Line elements require: `polygon`, `startBinding`, `endBinding`, `startArrowhead`, `endArrowhead`
- Official svg-to-excalidraw uses legacy `"draw"` type (same issue)
- `roughness: 0` on line elements → architect mode, minimal modification
- Reference implementation: `packages/backend/lib/excalidraw-elements.ts:164-179`

### Metis Review
**Identified Gaps** (addressed):
- `polygon: boolean` property needed for line elements (use `false` for open paths)
- Point format `[number, number][]` compatible with line elements
- Keep `roundness: null` for sharp corners matching preview
- Closed paths (circles) may need detection for `polygon: true`

---

## Work Objectives

### Core Objective
Change Excalidraw element type from `freedraw` to `line` to eliminate perfect-freehand post-processing and achieve visual fidelity with preview. Verify with LLM-based image comparison that works in CI.

### Concrete Deliverables
- Modified `apps/web/src/lib/icon-library/svg-to-excalidraw.ts` with line element generation
- Visual comparison helper function in `tests/e2e/src/runner/visual-review.ts`
- Enhanced E2E test that compares preview vs Excalidraw render using LLM

### Definition of Done
- [x] Line element interface defined with required properties
- [x] Element generation changed from freedraw to line
- [x] Exported .excalidrawlib imports successfully into excalidraw.com
- [x] Visual comparison helper added to visual-review.ts
- [x] E2E test enhanced to compare preview vs Excalidraw via LLM
- [x] Playwright MCP manual verification confirms approach works
- [x] `bun run build` succeeds
- [x] `bun x ultracite check` passes

### Must Have
- `ExcalidrawLineElement` interface with all required properties
- `type: "line"` instead of `type: "freedraw"`
- `polygon: false` for icon paths
- `startBinding: null`, `endBinding: null`
- `startArrowhead: null`, `endArrowhead: null`
- `roughness: 0` (now affects stroke)
- `roundness: null` (sharp corners)
- `compareScreenshotsWithLLM()` function for image comparison (gateway-agnostic)
- E2E test that captures both preview and Excalidraw, then compares

### Must NOT Have (Guardrails)
- DO NOT change SVG parsing logic (lines 203-233)
- DO NOT modify point sampling algorithm (SAMPLE_STEP, etc.)
- DO NOT touch label/text element generation (lines 306-351)
- DO NOT add new style settings to StyleSettings interface
- DO NOT change the preview component
- DO NOT attempt to match stroke width extraction (keep hardcoded 2)

---

## Verification Strategy (MANDATORY)

### Test Decision
- **Infrastructure exists**: YES (E2E test `excalidraw-export-colors.ts`)
- **User wants tests**: Visual comparison with LLM grader (CI-ready)
- **Framework**: Stagehand + Playwright + OpenRouter vision model

### Verification Approach

**Phase 1: Playwright MCP Manual Verification**
- Use Playwright MCP to manually walk through the flow
- Capture preview screenshot
- Export to Excalidraw, capture Excalidraw screenshot
- Visually confirm the comparison approach works
- Document findings before automating

**Phase 2: Automated E2E with LLM Comparison**
- Add `compareScreenshotsWithLLM()` to visual-review.ts
- Enhance excalidraw-export-colors.ts to:
  1. Screenshot preview before export
  2. Screenshot Excalidraw after import
  3. Send both images to LLM for comparison
  4. Assert colors match AND visual fidelity matches

---

## Task Flow

```
Task 1 (interface) → Task 2 (element gen) → Task 3 (playwright manual verify) → Task 4 (comparison helper) → Task 5 (enhanced E2E)
```

## Parallelization

| Task | Depends On | Reason |
|------|------------|--------|
| 1 | - | Interface definition is standalone |
| 2 | 1 | Uses the new interface |
| 3 | 2 | Verifies the code change works before automating |
| 4 | 3 | Implements the helper based on manual findings |
| 5 | 4 | Uses the comparison helper |

---

## TODOs

- [x] 1. Add ExcalidrawLineElement interface

  **What to do**:
  - Add new interface `ExcalidrawLineElement` extending `ExcalidrawBaseElement`
  - Include required properties: `type: "line"`, `points`, `polygon`, binding properties, arrowhead properties
  - Update the `ExcalidrawElement` type union to include `ExcalidrawLineElement`
  - Keep `ExcalidrawFreedrawElement` for backwards compatibility (but don't use it)

  **Must NOT do**:
  - Do not remove ExcalidrawFreedrawElement interface (may be referenced elsewhere)
  - Do not change ExcalidrawBaseElement

  **Parallelizable**: NO (foundation for task 2)

  **References**:
  **Pattern References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:130-135` - current ExcalidrawFreedrawElement
  - `packages/backend/lib/excalidraw-elements.ts:164-179` - arrow element binding/arrowhead pattern
  
  **API/Type References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:102-128` - ExcalidrawBaseElement
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:150-152` - ExcalidrawElement union

  **Acceptance Criteria**:
  - [ ] `ExcalidrawLineElement` interface exists with: type, points, polygon, startBinding, endBinding, startArrowhead, endArrowhead
  - [ ] `ExcalidrawElement` union includes `ExcalidrawLineElement`
  - [ ] TypeScript compiles without errors
  - [ ] `bun x ultracite check` passes

  **Commit**: NO (groups with task 2)

---

- [x] 2. Change element generation from freedraw to line

  **What to do**:
  - In `pathData.map()` loop (around line 252-302), change element creation:
    - `type: "freedraw"` → `type: "line"`
    - Remove `simulatePressure: true`
    - Remove `pressures: []`
    - Add `polygon: false`
    - Add `startBinding: null`
    - Add `endBinding: null`
    - Add `startArrowhead: null`
    - Add `endArrowhead: null`
  - Keep `roughness: 0` (unchanged)
  - Keep `roundness: null` (unchanged)
  - Update return type to `ExcalidrawLineElement[]`

  **Must NOT do**:
  - Do not change the `extractColors` logic
  - Do not modify point calculation/transformation
  - Do not change the text element generation (lines 306-351)
  - Do not change grouping logic

  **Parallelizable**: NO (depends on task 1)

  **References**:
  **Pattern References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:252-302` - current freedraw element creation
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:284-285` - color extraction usage

  **Acceptance Criteria**:
  - [ ] Elements have `type: "line"` instead of `type: "freedraw"`
  - [ ] `simulatePressure` and `pressures` properties removed
  - [ ] `polygon: false` added
  - [ ] Binding and arrowhead properties added (all null)
  - [ ] `bun run build` succeeds
  - [ ] `bun x ultracite check` passes

  **Commit**: YES
  - Message: `fix(icon-library): use line elements for faithful Excalidraw rendering`
  - Files: `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`
  - Pre-commit: `bun run build && bun x ultracite check`

---

- [x] 3. Playwright MCP manual verification

  **What to do**:
  Use Playwright MCP to manually verify the fix works before automating:
  
  1. **Start dev server** (if not running): `bun run dev`
  2. **Navigate to Icon Library Generator**: Use Playwright MCP to go to the app
  3. **Create library and upload SVGs**: Upload the colorful fixture SVGs
  4. **Screenshot the preview**: Capture `preview-screenshot.png`
  5. **Export as .excalidrawlib**: Download the file
  6. **Navigate to excalidraw.com**: Go to Excalidraw
  7. **Import the library**: Use file chooser to import
  8. **Drag icon to canvas**: Place an icon on canvas
  9. **Screenshot Excalidraw**: Capture `excalidraw-screenshot.png`
  10. **Visual comparison**: Compare the two screenshots manually
  
  Document:
  - Do colors match? (red, blue, green preserved)
  - Do stroke shapes match? (no extra roughness)
  - Any visible differences?
  - Is the comparison approach viable for automation?

  **Must NOT do**:
  - Do not modify any code in this task
  - Do not skip any verification step

  **Parallelizable**: NO (depends on task 2)

  **References**:
  - Fixture files: `tests/e2e/fixtures/colorful-icons/`
  - Existing test flow: `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts`

  **Acceptance Criteria**:
  - [ ] Preview screenshot captured
  - [ ] Excalidraw screenshot captured
  - [ ] Manual comparison confirms: colors preserved
  - [ ] Manual comparison confirms: strokes match closely (not rougher)
  - [ ] Findings documented with evidence

  **Commit**: NO (verification only)

---

- [x] 4. Add compareScreenshotsWithLLM function

  **What to do**:
  Add a new function to `tests/e2e/src/runner/visual-review.ts`:
  
  ```typescript
  export interface ComparisonResult {
    summary: string;
    colorsMatch: boolean;
    visualFidelityMatch: boolean;
    differences: string[];
  }

  export async function compareScreenshotsWithLLM(params: {
    imagePath1: string;  // "expected" - preview
    imagePath2: string;  // "actual" - excalidraw
    label1?: string;     // e.g., "Preview"
    label2?: string;     // e.g., "Excalidraw"
    apiKey?: string;
    modelName?: string;
  }): Promise<ComparisonResult>
  ```
  
  Implementation:
  - Load both images as base64
  - Send to OpenRouter with comparison prompt:
    ```
    Compare these two images of the same icon.
    Image 1 ({label1}): The expected appearance
    Image 2 ({label2}): The actual render
    
    Evaluate:
    1. COLORS: Do the colors match? (same hues for strokes and fills)
    2. VISUAL FIDELITY: Do the shapes/strokes match? (similar line paths, no extra roughness or wobble)
    3. DIFFERENCES: List any notable differences
    
    Respond in JSON format:
    {
      "colorsMatch": true/false,
      "visualFidelityMatch": true/false,
      "differences": ["diff1", "diff2", ...]
    }
    ```
  - Parse JSON response and return ComparisonResult

  **Must NOT do**:
  - Do not modify existing `reviewScreenshotWithOpenRouter` function
  - Do not change export structure of visual-review.ts

  **Parallelizable**: NO (depends on task 3 findings)

  **References**:
  **Pattern References**:
  - `tests/e2e/src/runner/visual-review.ts:116-200` - existing reviewScreenshotWithOpenRouter implementation
  - `tests/e2e/src/runner/visual-review.ts:216-219` - buildDataUrl helper
  
  **API References**:
  - OpenRouter API: same endpoint as existing function
  - Multi-image messages: content array with multiple image_url objects

  **Acceptance Criteria**:
  - [ ] `ComparisonResult` interface exported
  - [ ] `compareScreenshotsWithLLM` function exported
  - [ ] Function accepts two image paths and labels
  - [ ] Returns structured comparison result (colorsMatch, visualFidelityMatch, differences)
  - [ ] Gracefully handles missing API key (returns skip message)
  - [ ] `bun x ultracite check` passes

  **Commit**: YES
  - Message: `feat(e2e): add compareScreenshotsWithLLM for visual comparison`
  - Files: `tests/e2e/src/runner/visual-review.ts`
  - Pre-commit: `bun x ultracite check`

---

- [x] 5. Enhance excalidraw-export-colors E2E test with comparison

  **What to do**:
  Update `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts`:
  
  1. **After uploading SVGs, screenshot the preview**:
     ```typescript
     // Screenshot preview before export
     const previewScreenshot = await captureScreenshot(
       playwrightPage,
       cfg,
       "preview-before-export",
       { selector: "[data-testid='icon-preview']" }  // or appropriate selector
     );
     ```
  
  2. **After importing to Excalidraw, screenshot the canvas with icon**:
     ```typescript
     // Drag an icon onto canvas first
     await stagehand.act("Drag one of the imported icons onto the canvas");
     await sleep(1000);
     
     // Screenshot Excalidraw canvas
     await playwrightPage.screenshot({ 
       path: path.join(cfg.screenshotsDir, "excalidraw-canvas.png"),
       fullPage: false 
     });
     ```
  
  3. **Use compareScreenshotsWithLLM**:
     ```typescript
     const comparison = await compareScreenshotsWithLLM({
       imagePath1: path.join(cfg.screenshotsDir, "preview-before-export.png"),
       imagePath2: path.join(cfg.screenshotsDir, "excalidraw-canvas.png"),
       label1: "Preview",
       label2: "Excalidraw",
       apiKey: cfg.openrouterApiKey,
       modelName: cfg.visionModelName,
     });
     
     if (!comparison.colorsMatch) {
       warnings.push("Colors do not match between preview and Excalidraw");
     }
     if (!comparison.visualFidelityMatch) {
       warnings.push(`Visual fidelity mismatch: ${comparison.differences.join(", ")}`);
     }
     ```
  
  4. **Update scenario header comment** to reflect new verification

  **Must NOT do**:
  - Do not remove existing color verification
  - Do not change the library creation/export flow
  - Do not break existing assertions

  **Parallelizable**: NO (depends on task 4)

  **References**:
  **Test References**:
  - `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts` - full test file
  - `tests/e2e/src/runner/stagehand.ts:96-170` - captureScreenshot function

  **Acceptance Criteria**:
  - [ ] Test captures preview screenshot before export
  - [ ] Test captures Excalidraw screenshot after import + drag to canvas
  - [ ] Test uses compareScreenshotsWithLLM
  - [ ] Test reports warnings if colors don't match
  - [ ] Test reports warnings if visual fidelity doesn't match
  - [ ] Test still runs in CI (graceful handling if API key missing)
  - [ ] `bun run --cwd tests/e2e test:local -- excalidraw-export-colors` passes

  **Commit**: YES
  - Message: `test(e2e): add visual comparison between preview and Excalidraw export`
  - Files: `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts`
  - Pre-commit: `bun run --cwd tests/e2e test:local -- excalidraw-export-colors`

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 2 | `fix(icon-library): use line elements for faithful Excalidraw rendering` | `svg-to-excalidraw.ts` | `bun run build` |
| 4 | `feat(e2e): add compareScreenshotsWithLLM for visual comparison` | `visual-review.ts` | `bun x ultracite check` |
| 5 | `test(e2e): add visual comparison between preview and Excalidraw export` | `excalidraw-export-colors.ts` | E2E test passes |

---

## Success Criteria

### Verification Commands
```bash
# Build succeeds
bun run build

# Linting passes  
bun x ultracite check

# E2E test passes with visual comparison
bun run --cwd tests/e2e test:local -- excalidraw-export-colors
```

### Visual Criteria
- Excalidraw render should closely match preview
- No additional "roughness" or "wobbliness" compared to preview
- Stroke edges should be clean and consistent
- Colors (red, blue, green) preserved in both preview and Excalidraw

### CI Readiness
- Test runs with or without OPENROUTER_API_KEY (graceful skip if missing)
- Screenshots saved as artifacts for manual review
- Comparison results logged to scenario summary

### Final Checklist
- [x] All "Must Have" present
- [x] All "Must NOT Have" absent
- [x] Visual fidelity improved (verified by LLM comparison)
- [x] No regressions in color preservation
- [x] Build and lint pass
- [x] E2E test passes locally
- [x] Test is CI-ready
