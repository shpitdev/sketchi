# PR #90 CR Fixes — Fault-Tolerant Telemetry

## TL;DR

> **Quick Summary**: Address 7 unresolved CodeRabbit comments on PR #90 by hardening `logEvent` to never throw, centralizing `logEventSafely`, replacing all bare `await logEvent()` calls across 7 files, and fixing minor nitpicks. Then typecheck/lint/build/test/push.
>
> **Deliverables**:
> - `observability.ts` hardened: full try/catch, JSON.stringify safety, non-2xx response handling
> - `logEventSafely` exported centrally, local duplicates removed
> - All 7+ action files converted to safe logging
> - 3 minor nitpicks addressed (misleading op name, inconsistent trace ID, .env.example comments)
> - Clean CI: typecheck + lint + build + backend tests passing
> - Push to remote, CR re-triggered
>
> **Estimated Effort**: Medium (2-3 hours)
> **Parallel Execution**: NO — sequential (each task depends on prior)
> **Critical Path**: Task 1 → Task 2 → Task 3 → Task 4 → Task 5 → Task 6 → Task 7

---

## Context

### Original Request
Address remaining CR comments on PR #90, fix/test/typecheck/build, push, and confirm CR passes.

### PR Details
- **PR**: #90 "Observability: trace propagation and structured logs"
- **Branch**: `89-observability-unified-tracinglogging-across-next-orpc-convex-openrouter`
- **CI Status**: All passing (CodeRabbit, Vercel, api-tests, convex-tests, e2e)
- **Reviewer**: CodeRabbit (3 rounds, 7 unresolved actionable comments)

### Metis Review Findings
- **Missing file**: `logging.ts` has 3 bare `await logEvent()` calls (line 96 is in a catch block — most dangerous callsite)
- **Existing pattern**: `logEventSafely` already exists locally in `diagramModifyElements.ts:112-116` and `intermediate-generator.ts:148-152` — centralize, don't reinvent
- **Root cause**: `JSON.stringify` (line 183) and `buildLogEvent` are outside `logEvent`'s existing try/catch — fix the root, not just the callers
- **Guardrail**: `convex/observability.ts:sentrySmokeTest` must keep `await logEvent()` — it's a diagnostic tool
- **Skip**: trace.ts dedup (Convex import resolution unknown), orpc/router.ts (apps/web, different surface), diagrams.ts traceId overwrite (intentional design)

---

## Work Objectives

### Core Objective
Make telemetry logging fault-tolerant so it never crashes business-critical Convex actions.

### Concrete Deliverables
- Hardened `logEvent` function (full try/catch around entire body)
- Centralized `logEventSafely` export from `observability.ts`
- 0 bare `await logEvent(` calls in action files (except `observability.ts` smoke test)
- Non-2xx response handling in `sendToTelemetryProxy`
- Minor nitpick fixes (op name, trace ID consistency, env comments)

### Definition of Done
- [x] `grep -rn "await logEvent(" packages/backend/convex/ --include="*.ts" | grep -v observability.ts | grep -v ".test.ts"` returns 0 lines
- [x] `grep -rn "await logEvent(" packages/backend/lib/ --include="*.ts"` returns 0 lines
- [x] `bun run check-types` exits 0
- [x] `bun x ultracite check` exits 0
- [x] `bun run build` exits 0
- [x] `cd packages/backend && bun run test` exits 0
- [x] `git push` succeeds
- [x] CodeRabbit re-review triggered

### Must Have
- `logEvent` body fully wrapped in try/catch (root fix)
- `logEventSafely` exported from `observability.ts`
- All action files use `logEventSafely` instead of bare `await logEvent()`
- `sendToTelemetryProxy` handles non-2xx responses
- `logging.ts` converted (the most dangerous callsite)

### Must NOT Have (Guardrails)
- DO NOT touch `convex/observability.ts:sentrySmokeTest` — diagnostic tool, must keep `await logEvent()`
- DO NOT fix `diagrams.ts` traceId overwrite (lines 173→200) — intentional design, not a bug
- DO NOT attempt `trace.ts` dedup (Convex import resolution not validated)
- DO NOT replace `crypto.randomUUID()` in files NOT being touched for logEvent changes
- DO NOT restructure `createLoggedAction` in `logging.ts` — only swap to `logEventSafely`
- DO NOT add new dependencies or change the telemetry architecture
- DO NOT create mocked endpoints or test doubles — use real function calls

---

## Verification Strategy

> **UNIVERSAL RULE: ZERO HUMAN INTERVENTION**
> ALL verification is executed by the agent using commands. No manual testing.

### Test Decision
- **Infrastructure exists**: YES (Vitest for backend)
- **Automated tests**: Tests-after (existing tests must pass; no new unit tests needed for try/catch wrappers)
- **Framework**: Vitest (packages/backend)

### Agent-Executed QA (MANDATORY for all tasks)

Every task verified via grep assertions and build commands. See per-task acceptance criteria.

---

## Execution Strategy

### Sequential Execution (Dependencies Require It)

```
Task 1: Harden observability.ts internals
    ↓
Task 2: Export logEventSafely from observability.ts
    ↓
Task 3: Convert all action files to logEventSafely
    ↓
Task 4: Remove local logEventSafely duplicates
    ↓
Task 5: Address minor nitpicks
    ↓
Task 6: Full verification suite (typecheck, lint, build, test)
    ↓
Task 7: Push and confirm CR
```

### Dependency Matrix

| Task | Depends On | Blocks |
|------|------------|--------|
| 1 | None | 2 |
| 2 | 1 | 3, 4 |
| 3 | 2 | 4, 6 |
| 4 | 2, 3 | 6 |
| 5 | None (can run after 2) | 6 |
| 6 | 3, 4, 5 | 7 |
| 7 | 6 | None |

---

## TODOs

- [x] 1. Harden `observability.ts` internals

  **What to do**:
  - Wrap the ENTIRE `logEvent` function body in a top-level try/catch (not just the Sentry/proxy path). Currently `JSON.stringify(normalized)` on ~line 183 and `buildLogEvent()` on ~line 181 are outside the existing try/catch. Move them inside so `logEvent` truly never throws.
  - In the top-level catch, `console.warn("logEvent failed silently:", error)` — don't swallow completely.
  - In `sendToTelemetryProxy`: after the `fetch()` call, check `response.ok`. If false, `console.warn("Telemetry proxy returned non-2xx:", response.status, traceId)`. Don't throw — telemetry is best-effort.
  - Wrap `JSON.stringify(normalized)` in its own try/catch. On failure, fall back to `console.log("[logEvent] Failed to serialize event", event?.op, event?.traceId)`.

  **Must NOT do**:
  - Don't change the function signature or return type
  - Don't remove the existing try/catch around the Sentry/proxy path — extend it
  - Don't touch `sentrySmokeTest` action in this file

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: [`git-master`]
    - `git-master`: Will need to commit changes
  - **Skills Evaluated but Omitted**:
    - `playwright`: No browser testing needed
    - `frontend-ui-ux`: Backend-only change

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential (first task)
  - **Blocks**: Task 2
  - **Blocked By**: None

  **References**:

  **Pattern References**:
  - `packages/backend/convex/lib/observability.ts:~170-210` — Current `logEvent` implementation; see the gap between `buildLogEvent`/`JSON.stringify` (unprotected) and the `sendToTelemetryProxy` try/catch (protected)
  - `packages/backend/convex/lib/observability.ts:~145-165` — `sendToTelemetryProxy` function; needs `response.ok` check added

  **Why Each Reference Matters**:
  - `observability.ts` `logEvent` body: You need to see exactly where the try/catch boundary currently sits to extend it correctly
  - `sendToTelemetryProxy`: You need to see the fetch call to add the response check without breaking the flow

  **Acceptance Criteria**:

  - [ ] `logEvent` function body is fully wrapped in try/catch (verify by reading the function)
  - [ ] `JSON.stringify` call has its own try/catch with fallback logging
  - [ ] `sendToTelemetryProxy` checks `response.ok` and warns on non-2xx
  - [ ] `bun run check-types` exits 0 (run from repo root)

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: logEvent body is fully try/catch wrapped
    Tool: Bash (grep)
    Steps:
      1. Read packages/backend/convex/lib/observability.ts
      2. Verify the logEvent function has a top-level try/catch wrapping buildLogEvent, JSON.stringify, and sendToTelemetryProxy
      3. Verify the catch block logs a warning (console.warn)
    Expected Result: Entire function body protected

  Scenario: sendToTelemetryProxy checks response.ok
    Tool: Bash (grep)
    Steps:
      1. grep "response.ok\|\.ok" packages/backend/convex/lib/observability.ts
      2. Assert: at least 1 match in sendToTelemetryProxy
    Expected Result: Non-2xx responses logged as warnings

  Scenario: Typecheck passes after changes
    Tool: Bash
    Steps:
      1. bun run check-types
    Expected Result: Exit code 0
  ```

  **Commit**: YES
  - Message: `fix(observability): harden logEvent to never throw`
  - Files: `packages/backend/convex/lib/observability.ts`
  - Pre-commit: `bun run check-types`

---

- [x] 2. Export centralized `logEventSafely` from `observability.ts`

  **What to do**:
  - Add an exported `logEventSafely` function in `observability.ts` that wraps `logEvent` as fire-and-forget.
  - Follow the existing pattern from `diagramModifyElements.ts:112-116`:
    ```typescript
    export function logEventSafely(...args: Parameters<typeof logEvent>): void {
      logEvent(...args).catch(() => {});
    }
    ```
  - Note: since Task 1 hardened `logEvent` to never throw, the `.catch(() => {})` is a belt-and-suspenders safety net. The key difference is that `logEventSafely` returns `void` (not `Promise`), so callers don't `await` it.

  **Must NOT do**:
  - Don't rename or unexport `logEvent` — other diagnostic tools may need the awaitable version
  - Don't change `logEvent`'s implementation (that was Task 1)

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: [`git-master`]

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential
  - **Blocks**: Tasks 3, 4
  - **Blocked By**: Task 1

  **References**:

  **Pattern References**:
  - `packages/backend/convex/diagramModifyElements.ts:112-116` — Existing local `logEventSafely` pattern to replicate
  - `packages/backend/lib/agents/intermediate-generator.ts:148-152` — Second local copy, same pattern

  **Why Each Reference Matters**:
  - These are the exact implementations to centralize — copy the pattern, export it, then later tasks will remove these locals

  **Acceptance Criteria**:

  - [ ] `grep -c "export function logEventSafely" packages/backend/convex/lib/observability.ts` returns 1
  - [ ] Function returns `void` (not `Promise<void>`)
  - [ ] `bun run check-types` exits 0

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: logEventSafely is exported
    Tool: Bash (grep)
    Steps:
      1. grep "export function logEventSafely" packages/backend/convex/lib/observability.ts
    Expected Result: Exactly 1 match

  Scenario: Typecheck passes
    Tool: Bash
    Steps:
      1. bun run check-types
    Expected Result: Exit code 0
  ```

  **Commit**: NO (groups with Task 1)

---

- [x] 3. Convert all action files from `await logEvent()` to `logEventSafely()`

  **What to do**:
  - Use `ast_grep_search` to find ALL `await logEvent(` calls across `packages/backend/`
  - Convert each to `logEventSafely(` (drop the `await`, call the safe wrapper)
  - **Files to convert** (7 files):
    1. `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts` — CR comment #3
    2. `packages/backend/convex/diagramModifyFromShareLink.ts` — CR comment #4
    3. `packages/backend/convex/diagrams.ts` — trace ID consistency
    4. `packages/backend/convex/export.ts` — CR comment #6
    5. `packages/backend/convex/diagramModifyElements.ts` — CR comment #11
    6. `packages/backend/convex/lib/logging.ts` — Metis finding (3 calls, line 96 in catch block is critical)
    7. `packages/backend/lib/agents/intermediate-generator.ts` — CR comment #7
  - Update imports in each file: add `logEventSafely` to the import from `./lib/observability` (or relative path)
  - **EXCEPTION**: Do NOT convert `packages/backend/convex/observability.ts` — the `sentrySmokeTest` action must keep `await logEvent()` for diagnostics

  **Must NOT do**:
  - Don't touch `observability.ts` sentrySmokeTest
  - Don't restructure `createLoggedAction` in `logging.ts` — only swap the logEvent calls
  - Don't change any business logic, return values, or error handling flow
  - Don't remove `logEvent` from imports if other usages exist in the same file

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: [`git-master`]
    - `git-master`: Multiple files to commit
  - **Skills Evaluated but Omitted**:
    - `playwright`: No browser work

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential
  - **Blocks**: Tasks 4, 6
  - **Blocked By**: Task 2

  **References**:

  **Pattern References**:
  - `packages/backend/convex/diagramModifyElements.ts:112-116` — Shows the existing local `logEventSafely` and where it's used vs bare `await logEvent()`
  - `packages/backend/convex/lib/logging.ts:72,83,96` — Three `await logEvent()` calls; line 96 is inside a catch block (most dangerous — if it throws, original error is swallowed)

  **API/Type References**:
  - `packages/backend/convex/lib/observability.ts` — Source of `logEvent` and `logEventSafely` exports

  **Why Each Reference Matters**:
  - `diagramModifyElements.ts` shows the mixed state (some safe, most bare) — convert ALL bare calls
  - `logging.ts:96` is the single most dangerous callsite — in a catch block, a throw here masks the real error

  **Acceptance Criteria**:

  - [ ] `grep -rn "await logEvent(" packages/backend/convex/ --include="*.ts" | grep -v observability.ts | grep -v ".test.ts"` returns 0 lines
  - [ ] `grep -rn "await logEvent(" packages/backend/lib/ --include="*.ts"` returns 0 lines
  - [ ] Every converted file imports `logEventSafely` from the correct path
  - [ ] `bun run check-types` exits 0

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: No bare await logEvent in action files
    Tool: Bash (grep)
    Steps:
      1. grep -rn "await logEvent(" packages/backend/convex/ --include="*.ts" | grep -v observability.ts | grep -v ".test.ts"
      2. Assert: 0 lines returned
    Expected Result: All action files use logEventSafely

  Scenario: No bare await logEvent in lib/agents
    Tool: Bash (grep)
    Steps:
      1. grep -rn "await logEvent(" packages/backend/lib/ --include="*.ts"
      2. Assert: 0 lines returned
    Expected Result: Agent files also converted

  Scenario: sentrySmokeTest still uses await logEvent
    Tool: Bash (grep)
    Steps:
      1. grep -n "await logEvent(" packages/backend/convex/observability.ts
      2. Assert: at least 1 match (the smoke test)
    Expected Result: Diagnostic tool preserved

  Scenario: Typecheck passes
    Tool: Bash
    Steps:
      1. bun run check-types
    Expected Result: Exit code 0
  ```

  **Commit**: YES
  - Message: `fix(observability): make all telemetry logging fault-tolerant`
  - Files: All 7 converted files + `observability.ts` (logEventSafely export)
  - Pre-commit: `bun run check-types`

---

- [x] 4. Remove local `logEventSafely` duplicates

  **What to do**:
  - Remove the local `logEventSafely` function definition from:
    1. `packages/backend/convex/diagramModifyElements.ts:112-116`
    2. `packages/backend/lib/agents/intermediate-generator.ts:148-152`
  - These files should already import `logEventSafely` from `observability.ts` (done in Task 3)
  - Verify no other local duplicates exist

  **Must NOT do**:
  - Don't remove the import — only the local function definition
  - Don't change any callsites (already done in Task 3)

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: [`git-master`]

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential
  - **Blocks**: Task 6
  - **Blocked By**: Tasks 2, 3

  **References**:

  **Pattern References**:
  - `packages/backend/convex/diagramModifyElements.ts:112-116` — Local `logEventSafely` to remove
  - `packages/backend/lib/agents/intermediate-generator.ts:148-152` — Local `logEventSafely` to remove

  **Acceptance Criteria**:

  - [ ] `grep -rn "function logEventSafely" packages/backend/ --include="*.ts"` returns exactly 1 result (in `observability.ts`)
  - [ ] `bun run check-types` exits 0

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: Exactly one logEventSafely definition
    Tool: Bash (grep)
    Steps:
      1. grep -rn "function logEventSafely" packages/backend/ --include="*.ts"
      2. Assert: exactly 1 line, in observability.ts
    Expected Result: No duplicates

  Scenario: Typecheck passes
    Tool: Bash
    Steps:
      1. bun run check-types
    Expected Result: Exit code 0
  ```

  **Commit**: NO (groups with Task 3)

---

- [x] 5. Address minor nitpicks

  **What to do**:
  - **5a: Fix misleading op name in `diagrams.ts`**
    - Find the early return on failure that uses `pipeline.complete` as the op name
    - Change to `pipeline.failed` or `pipeline.aborted` — it's not a successful completion
    - Add a brief clarifying comment about the traceId overwrite at ~line 200 (don't fix it — it's intentional; just comment explaining why)

  - **5b: Consistent trace ID in `diagramModifyElements.ts`**
    - Replace any `crypto.randomUUID()` used for trace IDs with `createTraceId()` from the existing trace module
    - This file is already being touched in Tasks 3/4, so no extra blast radius

  - **5c: `.env.example` inline comments**
    - Add brief inline comments for new env vars added in this PR (telemetry-related vars)
    - One-liner comments only. No reformatting existing vars.

  **Must NOT do**:
  - Don't fix the traceId overwrite in `diagrams.ts` — just add a comment
  - Don't touch `crypto.randomUUID()` in files NOT already modified in this plan
  - Don't reformat `.env.example` beyond adding comments for new vars

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: [`git-master`]

  **Parallelization**:
  - **Can Run In Parallel**: NO (technically could parallel with 3/4 but same files)
  - **Parallel Group**: Sequential (after Task 2)
  - **Blocks**: Task 6
  - **Blocked By**: Task 2

  **References**:

  **Pattern References**:
  - `packages/backend/convex/diagrams.ts:~173-200` — traceId assignment and the early return with misleading `pipeline.complete` op
  - `packages/backend/convex/diagramModifyElements.ts` — `crypto.randomUUID()` callsites to replace with `createTraceId()`
  - `packages/backend/convex/lib/trace.ts` — source of `createTraceId()` function
  - `apps/web/.env.example` — needs inline comments for new telemetry env vars

  **Acceptance Criteria**:

  - [ ] No `pipeline.complete` op used for failure/abort paths in `diagrams.ts`
  - [ ] Comment explaining traceId overwrite exists near line 200 of `diagrams.ts`
  - [ ] No bare `crypto.randomUUID()` for trace IDs in `diagramModifyElements.ts` (use `createTraceId()`)
  - [ ] `.env.example` has inline comments for telemetry-related env vars
  - [ ] `bun run check-types` exits 0

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: No misleading pipeline.complete on failure path
    Tool: Bash (grep)
    Steps:
      1. Read packages/backend/convex/diagrams.ts
      2. Find early return failure path
      3. Verify op is not "pipeline.complete" (should be "pipeline.failed" or similar)
    Expected Result: Accurate op name for failure case

  Scenario: createTraceId used consistently
    Tool: Bash (grep)
    Steps:
      1. grep "crypto.randomUUID" packages/backend/convex/diagramModifyElements.ts
      2. Assert: 0 matches (all replaced with createTraceId)
    Expected Result: Consistent trace ID generation

  Scenario: Typecheck passes
    Tool: Bash
    Steps:
      1. bun run check-types
    Expected Result: Exit code 0
  ```

  **Commit**: YES
  - Message: `fix(observability): address CR nitpicks (op names, trace IDs, env docs)`
  - Files: `diagrams.ts`, `diagramModifyElements.ts`, `.env.example`
  - Pre-commit: `bun run check-types`

---

- [x] 6. Full verification suite

  **What to do**:
  - Run the complete verification pipeline in order:
    1. `bun x ultracite fix` — auto-fix formatting
    2. `bun x ultracite check` — verify lint passes
    3. `bun run check-types` — TypeScript type checking
    4. `bun run build` — full build (includes Convex function bundling)
    5. `cd packages/backend && bun run test` — backend unit tests
  - Fix any failures that arise. Common issues:
    - Import ordering (ultracite will fix)
    - Unused imports after removing local `logEventSafely` (remove them)
    - Type errors from signature mismatches (fix them)
  - If `bun run build` fails on Convex bundling, check that all imports resolve correctly in the Convex function context

  **Must NOT do**:
  - Don't skip any verification step
  - Don't ignore warnings — fix them
  - Don't create new test files (existing tests are sufficient for this change)

  **Recommended Agent Profile**:
  - **Category**: `unspecified-low`
  - **Skills**: [`git-master`]

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential (depends on all prior tasks)
  - **Blocks**: Task 7
  - **Blocked By**: Tasks 3, 4, 5

  **References**:

  **Documentation References**:
  - `package.json` root — `check-types` and `build` scripts
  - `turbo.json` — build pipeline configuration
  - `packages/backend/vitest.config.ts` — test configuration

  **Acceptance Criteria**:

  - [ ] `bun x ultracite check` exits 0
  - [ ] `bun run check-types` exits 0
  - [ ] `bun run build` exits 0
  - [ ] `cd packages/backend && bun run test` exits 0 (all tests pass)

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: Full lint check passes
    Tool: Bash
    Steps:
      1. bun x ultracite fix (auto-fix first)
      2. bun x ultracite check
    Expected Result: Exit code 0, no errors

  Scenario: Type checking passes
    Tool: Bash
    Steps:
      1. bun run check-types
    Expected Result: Exit code 0

  Scenario: Build succeeds
    Tool: Bash
    Steps:
      1. bun run build
    Expected Result: Exit code 0, no Convex bundling errors

  Scenario: Backend tests pass
    Tool: Bash
    Preconditions: Build succeeded
    Steps:
      1. cd packages/backend && bun run test
    Expected Result: All tests pass, exit code 0
  ```

  **Commit**: YES (if ultracite fixed anything)
  - Message: `style: format and lint fixes`
  - Files: Any files auto-fixed by ultracite
  - Pre-commit: `bun x ultracite check`

---

- [x] 7. Push and confirm CR

  **What to do**:
  - `git push` to the remote branch
  - Wait for CodeRabbit to re-review (typically 2-5 minutes)
  - Check CR status: `gh pr checks 90`
  - Review new comments (if any): `gh api repos/anand-testcompare/sketchi/pulls/90/comments --jq '.[].body' | tail -20`
  - If CodeRabbit raises new issues, assess and fix if trivial
  - Confirm all CI checks pass

  **Must NOT do**:
  - Don't force push — regular push only
  - Don't merge the PR — just push and verify
  - Don't add Claude/Anthropic branding to commits

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: [`git-master`]

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Final task
  - **Blocks**: None
  - **Blocked By**: Task 6

  **References**:

  **Documentation References**:
  - PR URL: https://github.com/anand-testcompare/sketchi/pull/90

  **Acceptance Criteria**:

  - [ ] `git push` succeeds (no conflicts)
  - [ ] `gh pr checks 90` shows all checks passing
  - [ ] CodeRabbit review triggered on new commits
  - [ ] No new critical/major comments from CodeRabbit

  **Agent-Executed QA Scenarios**:

  ```
  Scenario: Push succeeds
    Tool: Bash
    Steps:
      1. git push
    Expected Result: Push accepted, no errors

  Scenario: CI checks pass
    Tool: Bash
    Steps:
      1. Wait 60 seconds for checks to start
      2. gh pr checks 90
      3. If any pending, wait and re-check (up to 5 minutes)
    Expected Result: All checks pass

  Scenario: CR re-review shows improvement
    Tool: Bash
    Steps:
      1. Wait for CodeRabbit to post (2-5 min)
      2. gh api repos/anand-testcompare/sketchi/pulls/90/reviews --jq '.[-1]'
      3. Check latest review for reduced actionable comments
    Expected Result: Fewer or zero unresolved actionable comments
  ```

  **Commit**: NO (just pushing)

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1+2 | `fix(observability): harden logEvent to never throw` | `observability.ts` | `bun run check-types` |
| 3+4 | `fix(observability): make all telemetry logging fault-tolerant` | 7 action files + observability.ts | `bun run check-types` |
| 5 | `fix(observability): address CR nitpicks (op names, trace IDs, env docs)` | `diagrams.ts`, `diagramModifyElements.ts`, `.env.example` | `bun run check-types` |
| 6 | `style: format and lint fixes` (if needed) | Auto-fixed files | `bun x ultracite check` |

---

## Success Criteria

### Verification Commands
```bash
# Zero bare await logEvent in action files
grep -rn "await logEvent(" packages/backend/convex/ --include="*.ts" | grep -v observability.ts | grep -v ".test.ts"
# Expected: 0 lines

# Zero bare await logEvent in lib/agents
grep -rn "await logEvent(" packages/backend/lib/ --include="*.ts"
# Expected: 0 lines

# Exactly one logEventSafely definition
grep -rn "function logEventSafely" packages/backend/ --include="*.ts" | wc -l
# Expected: 1

# Full verification
bun x ultracite check    # Expected: exit 0
bun run check-types      # Expected: exit 0
bun run build            # Expected: exit 0
cd packages/backend && bun run test  # Expected: all pass

# CI status
gh pr checks 90          # Expected: all pass
```

### Final Checklist
- [x] All "Must Have" present
- [x] All "Must NOT Have" absent (especially: sentrySmokeTest untouched, no trace.ts dedup)
- [x] All 7 unresolved CR comments addressed
- [x] All CI checks pass
- [x] Push succeeded
- [x] CodeRabbit re-review triggered
