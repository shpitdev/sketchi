# CodeRabbit Review Fixes (Issue #22)

## Context

### Original Request
Fix 7 categories of issues identified by CodeRabbit in PR #19 (Icon Library Generator). Issues range from high to low priority affecting storage safety, SSR compatibility, accessibility, state management, security, and data integrity.

### Interview Summary
**Key Discussions**:
- Schema mismatch: User confirmed frontend settings (bowing, randomize, pencilFilter, showLabel, labelSize) should remain **session-only** for now. Persistence deferred until login feature is added.

**Research Findings**:
- Backend schema has 7 fields (strokeColor, backgroundColor, strokeWidth, strokeStyle, fillStyle, roughness, opacity)
- Frontend StyleSettings has 7 fields (fillStyle, roughness, bowing, randomize, pencilFilter, showLabel, labelSize)
- Only fillStyle and roughness overlap - current save/load code tries to bridge incompatible schemas
- validateSvgText exists at `apps/web/src/lib/icon-library/svg-validate.ts`
- sanitizeFileName exists but lacks deduplication

### Metis Review
**Identified Gaps** (addressed):
- Export failure mode: Default to skip problematic icon, not abort entire export
- Storage verification: Use Convex dashboard to check storage after delete tests
- Test coverage: Not adding tests (per AGENTS.md preference for API/E2E over unit tests)

---

## Work Objectives

### Core Objective
Fix 7 categories of CodeRabbit-identified issues to improve code safety, accessibility, and data integrity.

### Concrete Deliverables
- Fixed delete order in `packages/backend/convex/iconLibraries.ts`
- SSR guard in `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`
- Accessibility fixes in `library-card.tsx` and `page.tsx`
- State management fix in `page.tsx`
- SVG validation in `export-button.tsx`
- Reorder validation fix in `iconLibraries.ts`
- ZIP filename deduplication in `export-button.tsx`
- Clarified schema handling with session-only documentation

### Definition of Done
- [x] `bun run build` succeeds without SSR errors
- [x] `bun x ultracite check` passes (pre-existing errors unrelated to changes)
- [x] All 7 issue categories addressed per GitHub issue #22

### Must Have
- Storage delete before DB delete in deleteIcon
- SSR guard on DOMParser usage
- Descriptive alt text on preview images
- aria-label on library name input
- isSaving included in isBusy check
- validateSvgText call before SVG processing in export
- Split validation from patching in reorderIcons
- Filename deduplication in ZIP export

### Must NOT Have (Guardrails)
- No new fields added to backend schema (deferred to login feature)
- No refactoring of validateSvgText duplication (separate concern)
- No new tests (not requested)
- No changes to upload flow when fixing export validation
- No standardization of error handling beyond specific fixes
- No accessibility fixes beyond the 2 specified issues

---

## Verification Strategy

### Test Decision
- **Infrastructure exists**: YES (vitest in backend, playwright scripts)
- **User wants tests**: NO (per discussion)
- **Framework**: Manual verification

### Manual QA Approach
Each TODO includes specific verification procedures appropriate to the change type.

---

## Task Flow

```
Task 1 (SSR) ──┐
Task 2 (a11y) ─┼──→ Task 6 (isBusy) ──→ Task 8 (Schema cleanup)
Task 3 (a11y) ─┘
Task 4 (Security) ─────────────────────→ Task 7 (ZIP dedup)
Task 5 (Delete order) ─────────────────→ Task 9 (Reorder)
```

## Parallelization

| Group | Tasks | Reason |
|-------|-------|--------|
| A | 1, 2, 3 | Independent frontend files |
| B | 4, 5 | Independent (export vs backend) |
| C | 6, 7, 8, 9 | Sequential dependencies or same files |

| Task | Depends On | Reason |
|------|------------|--------|
| 6 | 2, 3 | Same file (page.tsx) |
| 8 | 6 | Same file (page.tsx) |

---

## TODOs

- [x] 1. Add SSR guard to svgToExcalidrawElements

  **What to do**:
  - Add browser environment check at the start of `svgToExcalidrawElements` function
  - Throw descriptive error if called in SSR context
  - Place guard before any DOMParser usage (line 178)

  **Must NOT do**:
  - Do not change function signature
  - Do not add polyfills

  **Parallelizable**: YES (with 2, 3, 4, 5)

  **References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:173-185` - Function entry point and DOMParser usage
  - GitHub issue #22 section 3 - Exact fix pattern provided

  **Acceptance Criteria**:
  - [ ] Guard added: `if (typeof window === "undefined") { throw new Error(...) }`
  - [ ] `bun run build` completes without DOMParser errors
  - [ ] Verify: `grep -n "typeof window" apps/web/src/lib/icon-library/svg-to-excalidraw.ts` shows guard

  **Commit**: YES
  - Message: `fix(web): add SSR guard to svgToExcalidrawElements`
  - Files: `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`

---

- [x] 2. Add descriptive alt text to preview images

  **What to do**:
  - In library-card.tsx, replace `alt=""` with descriptive text
  - Format: `alt={library.name} preview ${idx + 1}` or similar
  - Include library name for context

  **Must NOT do**:
  - Do not change image sizing or layout
  - Do not add new props

  **Parallelizable**: YES (with 1, 3, 4, 5)

  **References**:
  - `apps/web/src/components/icon-library/library-card.tsx:43-50` - Image component with empty alt
  - GitHub issue #22 section 4a - Fix description

  **Acceptance Criteria**:
  - [ ] All preview images have descriptive alt text
  - [ ] Alt text includes library name and position indicator
  - [ ] Verify: `grep -n 'alt=' apps/web/src/components/icon-library/library-card.tsx` shows descriptive text

  **Commit**: YES
  - Message: `fix(web): add descriptive alt text to library preview images`
  - Files: `apps/web/src/components/icon-library/library-card.tsx`

---

- [x] 3. Add aria-label to library name input

  **What to do**:
  - Add `aria-label="Library name"` to the Input component at line 223-226
  - Alternatively, add a visible `<label>` element (aria-label is simpler)

  **Must NOT do**:
  - Do not change input behavior
  - Do not add validation

  **Parallelizable**: YES (with 1, 2, 4, 5)

  **References**:
  - `apps/web/src/app/library-generator/[id]/page.tsx:223-226` - Input without label
  - GitHub issue #22 section 4b - Fix description

  **Acceptance Criteria**:
  - [ ] Input has `aria-label="Library name"` attribute
  - [ ] Verify: `grep -n 'aria-label' apps/web/src/app/library-generator/[id]/page.tsx` shows library name input

  **Commit**: NO (groups with 6, 8)

---

- [x] 4. Add SVG validation to export flow

  **What to do**:
  - Import `validateSvgText` from `@/lib/icon-library/svg-validate`
  - Call `validateSvgText(svgText)` after fetching SVG, before `svgToExcalidrawElements`
  - Wrap in try-catch: if validation fails, log warning and skip that icon (don't abort export)
  - Apply to both `handleExportExcalidraw` (~L139-152) and `handleExportZip` (~L204-215)

  **Must NOT do**:
  - Do not abort entire export on single icon failure
  - Do not modify validateSvgText function
  - Do not change upload validation

  **Parallelizable**: YES (with 1, 2, 3, 5)

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:139-152` - Excalidraw export loop
  - `apps/web/src/components/icon-library/export-button.tsx:204-215` - ZIP export loop
  - `apps/web/src/lib/icon-library/svg-validate.ts:10` - validateSvgText function
  - `apps/web/src/app/library-generator/[id]/page.tsx:18,120` - Example import and usage

  **Acceptance Criteria**:
  - [ ] validateSvgText imported and called in both export functions
  - [ ] Invalid SVGs are skipped with console warning, not crash
  - [ ] Verify: `grep -n 'validateSvgText' apps/web/src/components/icon-library/export-button.tsx` shows usage

  **Commit**: YES
  - Message: `fix(web): validate SVG before export processing`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`

---

- [x] 5. Fix delete order in deleteIcon mutation

  **What to do**:
  - Swap order: delete storage FIRST, then DB record
  - If storage delete fails, don't delete DB (fail fast)
  - Current order (L240-241): db.delete, then storage.delete
  - New order: storage.delete, then db.delete

  **Must NOT do**:
  - Do not add transaction/rollback complexity
  - Do not change function signature
  - Do not add cleanup jobs

  **Parallelizable**: YES (with 1, 2, 3, 4)

  **References**:
  - `packages/backend/convex/iconLibraries.ts:232-243` - deleteIcon mutation
  - GitHub issue #22 section 2 - Fix description

  **Acceptance Criteria**:
  - [ ] `ctx.storage.delete()` called BEFORE `ctx.db.delete()`
  - [ ] Verify: Read iconLibraries.ts and confirm order
  - [ ] Manual test: Delete icon via UI, verify no orphaned storage (check Convex dashboard)

  **Commit**: YES
  - Message: `fix(backend): delete storage before DB record in deleteIcon`
  - Files: `packages/backend/convex/iconLibraries.ts`

---

- [x] 6. Include isSaving in isBusy check

  **What to do**:
  - Change line 269 from `isBusy={isUploading}` to `isBusy={isUploading || isSaving}`
  - This prevents delete/move operations during save

  **Must NOT do**:
  - Do not rename isBusy prop
  - Do not add new states

  **Parallelizable**: NO (depends on 3 being in same file)

  **References**:
  - `apps/web/src/app/library-generator/[id]/page.tsx:269` - isBusy prop
  - `apps/web/src/app/library-generator/[id]/page.tsx:77` - isSaving state definition
  - GitHub issue #22 section 5 - Fix description

  **Acceptance Criteria**:
  - [ ] isBusy includes both isUploading and isSaving
  - [ ] Manual test: Click save, verify delete buttons are disabled during save
  - [ ] Verify: `grep -n 'isBusy=' apps/web/src/app/library-generator/[id]/page.tsx` shows both states

  **Commit**: NO (groups with 3, 8)

---

- [x] 7. Add ZIP filename deduplication

  **What to do**:
  - Track used filenames in a Set or Map
  - When collision detected, append `-1`, `-2`, etc.
  - Apply to both `handleExportZip` (~L213-214) and PNG export if applicable (~L261-262)
  - Example: `icon.svg`, `icon-1.svg`, `icon-2.svg`

  **Must NOT do**:
  - Do not change sanitizeFileName function
  - Do not limit deduplication count
  - Do not change ZIP library

  **Parallelizable**: NO (depends on 4 being in same file)

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:36-40` - sanitizeFileName function
  - `apps/web/src/components/icon-library/export-button.tsx:213-214` - ZIP file naming
  - `apps/web/src/components/icon-library/export-button.tsx:261-262` - PNG export naming
  - GitHub issue #22 section 7b - Fix description

  **Acceptance Criteria**:
  - [ ] Deduplication logic added: track names, append counter on collision
  - [ ] Test: Export library with icons having similar names (e.g., "icon 1", "icon-1")
  - [ ] Verify all icons present in ZIP with unique names

  **Commit**: YES
  - Message: `fix(web): deduplicate ZIP export filenames`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`

---

- [x] 8. Clean up schema handling documentation

  **What to do**:
  - Add comment in page.tsx useEffect (L53-71) explaining session-only behavior
  - Make default values explicit and documented
  - Remove any misleading code that suggests persistence
  - Comment format: `// Session-only settings - persistence deferred until user auth is implemented`

  **Must NOT do**:
  - Do not add new fields to backend schema
  - Do not change save behavior
  - Do not add persistence logic

  **Parallelizable**: NO (depends on 3, 6 in same file)

  **References**:
  - `apps/web/src/app/library-generator/[id]/page.tsx:53-71` - useEffect with hardcoded values
  - `apps/web/src/app/library-generator/[id]/page.tsx:83-110` - handleSave function
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:32-40` - StyleSettings interface
  - GitHub issue #22 section 1 - Context

  **Acceptance Criteria**:
  - [ ] Comment added explaining session-only behavior
  - [ ] Default values clearly documented
  - [ ] Verify: Read page.tsx and confirm documentation is clear

  **Commit**: YES
  - Message: `docs(web): clarify session-only style settings behavior`
  - Files: `apps/web/src/app/library-generator/[id]/page.tsx`

---

- [x] 9. Fix reorderIcons validation order

  **What to do**:
  - Split into two phases:
    1. First, validate ALL icons exist and belong to library
    2. Then, apply ALL patches
  - If any validation fails, throw before any patches applied
  - Remove Promise.all around validate+patch combined

  **Must NOT do**:
  - Do not change function signature
  - Do not add transaction support
  - Do not change error messages

  **Parallelizable**: NO (same file as 5)

  **References**:
  - `packages/backend/convex/iconLibraries.ts:245-266` - reorderIcons mutation
  - GitHub issue #22 section 7a - Fix description

  **Acceptance Criteria**:
  - [ ] Validation loop runs BEFORE patch loop
  - [ ] If validation fails, no patches are applied
  - [ ] Manual test: Attempt reorder with invalid ID, verify others unchanged
  - [ ] Verify: Read iconLibraries.ts and confirm two-phase approach

  **Commit**: YES
  - Message: `fix(backend): validate all icons before reordering`
  - Files: `packages/backend/convex/iconLibraries.ts`

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1 | `fix(web): add SSR guard to svgToExcalidrawElements` | svg-to-excalidraw.ts | `bun run build` |
| 2 | `fix(web): add descriptive alt text to library preview images` | library-card.tsx | ultracite check |
| 4 | `fix(web): validate SVG before export processing` | export-button.tsx | ultracite check |
| 5 | `fix(backend): delete storage before DB record in deleteIcon` | iconLibraries.ts | ultracite check |
| 7 | `fix(web): deduplicate ZIP export filenames` | export-button.tsx | ultracite check |
| 3,6,8 | `fix(web): accessibility and state management in library editor` | page.tsx | ultracite check |
| 9 | `fix(backend): validate all icons before reordering` | iconLibraries.ts | ultracite check |

---

## Success Criteria

### Verification Commands
```bash
bun run build          # Expected: success, no SSR errors
bun x ultracite check  # Expected: no new errors
```

### Final Checklist
- [x] All 7 CodeRabbit issue categories addressed
- [x] No backend schema changes (session-only approach confirmed)
- [x] Build passes
- [x] Linting passes (pre-existing errors unrelated to changes)
- [x] PR references GitHub issue #22 (PR #29 created)
