# Fix Excalidraw Export Colors & Add E2E Verification

## Context

### Original Request
Fix the Excalidraw export (.excalidrawlib) so that colors from original SVGs are preserved instead of everything being black. Add E2E test to verify the fix works by importing into Excalidraw and visually verifying colors.

### Interview Summary
**Key Discussions**:
- Root cause identified: Hardcoded `stroke: "#000000"` in svg2roughjs config and `strokeColor: "#000000"` in svg-to-excalidraw.ts
- Approach B selected: Feed svg2roughjs output (sketchy SVG) into Excalidraw converter for WYSIWYG consistency
- Testing via Stagehand E2E with Playwright file chooser API to import into excalidraw.com

**Research Findings**:
- svg2roughjs: roughConfig acts as defaults; removing `stroke` preserves original colors
- Excalidraw testing: Playwright `page.waitForEvent('filechooser')` + `setFiles()` enables programmatic upload
- Color extraction: Read `stroke`, `fill`, `stroke-opacity`, `fill-opacity` from SVG elements

### Metis Review
**Identified Gaps** (addressed):
- Fill colors scope: INCLUDE - extract both stroke and fill
- Text labels: EXCLUDE - keep black (generated labels, not from source)
- Sketchy ZIP export: INCLUDE - uses same roughConfig, fix together
- SVG fallback: Black default when element has no stroke/fill attribute
- Roughness value: Set to 0 (sketchiness baked into paths from svg2roughjs)

---

## Work Objectives

### Core Objective
Preserve original SVG colors in Excalidraw exports by removing hardcoded black and extracting colors from SVG elements, with E2E verification via Excalidraw import.

### Concrete Deliverables
- Modified `apps/web/src/components/icon-library/sketchy-icon-preview.tsx` - remove hardcoded stroke
- Modified `apps/web/src/components/icon-library/export-button.tsx` - remove hardcoded stroke, change Excalidraw export to use sketchy SVG
- Modified `apps/web/src/lib/icon-library/svg-to-excalidraw.ts` - add color extraction from SVG input
- New `tests/e2e/fixtures/colorful-icons/` - SVG fixtures with known colors
- New `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts` - E2E verification test

### Definition of Done
- [x] Preview displays icons with original colors (not all black)
- [x] Excalidraw export preserves stroke colors from original SVGs
- [x] Excalidraw export preserves fill/background colors from original SVGs
- [x] Sketchy ZIP export preserves original colors
- [x] E2E test passes: imports into excalidraw.com and visual review confirms colors
- [x] `bun run build` succeeds
- [x] `bun x ultracite check` passes

### Must Have
- Stroke color extraction from SVG elements
- Fill/background color extraction from SVG elements
- Fallback to black when SVG element has no explicit color
- E2E test with colorful SVG fixtures (red, blue, green minimum)
- Visual AI verification prompt that specifically checks for colors

### Must NOT Have (Guardrails)
- DO NOT change `handleExportZip` behavior (original SVG export stays as-is)
- DO NOT extract colors for text labels (keep generated labels black)
- DO NOT change strokeWidth extraction (keep at 2)
- DO NOT support gradient strokes/fills (out of scope - use first stop color or black)
- DO NOT support CSS-defined colors in SVG `<style>` blocks (out of scope)
- DO NOT use Stagehand `act()` for excalidraw.com file upload - use Playwright native APIs

---

## Verification Strategy (MANDATORY)

### Test Decision
- **Infrastructure exists**: YES (Stagehand E2E in `tests/e2e/`)
- **User wants tests**: YES (E2E test for Excalidraw verification)
- **Framework**: Stagehand + Playwright + visual review

### Manual Execution Verification

**For preview changes:**
- [x] Run `bun run dev`
- [x] Navigate to Icon Library Generator
- [x] Upload a colorful SVG (e.g., multi-colored icon)
- [x] Verify preview shows original colors, not black

**For Excalidraw export:**
- [x] Export as .excalidrawlib
- [x] Open https://excalidraw.com
- [x] Import the library (hamburger menu → Open → select file)
- [x] Drag an icon onto canvas
- [x] Verify colors match original SVG

---

## Task Flow

```
Task 0 (fixtures) ──┐
                    ├──→ Task 1 (preview) ──→ Task 3 (svg-to-excalidraw) ──→ Task 4 (export flow) ──→ Task 5 (E2E test)
Task 2 (export-btn roughConfig) ─┘
```

## Parallelization

| Group | Tasks | Reason |
|-------|-------|--------|
| A | 0, 1, 2 | Independent setup/config changes |

| Task | Depends On | Reason |
|------|------------|--------|
| 3 | 1, 2 | Needs roughConfig fixed first to understand output |
| 4 | 3 | Needs color extraction working |
| 5 | 0, 4 | Needs fixtures and full export flow working |

---

## TODOs

- [x] 0. Create colorful SVG test fixtures

  **What to do**:
  - Create directory `tests/e2e/fixtures/colorful-icons/`
  - Create 3 simple SVGs with distinct, known colors:
    - `red-circle.svg` - red stroke (#FF0000)
    - `blue-square.svg` - blue stroke (#0000FF)  
    - `green-triangle.svg` - green stroke (#00FF00)
  - Each SVG should be simple (single shape) with explicit stroke attribute

  **Must NOT do**:
  - No gradients
  - No CSS `<style>` blocks
  - No complex multi-path shapes

  **Parallelizable**: YES (with 1, 2)

  **References**:
  - `tests/e2e/fixtures/` - existing fixtures location pattern
  - Simple SVG format: `<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" stroke="#FF0000" fill="none" stroke-width="4"/></svg>`

  **Acceptance Criteria**:
  - [ ] 3 SVG files created in `tests/e2e/fixtures/colorful-icons/`
  - [ ] Each SVG has explicit `stroke` attribute with known hex color
  - [ ] SVGs render correctly when opened in browser

  **Commit**: YES
  - Message: `test(e2e): add colorful SVG fixtures for color verification`
  - Files: `tests/e2e/fixtures/colorful-icons/*.svg`

---

- [x] 1. Remove hardcoded stroke from sketchy-icon-preview.tsx

  **What to do**:
  - Remove `stroke: "#000000"` from roughConfig (line 146)
  - Remove `strokeWidth: 2` from roughConfig (let svg2roughjs use original)
  - Keep `fill: undefined` to preserve original fills

  **Must NOT do**:
  - Do not change other roughConfig properties (fillStyle, roughness, bowing)
  - Do not change randomize or pencilFilter settings

  **Parallelizable**: YES (with 0, 2)

  **References**:
  **Pattern References**:
  - `apps/web/src/components/icon-library/sketchy-icon-preview.tsx:141-148` - current roughConfig location
  
  **External References**:
  - svg2roughjs docs: roughConfig without stroke/fill preserves original colors

  **Acceptance Criteria**:
  - [ ] `stroke: "#000000"` removed from roughConfig
  - [ ] `strokeWidth: 2` removed from roughConfig
  - [ ] `bun run dev` → preview shows colorful SVGs with original colors
  - [ ] `bun x ultracite check` passes

  **Commit**: YES
  - Message: `fix(icon-library): preserve original colors in sketchy preview`
  - Files: `apps/web/src/components/icon-library/sketchy-icon-preview.tsx`

---

- [x] 2. Remove hardcoded stroke from export-button.tsx roughConfig

  **What to do**:
  - Remove `stroke: "#000000"` from roughConfig in `renderSketchySvg` function (line 100)
  - Remove `strokeWidth: 2` from roughConfig
  - This affects both the sketchy ZIP export AND will be used for Excalidraw export

  **Must NOT do**:
  - Do not modify `handleExportZip` (original SVG export)
  - Do not change fillStyle, roughness, bowing settings

  **Parallelizable**: YES (with 0, 1)

  **References**:
  **Pattern References**:
  - `apps/web/src/components/icon-library/export-button.tsx:91-113` - renderSketchySvg function
  - `apps/web/src/components/icon-library/export-button.tsx:95-102` - roughConfig location

  **Acceptance Criteria**:
  - [ ] `stroke: "#000000"` removed from roughConfig
  - [ ] `strokeWidth: 2` removed from roughConfig
  - [ ] Sketchy ZIP export produces SVGs with original colors
  - [ ] `bun x ultracite check` passes

  **Commit**: NO (groups with 4)

---

- [x] 3. Add color extraction to svg-to-excalidraw.ts

  **What to do**:
  - Add helper function `extractColors(element: SVGElement)` that reads:
    - `stroke` attribute → strokeColor
    - `fill` attribute → backgroundColor
    - Handle `none`, `transparent`, missing values with sensible defaults
  - Modify `svgToExcalidrawElements` to:
    - Accept sketchy SVG (output from svg2roughjs) as input
    - Extract colors from each geometry element
    - Use extracted strokeColor instead of hardcoded `#000000`
    - Use extracted fill as backgroundColor instead of `transparent`
    - Set `roughness: 0` (sketchiness already baked in)
  - Default fallbacks:
    - No stroke attribute → `#000000`
    - `stroke="none"` → `#00000000` (transparent)
    - No fill attribute → `transparent`

  **Must NOT do**:
  - Do not extract colors for text elements (line 303) - keep labels black
  - Do not change strokeWidth (keep at 2)
  - Do not attempt to parse CSS `<style>` blocks
  - Do not handle gradients (use black fallback)

  **Parallelizable**: NO (depends on 1, 2)

  **References**:
  **Pattern References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:228-278` - freedraw element creation
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:260-261` - current hardcoded colors
  
  **API/Type References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:102-128` - ExcalidrawBaseElement type with strokeColor, backgroundColor

  **External References**:
  - SVG stroke attribute: https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/stroke
  - SVG fill attribute: https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/fill

  **Acceptance Criteria**:
  - [ ] `extractColors()` helper function exists and handles stroke/fill/none/missing
  - [ ] Freedraw elements use extracted strokeColor
  - [ ] Freedraw elements use extracted backgroundColor
  - [ ] Text elements still use `#000000` (unchanged)
  - [ ] `roughness: 0` on all freedraw elements
  - [ ] `bun x ultracite check` passes
  - [ ] TypeScript compiles without errors

  **Commit**: NO (groups with 4)

---

- [x] 4. Update Excalidraw export to use sketchy SVG

  **What to do**:
  - Modify `handleExportExcalidraw` in export-button.tsx to:
    1. Fetch original SVG
    2. Render through svg2roughjs (reuse `renderSketchySvg` function)
    3. Pass sketchy SVG string to `svgToExcalidrawElements`
  - This ensures Excalidraw export matches the preview exactly (WYSIWYG)

  **Must NOT do**:
  - Do not change the .excalidrawlib file structure/format
  - Do not modify handleExportZip or handleExportSketchyZip

  **Parallelizable**: NO (depends on 3)

  **References**:
  **Pattern References**:
  - `apps/web/src/components/icon-library/export-button.tsx:122-191` - handleExportExcalidraw function
  - `apps/web/src/components/icon-library/export-button.tsx:66-113` - renderSketchySvg function to reuse

  **Acceptance Criteria**:
  - [ ] handleExportExcalidraw calls renderSketchySvg before svgToExcalidrawElements
  - [ ] Exported .excalidrawlib contains elements with original colors
  - [ ] Manual test: export → import to excalidraw.com → colors visible
  - [ ] `bun run build` succeeds
  - [ ] `bun x ultracite check` passes

  **Commit**: YES
  - Message: `fix(icon-library): preserve colors in Excalidraw export via sketchy SVG pipeline`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`, `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`
  - Pre-commit: `bun run build && bun x ultracite check`

---

- [x] 5. Create E2E test for Excalidraw color verification

  **What to do**:
  - Create new test file `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts`
  - Test flow:
    1. Navigate to Icon Library Generator
    2. Create library with unique name
    3. Upload colorful SVG fixtures (from Task 0)
    4. Export as .excalidrawlib (intercept download with `page.waitForEvent('download')`)
    5. Navigate to https://excalidraw.com
    6. Import library via file chooser (`page.waitForEvent('filechooser')` + `setFiles()`)
    7. Drag an icon onto canvas using Stagehand
    8. Take screenshot
    9. Visual review with prompt: "Verify the Excalidraw canvas shows icons with colors. Look for red, blue, and green colored shapes. The icons should NOT be all black."

  **Must NOT do**:
  - Do not use Stagehand `act()` for file chooser on excalidraw.com
  - Do not skip the visual verification step
  - Do not hardcode file paths (use relative paths from test file)

  **Parallelizable**: NO (depends on 0, 4)

  **References**:
  **Pattern References**:
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts` - existing test structure
  - `tests/e2e/src/runner/stagehand.ts:96-170` - captureScreenshot with visual review
  - `tests/e2e/src/runner/utils.ts` - resetBrowserState, ensureDesktopViewport

  **Test References**:
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts:117-127` - export and screenshot pattern

  **External References**:
  - Playwright download handling: https://playwright.dev/docs/downloads
  - Playwright file chooser: https://playwright.dev/docs/api/class-filechooser

  **Acceptance Criteria**:
  - [ ] Test file created at correct path
  - [ ] Test uploads colorful SVG fixtures
  - [ ] Test intercepts .excalidrawlib download
  - [ ] Test navigates to excalidraw.com and imports via file chooser
  - [ ] Test takes screenshot and runs visual review
  - [ ] Visual review prompt specifically mentions red/blue/green colors
  - [ ] Test runs locally: `bun run --cwd tests/e2e test:local`
  - [ ] `bun x ultracite check` passes on test file

  **Commit**: YES
  - Message: `test(e2e): add Excalidraw color export verification test`
  - Files: `tests/e2e/src/scenarios/unauthenticated/excalidraw-export-colors.ts`
  - Pre-commit: `bun x ultracite check`

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 0 | `test(e2e): add colorful SVG fixtures for color verification` | `tests/e2e/fixtures/colorful-icons/*.svg` | Files exist |
| 1 | `fix(icon-library): preserve original colors in sketchy preview` | `sketchy-icon-preview.tsx` | `bun x ultracite check` |
| 4 | `fix(icon-library): preserve colors in Excalidraw export via sketchy SVG pipeline` | `export-button.tsx`, `svg-to-excalidraw.ts` | `bun run build` |
| 5 | `test(e2e): add Excalidraw color export verification test` | `excalidraw-export-colors.ts` | `bun x ultracite check` |

---

## Success Criteria

### Verification Commands
```bash
# Build succeeds
bun run build

# Linting passes  
bun x ultracite check

# E2E test passes (local)
bun run --cwd tests/e2e test:local -- excalidraw-export-colors
```

### Final Checklist
- [x] All "Must Have" present
- [x] All "Must NOT Have" absent
- [x] Preview shows original colors
- [x] Excalidraw export preserves colors
- [x] E2E test passes with visual verification
- [x] Build and lint pass
