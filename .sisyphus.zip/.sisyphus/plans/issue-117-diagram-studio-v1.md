# Issue 117: Diagram Studio v1 (Sessions + AI Restructure)

## TL;DR

> **Quick Summary**: Add a first-class Diagram Studio to the web app with an embedded editable Excalidraw canvas, a Restructure-first chat sidebar, and Convex-backed session persistence (OCC + capability-token URLs).
>
> **Deliverables**:
> - `/diagrams` landing that creates a new session and routes to `/diagrams/:sessionId`
> - `/diagrams/:sessionId` Diagram Studio (Excalidraw + autosave + chat + import/export)
> - Convex `diagramSessions` table + CRUD with optimistic concurrency + size guardrails
> - New Convex action `diagrams.restructureFromScene({ elements, appState, prompt })`
> - Deterministic Convex tests (mock AI internals) + Stagehand E2E coverage for key UX flows
>
> **Estimated Effort**: Large
> **Parallel Execution**: YES - 3 waves
> **Critical Path**: Convex sessions + OCC -> Studio route + autosave/conflict UX -> E2E + CI + PR checks

---

## Context

### Original Request
- Implement: https://github.com/anand-testcompare/sketchi/issues/117
- “Perfect” implementation quality: readable, maintainable, minimal duplication; ready to extend soon with #120 and native Convex Agents/threads.
- Must be PR-ready: linted, typechecked, built, tests passing, GitHub Actions green; minimize user intervention during review/merge.

### Problem Statement
Today, AI diagram generation exists as actions and share-link based tooling, but the web app’s “AI Diagram Generation” is still “coming soon”. Issue #117 defines a V1 Diagram Studio where **Convex is canonical** for scene state, and AI “Restructure” operates directly on the in-memory scene (no share-link round trip).

### Hard Requirements (from Issue #117)
- Convex is canonical for diagram state via `diagramSessions.latestScene = { elements, appState }`.
- Excalidraw share links are import/export only (not primary persistence).
- Session URL is a capability token (no auth v1): if you have the session id, you can edit.
- Must be unguessable: >= 128 bits of entropy; no session listing endpoint.
- OCC via `latestSceneVersion` monotonic int; prevent silent clobber; explicit conflict UX.
- Restructure overwrites manual layout (simplify to IntermediateFormat + deterministic re-render).
- No Convex Agents/threads/messages/tool traces in V1 (explicit non-goal; epic is #120).

### Codebase Findings (relevant)
- Existing diagram actions: `packages/backend/convex/diagrams.ts`
  - `diagrams.restructureDiagram({ shareUrl, prompt })` exists (share-link based).
  - `diagrams.parseDiagram`, `diagrams.shareDiagram` exist (import/export primitives).
  - `simplifyDiagramElements` exists: `packages/backend/lib/diagram-simplify.ts`.
- Existing deterministic tests mock AI internals:
  - `packages/backend/convex/diagrams.test.ts` mocks `generateIntermediate` + `modifyIntermediate`.
  - We should follow this pattern so new tests do not flake on LLM variability.
- Web app:
  - Home card “AI Diagram Generation” is `coming-soon`: `apps/web/src/app/page.tsx`.
  - Convex client is set up globally: `apps/web/src/components/providers.tsx`.
- E2E:
  - Stagehand scenarios are Playwright-first and prefer stable selectors + minimal assertions: `tests/e2e/src/scenarios/unauthenticated/*`.

### Metis Review (gaps addressed)
- Capability token entropy: Convex `_id` is **not** >=128 bits of entropy; must add a separate 128-bit+ `sessionId`/`accessToken` field and index it.
- Convex doc size limit (1MB): Excalidraw scenes can grow large; must add size validation and user-visible error.
- Autosave races restructure: must suppress autosave while restructure is in-flight; also avoid autosave triggering on initial load.
- Excalidraw in Next.js App Router: must use `next/dynamic` with `ssr: false` and import Excalidraw CSS; add `@excalidraw/excalidraw` to `apps/web`.
- `diagrams.ts` is already large; keep `diagramSessions` in its own Convex file.

---

## Work Objectives

### Core Objective
Deliver Diagram Studio v1: users can open a capability-token session URL, edit an embedded Excalidraw canvas with throttled autosave to Convex, run AI Restructure to overwrite layout, and import/export via share links and downloads.

### Concrete Deliverables
- Convex schema update: `diagramSessions` table.
- Convex functions:
  - `diagramSessions.create()` -> returns `sessionId` (capability token)
  - `diagramSessions.get({ sessionId })` -> returns latest scene + version or null
  - `diagramSessions.setLatestScene({ sessionId, expectedVersion, scene })` -> success/conflict + new version
  - `diagrams.restructureFromScene({ elements, appState, prompt, options? })` -> returns new scene (no share-link round trip)
- Web UI:
  - `/diagrams` landing with “New diagram” CTA that creates session and routes to `/diagrams/:sessionId`
  - `/diagrams/:sessionId` studio: Excalidraw + chat + import/export + conflict UX + layout rewrite warning
- Tests:
  - Convex unit tests: OCC conflict, scene size guard, restructureFromScene pipeline (mock modifyIntermediate)
  - Stagehand E2E: create session, edit + autosave + reload persistence, conflict UX, import/export flows

### Definition of Done
- All ACs from Issue #117 are met (AC1-AC7), with agent-executed verification.
- Commands succeed:
  - `bun x ultracite check`
  - `bun run check-types`
  - `bun run build`
  - `cd packages/backend && bunx convex codegen && bun run test`
- GitHub Actions green:
  - `ci-tests` (backend)
  - `e2e-web` (runs on preview deploy)

### Must Have
- Capability token >= 128 bits entropy (not Convex `_id`), no listing endpoint.
- OCC with explicit conflict UX (no silent clobber).
- Throttled autosave, guarded against initial-load echo writes.
- Restructure warning in UI.

### Must NOT Have (Guardrails)
- No Convex Agents threads/messages/tool traces in v1 (non-goal, #120).
- No auth/user ownership, no session listing.
- No attempt to preserve manual layout during restructure.
- No new public ORPC endpoints for sessions (keep sessions in Convex client layer).
- No big refactor of existing `diagrams.restructureDiagram` (add new action alongside it).

---

## Verification Strategy (MANDATORY)

> **UNIVERSAL RULE: ZERO HUMAN INTERVENTION**
>
> All verification must be executable by the agent. No “user manually verifies”. Evidence is captured as screenshots/downloads/logs.

### Test Decision
- **Infrastructure exists**: YES
  - Backend: Vitest + convex-test (`packages/backend/convex/*.test.ts`)
  - E2E: Stagehand (Playwright) (`tests/e2e/src/scenarios/*`)
- **Automated tests**: YES (tests-after; deterministic where possible)
- **Frameworks**: Vitest, convex-test, Stagehand

### Agent-Executed QA Scenarios (mandatory per task)
- UI flows: Stagehand scenarios with stable selectors + downloads + screenshots.
- Backend flows: `bun run test` with deterministic mocks for AI steps.

---

## Execution Strategy

### Parallel Execution Waves

Wave 1 (Backend foundations):
1) `diagramSessions` schema + CRUD + OCC + size guard + unit tests
2) `diagrams.restructureFromScene` action + unit tests

Wave 2 (Web studio):
3) Add Excalidraw dependency + route skeletons (`/diagrams`, `/diagrams/:sessionId`)
4) Implement Excalidraw wrapper + session load/apply + session info panel
5) Implement autosave throttle + OCC conflict UX

Wave 3 (Product polish + E2E + CI):
6) Chat sidebar restructure integration + layout warning
7) Import/export UX
8) Add Stagehand scenarios + wire into `.github/workflows/e2e-web.yml`
9) Full repo verification + PR readiness (checks + CodeRabbit feedback loop)

---

## TODOs

> Implementation + tests live together. Each task ends with agent-executable acceptance criteria.

- [x] 1. Backend: Add `diagramSessions` schema + capability token + OCC + size guard

  **What to do**:
  - Update `packages/backend/convex/schema.ts` to add `diagramSessions` table with:
    - `sessionId` (capability token, >=128 bits entropy)
    - `latestScene` optional: `{ elements, appState }`
    - `latestSceneVersion` number (monotonic)
    - `createdAt`, `updatedAt`
    - Optional future field (allowed): `threadId?: string` (do not use in v1)
  - Add index `by_sessionId`.
  - Create `packages/backend/convex/diagramSessions.ts` with:
    - `create` mutation: generate 16 random bytes -> hex string (32 chars) as `sessionId`; ensure uniqueness via index lookup loop; insert row; return `sessionId`.
      - Insert defaults:
        - `latestSceneVersion: 0`
        - `latestScene: undefined` (treat as empty scene in UI)
        - `createdAt/updatedAt: Date.now()`
    - `get` query: lookup by `sessionId` index; return `{ sessionId, latestScene, latestSceneVersion }` (and timestamps) or `null`.
    - `setLatestScene` mutation:
      - Args: `{ sessionId, expectedVersion, scene }`.
      - Validate scene size (bytes) < threshold using `TextEncoder` + `JSON.stringify`.
        - Recommend: `MAX_SCENE_BYTES = 900_000` (buffer below Convex 1MB limit)
      - Filter `appState` before saving to reduce bloat and avoid transient state.
        - MUST strip keys like: `selectedElementIds`, `selectedGroupIds`, `editingElement`, `openDialog`, `collaborators`, `cursorButton`.
      - Enforce OCC:
        - If `expectedVersion !== latestSceneVersion`, return a structured conflict result and DO NOT patch.
      - Return contract (make this explicit and stable for UI + tests):
        - Success: `{ status: "success", latestSceneVersion: number, savedAt: number }`
        - Conflict: `{ status: "conflict", latestSceneVersion: number }`
        - Too large: `{ status: "failed", reason: "scene-too-large", maxBytes: number, actualBytes: number }`
      - On success: patch `latestScene`, increment version, update timestamps.
  - Add new backend unit tests in `packages/backend/convex/diagramSessions.test.ts`:
    - create -> get returns empty scene with version 0
    - setLatestScene success increments version
    - setLatestScene conflict (stale expectedVersion) returns conflict result and does not clobber
    - setLatestScene rejects over-size scene with explicit error code
  - Update convex-test module map in `packages/backend/convex/test.setup.ts` to include `./diagramSessions.ts`.

  **Must NOT do**:
  - Do not expose a list/query-all sessions function.
  - Do not add auth/ownership.

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Schema + OCC + size constraints require careful correctness.
  - **Skills**: `git-master`
    - `git-master`: keep commits small and reversible.

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 2)
  - **Parallel Group**: Wave 1
  - **Blocks**: Tasks 3-8 (web needs session API)
  - **Blocked By**: None

  **References**:
  - `packages/backend/convex/schema.ts` - existing schema style; add new table + index.
  - `packages/backend/convex/iconLibraries.ts` - query/mutation style + index usage.
  - `packages/backend/convex/test.setup.ts` - convex-test module map; must include new file.
  - Issue spec: https://github.com/anand-testcompare/sketchi/issues/117 (Canonical State + OCC)

  **Acceptance Criteria**:
  - [ ] `packages/backend/convex/schema.ts` includes `diagramSessions` with `by_sessionId` index.
  - [ ] `packages/backend/convex/diagramSessions.ts` exports `create`, `get`, `setLatestScene`.
  - [ ] `packages/backend/convex/diagramSessions.test.ts` exists and passes:
    - `cd packages/backend && bun run test` -> PASS
  - [ ] `setLatestScene` conflict path returns a structured result (not a generic throw) and leaves stored scene unchanged.
  - [ ] `setLatestScene` too-large path returns `reason: "scene-too-large"` with `maxBytes` and `actualBytes`.

  **Agent-Executed QA Scenarios**:
  - Scenario: OCC stale write rejected (Convex test)
    Tool: `bun run test`
    Steps: run `cd packages/backend && bun run test --runInBand diagramSessions.test.ts`
    Expected Result: test asserts conflict result and unchanged scene

- [x] 2. Backend: Add `diagrams.restructureFromScene` action (no share-link round-trip) + deterministic tests

  **What to do**:
  - Add a new action export to `packages/backend/convex/diagrams.ts`:
    - Name: `restructureFromScene`
    - Args: `{ elements: unknown[], appState?: any, prompt: string, traceId?: string, options?: { profileId?, timeoutMs?, maxSteps? }, sessionId?: string (optional for future) }`
    - Pipeline:
      1) log start (reuse `logEventSafely` pattern)
      2) simplify -> intermediate: `simplifyDiagramElements(elements)`
      3) `modifyIntermediate(intermediate, prompt, options)`
      4) validate edge references: `validateEdgeReferences`
      5) render: `renderIntermediateDiagram(modifiedIntermediate)`
      6) return `{ status, elements, appState, stats }` (NO share link, NO intermediate payload)
  - Ensure error handling mirrors `restructureDiagram`:
    - returns `status: failed` with `reason` + `issues[]` + `stats`
  - Add tests in `packages/backend/convex/diagrams.test.ts`:
    - mock `modifyIntermediate` to return known intermediate; call `api.diagrams.restructureFromScene` and assert:
      - status success
      - elements array is non-empty
      - intermediate not leaked

  **Must NOT do**:
  - Do not change existing `restructureDiagram` behavior or signature.
  - Do not add a share-link generation step to `restructureFromScene`.

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: `git-master`

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 1)
  - **Parallel Group**: Wave 1
  - **Blocks**: Task 6 (chat restructure in UI)
  - **Blocked By**: None

  **References**:
  - `packages/backend/convex/diagrams.ts` - existing restructureDiagram pipeline to mirror.
  - `packages/backend/lib/diagram-simplify.ts` - `simplifyDiagramElements` entrypoint.
  - `packages/backend/convex/diagrams.test.ts` - mocking pattern for deterministic tests.
  - Issue spec: “Current State (Gap Callouts)” requests `restructureFromScene`.

  **Acceptance Criteria**:
  - [ ] `api.diagrams.restructureFromScene` exists and is callable from Convex.
  - [ ] `packages/backend/convex/diagrams.test.ts` includes at least one test covering it.
  - [ ] `cd packages/backend && bun run test` -> PASS.

- [x] 3. Web: Install Excalidraw + add `/diagrams` landing (create session) + wire home card

  **What to do**:
  - Add `@excalidraw/excalidraw` dependency to `apps/web/package.json`.
  - Add route `apps/web/src/app/diagrams/page.tsx`:
    - UI: “New diagram” button.
    - On click: call `api.diagramSessions.create` (Convex mutation) and route to `/diagrams/${sessionId}`.
    - No session listing.
  - Update home card in `apps/web/src/app/page.tsx`:
    - Change “AI Diagram Generation” from `coming-soon` to `alpha` or `available`.
    - Make it navigate to `/diagrams`.
    - Update the `FeatureCardProps.href` typing (currently `"/library-generator"` only) to include `/diagrams` (or widen to `string`).

  **Must NOT do**:
  - Do not add a sessions listing grid.
  - Do not add auth.

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
  - **Skills**: `frontend-ui-ux`, `git-master`

  **Parallelization**:
  - **Can Run In Parallel**: YES (after Tasks 1-2)
  - **Parallel Group**: Wave 2
  - **Blocks**: Task 4+ (studio needs sessionId creation entrypoint)
  - **Blocked By**: Task 1

  **References**:
  - `apps/web/src/app/library-generator/page.tsx` - pattern for create + router push + loading/toast.
  - `apps/web/src/app/page.tsx` - feature card configuration; change status/href.
  - `apps/web/src/components/providers.tsx` - Convex client already configured.

  **Acceptance Criteria**:
  - [ ] Visiting `/diagrams` shows a “New diagram” CTA.
  - [ ] Clicking “New diagram” navigates to `/diagrams/:sessionId` (32 hex chars) and does not error.
  - [ ] Home page “AI Diagram Generation” card is clickable and routes to `/diagrams`.

  **Agent-Executed QA Scenarios**:
  - Scenario: Create session from landing page
    Tool: Stagehand (Playwright)
    Steps:
      1. Navigate to `${STAGEHAND_TARGET_URL}/diagrams`
      2. Click button `[data-testid="diagram-new-session"]`
      3. Assert URL matches `/diagrams/[0-9a-f]{32}`
      4. Screenshot `.sisyphus/evidence/task-3-diagrams-new-session.png`

- [x] 4. Web: Add Diagram Studio page `/diagrams/:sessionId` with embedded Excalidraw + session load/apply

  **What to do**:
  - Create `apps/web/src/app/diagrams/[sessionId]/page.tsx` as a client page (uses Convex hooks).
  - Ensure Excalidraw CSS is loaded (Next.js App Router global CSS constraint):
    - Preferred: import `@excalidraw/excalidraw/index.css` inside the client-only Excalidraw wrapper component (`"use client"`).
    - Fallback: import in `apps/web/src/app/layout.tsx` (root layout) if Next rejects non-root global CSS imports.
  - Implement Excalidraw wrapper component(s) in `apps/web/src/components/diagram-studio/`:
    - Use `next/dynamic` with `ssr:false` to import `Excalidraw` component.
    - Provide a stable container with `data-testid="diagram-canvas"`.
  - Session loading:
    - `useQuery(api.diagramSessions.get, { sessionId })`.
    - If null: show “Session not found” + CTA to create new.
    - If found: apply `latestScene` to Excalidraw via API/ref.
    - Avoid triggering autosave on initial apply (set a `suppressOnChange` ref).
  - Show session info panel (for UX + testability):
    - display `sessionId`, `latestSceneVersion`, element count, last saved status.
    - add stable testids: `diagram-session-version`, `diagram-element-count`, `diagram-save-status`.

  **Must NOT do**:
  - Do not add collaboration features; just OCC conflict detection.

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
  - **Skills**: `frontend-ui-ux`

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 5 scaffolding)
  - **Parallel Group**: Wave 2
  - **Blocks**: Task 5-7
  - **Blocked By**: Task 3

  **References**:
  - `apps/web/src/components/providers.tsx` - Convex setup.
  - `apps/web/src/app/layout.tsx` - global layout constraints (`grid-rows-[auto_1fr]`).
  - Excalidraw dep usage patterns (existing): `packages/backend/package.json` already has `@excalidraw/excalidraw`.

  **Acceptance Criteria**:
  - [ ] `/diagrams/:sessionId` loads without console errors.
  - [ ] If session missing, page renders a friendly not-found state.
  - [ ] If session exists, Excalidraw mounts and displays a blank scene (or saved scene) and session info panel shows version.

- [x] 5. Web: Implement throttled autosave to Convex + OCC conflict UX

  **What to do**:
  - Add throttled autosave using `setTimeout`/`clearTimeout` pattern:
    - Take snapshots from Excalidraw `onChange` and schedule `setLatestScene` after idle.
    - Only autosave after the user has edited (avoid initial load echo).
  - Conflict handling:
    - If `setLatestScene` returns conflict, show an explicit conflict banner/modal with actions:
      - Reload: refetch session and apply server scene
      - Overwrite: attempt save again using the server’s latest version as expectedVersion
    - Ensure no silent clobber.
  - Add save-state UX:
    - “Saving…” while mutation in-flight
    - “Saved” with timestamp on success
    - “Conflict” state when conflict
  - Size error handling:
    - If `setLatestScene` returns size error, show clear toast and disable autosave until user reduces scene.
  - Ensure autosave is suppressed while restructure is running (Task 6) and while applying server scenes.

  **Must NOT do**:
  - Do not silently retry conflicts without user decision.

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
  - **Skills**: `frontend-ui-ux`

  **Parallelization**:
  - **Can Run In Parallel**: NO (depends on Task 4)
  - **Parallel Group**: Wave 2
  - **Blocks**: Task 6-8
  - **Blocked By**: Task 4

  **References**:
  - `apps/web/src/components/icon-library/sketchy-icon-preview.tsx` - debounce pattern.
  - Issue #117 AC2/AC3.

  **Acceptance Criteria**:
  - [ ] Editing the canvas triggers autosave (throttled) and increments `latestSceneVersion`.
  - [ ] Reloading the page restores the last saved scene (element count matches).
  - [ ] Two tabs: stale save attempt shows conflict UX and does not overwrite.

  **Agent-Executed QA Scenarios**:
  - Scenario: Autosave persists and reload restores
    Tool: Stagehand (Playwright)
    Preconditions: Session created
    Steps:
      1. Add a text element (keyboard `t`, click canvas, type `hello`, press Escape)
      2. Wait for `[data-testid="diagram-save-status"]` to become `Saved`
      3. Capture version from `[data-testid="diagram-session-version"]`
      4. Reload
      5. Assert version is unchanged and element count > 0
      6. Screenshot `.sisyphus/evidence/task-5-autosave-reload.png`

- [x] 6. Web: Chat sidebar (Restructure primary) + warning + snapshot/persist/apply/persist

  **What to do**:
  - Add chat panel UI in `apps/web/src/components/diagram-studio/`:
    - Prompt input + send button
    - Ephemeral message list (local React state only)
    - Explicit warning: “Restructure rewrites layout and may drop non-graph elements.”
  - Implement restructure flow per issue:
    1) Snapshot scene at click time
    2) Persist snapshot to session (`setLatestScene`)
    3) Call `api.diagrams.restructureFromScene({ elements, appState, prompt })`
    4) Apply returned scene to Excalidraw
    5) Persist updated scene to session
  - Concurrency guardrails:
    - Disable send while restructure in-flight
    - Suppress autosave while restructure runs
    - If OCC conflict occurs on final persist, surface conflict UX

  **Must NOT do**:
  - Do not persist chat history in Convex (non-goal in v1).

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
  - **Skills**: `frontend-ui-ux`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 3
  - **Blocks**: Task 8
  - **Blocked By**: Task 5 and Task 2

  **References**:
  - Issue #117 “Restructure (primary)” flow.
  - `packages/backend/convex/diagrams.ts` restructure result shape patterns.

  **Acceptance Criteria**:
  - [ ] Warning is visible before running restructure.
  - [ ] Clicking Send persists snapshot, runs action, applies new scene, persists new scene.
  - [ ] Autosave does not interfere while restructure is running.

- [x] 7. Web: Import / Export UX (share link import/export + .excalidraw + PNG)

  **What to do**:
  - Import:
    - UI to paste share link (Excalidraw share or Excalidraw+ link).
    - Call `api.diagrams.parseDiagram({ shareUrl })` to get `{ elements, appState }`.
    - Apply to canvas + persist to session.
  - Export:
    - Share link: call `api.diagrams.shareDiagram({ elements, appState })`; show/copy returned URL.
    - `.excalidraw` download: serialize current scene and trigger file download.
    - PNG download: use Excalidraw `exportToBlob` on the client.
  - Add stable testids:
    - `diagram-import-input`, `diagram-import-submit`, `diagram-export-share`, `diagram-export-excalidraw`, `diagram-export-png`.

  **Must NOT do**:
  - Do not make share links the primary persistence mechanism.

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
  - **Skills**: `frontend-ui-ux`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 3
  - **Blocked By**: Task 4-6

  **References**:
  - Existing black-box API coverage: `tests/e2e/src/scenarios/unauthenticated/excalidraw-plus-links.ts`.
  - ORPC routes for diagrams endpoints: `apps/web/src/lib/orpc/router.ts` (for understanding parse/tweak/share semantics).
  - Convex actions: `packages/backend/convex/diagrams.ts` (`parseDiagram`, `shareDiagram`).

  **Acceptance Criteria**:
  - [ ] Importing a valid share link updates the canvas and persists; reload shows imported scene.
  - [ ] Export share link returns a URL that matches `https://excalidraw.com/#json=`.
  - [ ] Export `.excalidraw` triggers a download with valid JSON.
  - [ ] Export PNG triggers a download with non-zero bytes.

- [x] 8. E2E: Add Diagram Studio Stagehand scenarios + wire into CI workflow

  **What to do**:
  - Add new scenario files under `tests/e2e/src/scenarios/unauthenticated/`:
    - `diagram-studio-happy-path.ts`:
      - create session
      - add text element
      - wait for autosave
      - reload and assert persistence via session info panel
      - verify warning exists
      - import known share link -> persist -> reload
      - export share link (assert pattern)
      - export `.excalidraw` download (assert JSON contains elements)
    - `diagram-studio-occ-conflict.ts`:
      - open same session in two pages
      - tab A edit + save
      - tab B edit + attempt save -> conflict UI
      - choose reload and verify state refreshes
  - Update `tests/e2e/package.json` scripts to include the new scenarios.
  - Update `.github/workflows/e2e-web.yml` to run the new scripts after existing ones.

  **Must NOT do**:
  - Avoid brittle selectors: prefer your own `data-testid` attributes.

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: `playwright`, `git-master`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 3
  - **Blocked By**: Tasks 3-7

  **References**:
  - E2E patterns: `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts`.
  - Runner utilities: `tests/e2e/src/runner/stagehand.ts`.
  - CI workflow: `.github/workflows/e2e-web.yml`.

  **Acceptance Criteria**:
  - [ ] `cd tests/e2e && bun run diagram-studio-happy-path` exits 0 locally.
  - [ ] `cd tests/e2e && bun run diagram-studio-occ-conflict` exits 0 locally.
  - [ ] `.github/workflows/e2e-web.yml` runs the new scenarios on preview deploy.

- [x] 9. Repo verification + PR readiness (checks + CodeRabbit loop)

  **What to do**:
  - Run repo sanity commands in order:
    - `bun x ultracite fix`
    - `bun x ultracite check`
    - `bun run check-types`
    - `bun run build`
    - `cd packages/backend && bunx convex codegen && bun run test`
  - Create a feature branch with correct prefix (e.g., `feature/diagram-studio-v1`).
  - Make small commits grouped by tasks (backend schema, backend action, web route, e2e).
  - Open a PR referencing #117.
  - Monitor GitHub Actions checks; fix any failures.
  - Monitor CodeRabbit review (if installed) and address comments until resolved.

  **Must NOT do**:
  - No force pushes to main.
  - No amending pushed commits unless explicitly needed.

  **Recommended Agent Profile**:
  - **Category**: `git-master`
  - **Skills**: `git-master`

  **Acceptance Criteria**:
  - [ ] PR exists, checks green, CodeRabbit comments (if any) are resolved.

---

## Commit Strategy

Suggested commit sequence (atomic, reviewable):
1) `feat(backend): add diagramSessions schema + OCC` (schema + diagramSessions.ts + tests)
2) `feat(backend): add diagrams.restructureFromScene` (action + tests)
3) `feat(web): add diagrams landing + enable home card` (/diagrams + home)
4) `feat(web): add diagram studio route + excalidraw embed + autosave` (core UI)
5) `feat(web): add restructure chat + import/export` (product completeness)
6) `test(e2e): add diagram studio scenarios` (E2E + workflow)

---

## Success Criteria

### Verification Commands
```bash
bun x ultracite check
bun run check-types
bun run build
cd packages/backend && bunx convex codegen && bun run test
```

### Final Checklist
- [x] Capability-token sessions use >=128-bit token (NOT Convex `_id`).
- [x] No session listing endpoints.
- [x] OCC prevents silent clobber; conflict UX present.
- [x] Autosave is throttled and does not fire on initial load; suppressed during restructure.
- [x] Import/export works; share links remain secondary.
- [x] E2E coverage exists and is wired into preview CI.
- [x] PR checks green; minimal reviewer friction.
