# Issue #21: Fix Excalidraw and SVG Export

## Context

### Original Request
Fix two bugs in icon library export functionality:
1. Exported `.excalidrawlib` files not importing into Excalidraw (nothing happens)
2. "Export as ZIP (SVGs)" exports original SVGs, not sketchy-rendered versions

User requirements:
- Tests must pass
- Include evidence in issue before PR
- Test locally with Playwright MCP
- CI must run successfully
- Incorporate valid CodeRabbit comments

### Interview Summary
**Key Discussions**:
- Analyzed `export-button.tsx` (lines 48-117 for Excalidraw, 119-163 for ZIP)
- Reviewed `svg-to-excalidraw.ts` element generation (lines 247-278)
- Found official Excalidraw spec for freedraw elements
- Identified `sketchy-icon-preview.tsx` (lines 140-152) as svg2roughjs reference

**Research Findings**:
- Freedraw elements require: `type`, `points`, `pressures`, `simulatePressure`, plus base fields
- `index: null` (line 273) may be problematic - Excalidraw may expect fractional indices
- `restoreElements()` is permissive but silently drops invalid elements
- ZIP export (lines 130-140) downloads raw SVGs, needs svg2roughjs pass

### Metis Review
**Identified Gaps** (addressed):
- Need reference `.excalidrawlib` from Excalidraw to validate format → Added as validation task
- svg2roughjs output serialization unverified → Use `outerHTML` like preview component
- E2E test is just a stub (20 lines) → Will implement full test

---

## Work Objectives

### Core Objective
Fix both export bugs so Excalidraw library import works and ZIP exports contain sketchy SVGs.

### Concrete Deliverables
- Fixed `svgToExcalidrawElements()` with valid element format
- New `handleExportSketchyZip()` function in `export-button.tsx`
- Third dropdown option "Export as Sketchy SVGs (ZIP)"
- Implemented E2E test for export workflows
- Evidence posted to GitHub issue #21
- PR with passing CI

### Definition of Done
- [x] Export `.excalidrawlib` → import into excalidraw.com → library appears
- [x] Export "Sketchy SVGs (ZIP)" → unzip shows rendered SVGs (not original)
- [x] E2E tests pass locally and in CI
- [x] GitHub issue #21 updated with evidence before PR
- [x] CI green, CodeRabbit comments addressed

### Must Have
- Excalidraw library import works on excalidraw.com
- Sketchy SVG export uses svg2roughjs with current style settings
- Deterministic output (fixed seed like preview component)
- E2E test covers both export types

### Must NOT Have (Guardrails)
- No unit tests (per AGENTS.md: API > E2E > unit)
- No changes to preview component (only reference its pattern)
- No new dependencies beyond what's already used
- No UI redesign of dropdown
- No backend/Convex changes
- No removing original "Export as ZIP (SVGs)" option

---

## Verification Strategy

### Test Decision
- **Infrastructure exists**: YES (Stagehand E2E in `tests/e2e/`)
- **User wants tests**: YES (E2E per AGENTS.md)
- **Framework**: Stagehand 3 with Playwright MCP for local testing

### E2E Test Approach
Each TODO includes Playwright MCP verification locally, then Stagehand E2E for CI.

---

## Task Flow

```
Task 0 (Validate) → Task 1 (Bug 1 Fix) → Task 2 (Bug 2 Fix) → Task 3 (E2E Tests) → Task 4 (Local Verify) → Task 5 (Update Issue) → Task 6 (PR + CI)
                                                                          ↘
                                                              Task 3b (Fix Stagehand complexity error)
```

## Parallelization

| Group | Tasks | Reason |
|-------|-------|--------|
| - | 1, 2 | Sequential - Bug 1 must pass before testing export flow |

| Task | Depends On | Reason |
|------|------------|--------|
| 1 | 0 | Need reference format before fixing |
| 2 | 1 | Bug 1 fix may reveal shared issues |
| 3, 3b | 2 | Need both fixes complete to test |
| 4 | 3 | Need tests written before local verify |
| 5 | 4 | Need passing evidence before issue update |
| 6 | 5 | Issue updated before PR |

---

## TODOs

- [x] 0. Generate Reference Excalidraw Library for Comparison

  **What to do**:
  - Use Playwright MCP to navigate to excalidraw.com
  - Draw a simple freedraw element
  - Export as library (.excalidrawlib)
  - Download and inspect the JSON structure
  - Compare field values against `svg-to-excalidraw.ts` output
  - Document required field values (especially `index`, `lastCommittedPoint`)

  **Must NOT do**:
  - Skip this step - it's essential for understanding valid format

  **Parallelizable**: NO (blocking - must complete first)

  **References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:247-278` - Current element generation
  - Excalidraw restore.ts source: `https://github.com/excalidraw/excalidraw/blob/master/packages/excalidraw/data/restore.ts`

  **Acceptance Criteria**:
  - [ ] Have reference `.excalidrawlib` file with known-good freedraw element
  - [ ] Documented differences from current implementation
  - [ ] Clear list of fields to fix

  **Commit**: NO (research only)

---

- [x] 1. Fix Bug 1: Excalidraw Element Format in svg-to-excalidraw.ts

  **What to do**:
  - Update `svgToExcalidrawElements()` to match Excalidraw's expected format
  - Based on Task 0 findings, likely fixes:
    - `index: null` → may need fractional index like `"a0"`, `"a1"`
    - `lastCommittedPoint: null` → may need actual last point
    - Verify `pressures: []` with `simulatePressure: true` is valid
  - Test generated JSON by manually importing into excalidraw.com

  **Must NOT do**:
  - Refactor beyond what's needed for the fix
  - Change element types or add new element types
  - Modify style settings handling

  **Parallelizable**: NO (depends on Task 0)

  **References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:247-278` - Element creation
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:102-128` - ExcalidrawBaseElement interface
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:130-136` - ExcalidrawFreedrawElement interface
  - Task 0 reference file comparison

  **Acceptance Criteria**:
  - [ ] Using Playwright MCP:
    - Navigate to Icon Library Generator
    - Upload a test SVG
    - Export as .excalidrawlib
    - Navigate to excalidraw.com
    - Import the exported library
    - Verify: Library appears in library panel
    - Verify: Can drag icon to canvas
    - Screenshot evidence saved

  **Commit**: YES
  - Message: `fix(icon-library): correct excalidraw element format for library import`
  - Files: `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`
  - Pre-commit: `bun x ultracite check`

---

- [x] 2. Fix Bug 2: Add Sketchy SVG Export Option

  **What to do**:
  - Add new `handleExportSketchyZip()` function in `export-button.tsx`
  - Use svg2roughjs with style settings (following `sketchy-icon-preview.tsx:140-152` pattern)
  - Use fixed seed (12345) for deterministic output matching preview
  - Serialize rendered SVG using `container.innerHTML` or `outerHTML`
  - Add viewBox for scalability (like `makeSvgScalable` in preview)
  - Package into ZIP with sanitized filenames
  - Add third dropdown option "Export as Sketchy SVGs (ZIP)"
  - Keep existing "Export as ZIP (SVGs)" for raw/original access

  **Must NOT do**:
  - Remove or modify existing ZIP export option
  - Modify the preview component itself
  - Add new dependencies

  **Parallelizable**: NO (depends on Task 1 completion for full testing)

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:119-163` - Current ZIP export pattern
  - `apps/web/src/components/icon-library/sketchy-icon-preview.tsx:70-77` - Svg2Roughjs initialization
  - `apps/web/src/components/icon-library/sketchy-icon-preview.tsx:140-152` - svg2roughjs configuration and sketch()
  - `apps/web/src/components/icon-library/sketchy-icon-preview.tsx:26-46` - makeSvgScalable helper
  - `apps/web/src/components/icon-library/sketchy-icon-preview.tsx:23` - FIXED_SEED = 12345

  **Acceptance Criteria**:
  - [ ] Using Playwright MCP:
    - Navigate to Icon Library Generator
    - Upload a test SVG
    - Click Export dropdown
    - Verify: Three options visible (Excalidraw, ZIP, Sketchy ZIP)
    - Click "Export as Sketchy SVGs (ZIP)"
    - Download completes
    - Unzip and open SVG
    - Verify: SVG contains rough/sketchy paths (not original clean paths)
    - Screenshot evidence saved

  **Commit**: YES
  - Message: `feat(icon-library): add sketchy SVG export using svg2roughjs`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`
  - Pre-commit: `bun x ultracite check`

---

- [x] 3. Implement E2E Tests for Export Workflows

  **What to do**:
  - Implement `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts`
  - Cover: create library → upload SVGs → export .excalidrawlib → verify download
  - Cover: export sketchy ZIP → verify download
  - Use Stagehand 3 patterns from existing tests
  - Model: `google/gemini-2.5-flash-lite` for general actions

  **Must NOT do**:
  - Add unit tests
  - Create new test files beyond implementing the stub
  - Add brittle selectors (use prompt-first approach per tests/README.md)

  **Parallelizable**: NO (depends on Tasks 1, 2)

  **References**:
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts` - Stub to implement
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-invalid-svg.ts` - Pattern reference
  - `tests/e2e/src/scenarios/unauthenticated/visual-sanity.ts` - Pattern reference (note: has complexity error to avoid)
  - `tests/README.md` - Test philosophy and patterns

  **Acceptance Criteria**:
  - [ ] Run E2E test locally: `bun run test:e2e` or equivalent
  - [ ] Test passes with export workflows validated
  - [ ] No excessive complexity (avoid visual-sanity.ts issue)

  **Commit**: YES
  - Message: `test(e2e): implement icon library export workflow tests`
  - Files: `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts`
  - Pre-commit: `bun x ultracite check`

---

- [x] 3b. Fix visual-sanity.ts Complexity Error (if blocking CI)

  **What to do**:
  - Address LSP error: "Excessive complexity of 29 detected (max: 20)"
  - Refactor to reduce complexity below 20
  - Split into smaller functions if needed

  **Must NOT do**:
  - Change test behavior
  - Remove test coverage

  **Parallelizable**: YES (with Task 3)

  **References**:
  - `tests/e2e/src/scenarios/unauthenticated/visual-sanity.ts:59` - Complexity error location

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check` passes for visual-sanity.ts
  - [ ] Test still functions correctly

  **Commit**: YES
  - Message: `refactor(e2e): reduce visual-sanity.ts complexity`
  - Files: `tests/e2e/src/scenarios/unauthenticated/visual-sanity.ts`

---

- [x] 4. Local Verification with Playwright MCP

  **What to do**:
  - Run full export workflow using Playwright MCP
  - Test .excalidrawlib import on excalidraw.com
  - Test sketchy ZIP export content
  - Capture screenshots as evidence
  - Document any issues found

  **Must NOT do**:
  - Skip any verification step
  - Use mocked data

  **Parallelizable**: NO (depends on Tasks 1-3)

  **References**:
  - Load `/playwright` skill for browser automation
  - `apps/web` - Local dev server

  **Acceptance Criteria**:
  - [ ] Using Playwright MCP (load skill first):
    - Start dev server: `bun run dev`
    - Navigate to localhost:[port]/icon-library-generator
    - Upload test SVG
    - Export .excalidrawlib → download completes
    - Navigate to excalidraw.com
    - Import library → appears in panel
    - Screenshot: `evidence-excalidraw-import.png`
    - Return to app, export Sketchy ZIP
    - Unzip, inspect SVG → contains sketchy paths
    - Screenshot: `evidence-sketchy-svg.png`

  **Commit**: NO (verification only, screenshots for issue)

---

- [x] 5. Update GitHub Issue #21 with Evidence

  **What to do**:
  - Add comment to issue #21 with:
    - Summary of fixes made
    - Screenshots from Task 4 verification
    - Test results (E2E pass/fail)
  - Use `gh issue comment 21 --body "..."` command

  **Must NOT do**:
  - Close the issue (PR will do that)
  - Overwrite issue description

  **Parallelizable**: NO (depends on Task 4)

  **References**:
  - GitHub CLI: `gh issue comment`

  **Acceptance Criteria**:
  - [ ] Comment added to issue #21
  - [ ] Contains: fix summary, screenshots, test evidence
  - [ ] Viewable at: https://github.com/anand-testcompare/sketchi/issues/21

  **Commit**: NO (GitHub operation only)

---

- [x] 6. Create PR, Run CI, Address CodeRabbit Comments

  **What to do**:
  - Create feature branch: `feature/fix-excalidraw-svg-export`
  - Push commits from Tasks 1, 2, 3, 3b
  - Create PR with summary referencing issue #21
  - Wait for CI to complete
  - Review and address valid CodeRabbit comments
  - Confirm CI passes after all fixes
  - Pull latest changes to verify final state

  **Must NOT do**:
  - Force push to main
  - Skip CodeRabbit review
  - Merge without green CI
  - Include Claude/Anthropic branding in PR

  **Parallelizable**: NO (final task)

  **References**:
  - GitHub CLI: `gh pr create`, `gh pr view`, `gh pr checks`
  - AGENTS.md: No Claude branding in PRs

  **Acceptance Criteria**:
  - [ ] PR created: `gh pr create --title "..." --body "..."`
  - [ ] CI runs: `gh pr checks [PR_NUMBER]` shows pending/pass
  - [ ] CodeRabbit comments reviewed
  - [ ] Valid comments addressed (new commits if needed)
  - [ ] Final CI status: all checks green
  - [ ] Pull PR locally: `gh pr checkout [PR_NUMBER]`
  - [ ] Verify all changes present

  **Commit**: Multiple small commits for CodeRabbit fixes
  - Messages: `fix: address coderabbit feedback on [topic]`

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1 | `fix(icon-library): correct excalidraw element format for library import` | svg-to-excalidraw.ts | Manual import to excalidraw.com |
| 2 | `feat(icon-library): add sketchy SVG export using svg2roughjs` | export-button.tsx | Manual export and unzip |
| 3 | `test(e2e): implement icon library export workflow tests` | icon-library-generator-happy-path.ts | `bun run test:e2e` |
| 3b | `refactor(e2e): reduce visual-sanity.ts complexity` | visual-sanity.ts | `bun x ultracite check` |
| 6+ | `fix: address coderabbit feedback on [topic]` | Various | CI pass |

---

## Success Criteria

### Verification Commands
```bash
bun x ultracite check                    # Expected: no errors
bun run build                            # Expected: build succeeds
bun run test:e2e                         # Expected: all tests pass
gh pr checks [PR_NUMBER]                 # Expected: all checks pass
```

### Final Checklist
- [x] All "Must Have" present
- [x] All "Must NOT Have" absent
- [x] E2E tests pass
- [x] CI green
- [x] Issue #21 updated with evidence
- [x] CodeRabbit comments addressed
- [x] PR ready for merge
