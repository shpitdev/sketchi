# Excalidraw V2 Share Link Support

## TL;DR

> **Quick Summary**: Add V2 format support to Excalidraw share link parsing. V2 uses nested buffers with pako compression. Extract shared logic to `@sketchi/shared` package.
> 
> **Deliverables**:
> - New `packages/shared` package with shared parsing logic
> - Updated backend to import from shared
> - Updated MCP plugin to import from shared
> - Tests for V1 backward compatibility + V2 parsing
> 
> **Estimated Effort**: Medium (2-3 hours)
> **Parallel Execution**: YES - 2 waves
> **Critical Path**: Task 1 (shared package) → Tasks 2,3 (consumers) → Task 4 (V2 implementation) → Tasks 5,6 (tests)

---

## Context

### Original Request
GitHub Issue #74: Parsing Excalidraw share links fails with "OperationError" when the link was created using Excalidraw's newer V2 storage format.

### Interview Summary
**Key Discussions**:
- Root cause: Code assumes V1 `[IV][ciphertext]` but Excalidraw now uses V2 with nested buffers + pako compression
- Two files need updating: backend (`packages/backend/convex/lib/`) and MCP plugin (`.opencode/plugins/sketchi/lib/`)
- User decision: Extract shared logic to new `packages/shared` package (proper monorepo pattern)

**Research Findings**:
- V2 format: `[4-byte version][4-byte len][encodingMetadata JSON][4-byte len][IV][4-byte len][ciphertext]`
- FileEncodingInfo: `{"version":2,"compression":"pako@1","encryption":"AES-GCM"}`
- Excalidraw tries V2 first, falls back to V1 on failure
- IV is still 12 bytes; AES-GCM 128-bit key unchanged
- Source: `excalidraw/excalidraw` repo `encode.ts` and `excalidraw-app/data/index.ts`

### Metis Review
**Identified Gaps** (addressed):
- Need real V2 share link for testing → Added task to obtain one
- pako version must be `^1.x` → Specified in task
- Missing AC for build/lint → Added AC5-AC8
- Edge cases (empty scenes, corrupted headers) → Added to test cases

---

## Work Objectives

### Core Objective
Support V2 Excalidraw share link format while maintaining V1 backward compatibility, using shared code via a new monorepo package.

### Concrete Deliverables
- `packages/shared/package.json` - New package configuration
- `packages/shared/src/excalidraw-share-links.ts` - V1+V2 parsing logic with pako decompression
- Updated `packages/backend/convex/lib/excalidrawShareLinks.ts` - Imports from shared
- Updated `.opencode/plugins/sketchi/lib/excalidraw.ts` - Imports from shared
- New tests in `packages/backend/convex/excalidrawShareLinks.test.ts` for V2 scenarios

### Definition of Done
- [ ] `bun run build` passes (all packages build)
- [ ] `bun run check-types` passes (TypeScript compiles)
- [ ] `bun x ultracite check` passes (linting)
- [ ] `cd packages/backend && bun run test` passes (all share link tests)
- [ ] V2 share link from Excalidraw.com parses successfully
- [ ] V1 share links (from our createShareLink) continue to work

### Must Have
- V2 format detection (first 4 bytes == `0x00000001`)
- pako decompression for V2 format
- Fallback to V1 if V2 parsing fails
- Meaningful error messages (not generic "OperationError")
- TypeScript types for all new code

### Must NOT Have (Guardrails)
- **Do NOT** change `createExcalidrawShareLink` to produce V2 format (issue #75 scope)
- **Do NOT** refactor V1 code path beyond adding detection branch
- **Do NOT** add retry/caching logic
- **Do NOT** add `files` blob support (V2 has it but not needed)
- **Do NOT** add support for hypothetical V3 format
- **Do NOT** over-abstract the shared package (parsing only, no summarization)

---

## Verification Strategy (MANDATORY)

### Test Decision
- **Infrastructure exists**: YES (vitest + convex-test)
- **User wants tests**: YES (Tests-after, per issue ACs)
- **Framework**: vitest for convex functions

### Automated Verification

Each TODO includes executable verification procedures:

**For Backend Tests** (convex-test):
```bash
cd packages/backend && bun run test -- --grep "share link"
# Assert: All tests pass including new V2 cases
```

**For Build/Types** (CI verification):
```bash
bun run build && bun run check-types && bun x ultracite check
# Assert: Exit code 0 for all
```

**For MCP Plugin** (manual/stagehand):
- Use `diagram_to_png` tool with a V2 share URL
- Verify PNG renders without errors

---

## Execution Strategy

### Parallel Execution Waves

```
Wave 1 (Start Immediately):
├── Task 1: Create @sketchi/shared package skeleton
└── Task 2: Obtain real V2 share link for testing

Wave 2 (After Wave 1):
├── Task 3: Implement V2 parsing in shared package
└── (blocked until Task 1 complete)

Wave 3 (After Wave 2):
├── Task 4: Update backend to use shared
└── Task 5: Update MCP plugin to use shared

Wave 4 (After Wave 3):
├── Task 6: Add V2 test cases
└── Task 7: Stagehand E2E test for MCP

Wave 5 (Final):
└── Task 8: Final verification and cleanup

Critical Path: Task 1 → Task 3 → Task 4 → Task 6 → Task 8
```

### Dependency Matrix

| Task | Depends On | Blocks | Can Parallelize With |
|------|------------|--------|---------------------|
| 1 | None | 3, 4, 5 | 2 |
| 2 | None | 6 | 1 |
| 3 | 1 | 4, 5 | None |
| 4 | 3 | 6 | 5 |
| 5 | 3 | 7 | 4 |
| 6 | 2, 4 | 8 | 7 |
| 7 | 5 | 8 | 6 |
| 8 | 6, 7 | None | None (final) |

### Agent Dispatch Summary

| Wave | Tasks | Recommended Agents |
|------|-------|-------------------|
| 1 | 1, 2 | quick (skeleton) + quick (web fetch) |
| 2 | 3 | unspecified-high (crypto implementation) |
| 3 | 4, 5 | quick (refactor imports) |
| 4 | 6, 7 | quick (tests) + visual-engineering (e2e) |
| 5 | 8 | quick (verification) |

---

## TODOs

- [x] 1. Create `@sketchi/shared` package skeleton

  **What to do**:
  - Create `packages/shared/package.json` following `packages/env/package.json` pattern
    - MUST include `"exports": { ".": "./src/index.ts" }` for proper module resolution
    - MUST include `"type": "module"`
  - Create `packages/shared/tsconfig.json` extending `@sketchi/config`
  - Create `packages/shared/src/index.ts` that re-exports from `./excalidraw-share-links.ts`
    - This file will be populated with actual exports in Task 3
    - For now, create empty file or placeholder comment
  - Add `pako` dependency (`^1.0.11` - matching Excalidraw's `pako@1` spec)
  - Add `@types/pako` dev dependency
  - Run `bun install` to update lockfile

  **Must NOT do**:
  - Add unnecessary dependencies
  - Skip the `exports` field (Tasks 4/5 depend on it for imports)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Straightforward scaffolding task, <30 min
  - **Skills**: []
    - No specialized skills needed

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Task 2)
  - **Blocks**: Tasks 3, 4, 5
  - **Blocked By**: None

  **References**:

  **Pattern References**:
  - `packages/env/package.json` - Package.json structure for workspace packages (name, exports, type module)
  - `packages/env/tsconfig.json` - TypeScript config extending @sketchi/config

  **API/Type References**:
  - Root `package.json:4-9` - Workspaces configuration showing `packages/*` pattern

  **WHY Each Reference Matters**:
  - `packages/env` is the existing example of a shared package - follow its exact structure

  **Acceptance Criteria**:

  ```bash
  # Verify package exists and installs
  ls packages/shared/package.json && bun install
  # Assert: No errors, lockfile updated
  
  # Verify TypeScript setup
  cd packages/shared && bunx tsc --noEmit
  # Assert: Exit code 0
  ```

  **Commit**: YES
  - Message: `feat(shared): scaffold @sketchi/shared package`
  - Files: `packages/shared/`
  - Pre-commit: `bun install && bun run check-types`

---

- [x] 2. Obtain real V2 share link for testing

  **What to do**:
  - Create directory: `mkdir -p packages/backend/convex/test-fixtures`
  - Go to https://excalidraw.com
  - Draw a simple diagram (rectangle + arrow + text)
  - Click "Share" → "Share Link" to generate a V2 share link
  - Save the URL to `packages/backend/convex/test-fixtures/v2-share-link.txt`
  - Verify it's V2 by checking raw response bytes (should start with version marker)

  **Must NOT do**:
  - Use a mocked/synthetic V2 format
  - Modify the URL in any way
  - Skip the mkdir step (directory does not exist)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Simple browser interaction
  - **Skills**: [`playwright`]
    - `playwright`: Needed to automate Excalidraw interaction

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Task 1)
  - **Blocks**: Task 6
  - **Blocked By**: None

  **References**:

  **External References**:
  - https://excalidraw.com - Target site for share link creation

  **WHY Each Reference Matters**:
  - Need real V2 link from production Excalidraw, not synthetic test data

  **Acceptance Criteria**:

  ```bash
  # Verify file exists with valid URL
  cat packages/backend/convex/test-fixtures/v2-share-link.txt | grep -E '^https://excalidraw.com/#json='
  # Assert: URL matches pattern
  
  # Verify it's actually V2 format (fetch and check first bytes)
  # This will be validated in Task 6 tests
  ```

  **Commit**: YES
  - Message: `test(backend): add V2 share link test fixture`
  - Files: `packages/backend/convex/test-fixtures/v2-share-link.txt`
  - Pre-commit: None

---

- [x] 3. Implement V2 parsing in shared package

  **What to do**:
  - Create `packages/shared/src/excalidraw-share-links.ts`
  - Implement `splitBuffers()` function matching Excalidraw's `encode.ts:254-291`
  - Implement `decompressData()` function matching Excalidraw's `encode.ts:374-412`
  - Implement V2 detection: first 4 bytes == `0x00000001` (big-endian)
  - Implement V1 fallback: try V2 first, catch and try V1 on failure
  - Export `parseExcalidrawShareLink()` and types
  - Use pako `inflate()` for decompression
  - Preserve exact byte offsets from Excalidraw source
  - **Wrap crypto/decompress errors with meaningful messages**:
    - Catch `OperationError` from `crypto.subtle.decrypt` → rethrow as `"Decryption failed: invalid key or corrupted data"`
    - Catch pako inflate errors → rethrow as `"Decompression failed: invalid V2 payload"`
    - Include format version in error messages (e.g., `"V2 parsing failed: ..."`)
  - Update `packages/shared/src/index.ts` to re-export `parseExcalidrawShareLink` and types

  **Must NOT do**:
  - Modify V1 parsing logic (copy existing implementation exactly)
  - Add retry logic or caching
  - Support V3 or future formats
  - Add `files` blob support
  - Let generic `OperationError` bubble up without context

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Crypto implementation requiring precise byte manipulation
  - **Skills**: []
    - No specialized skills needed, but requires careful attention to detail

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential (Wave 2)
  - **Blocks**: Tasks 4, 5
  - **Blocked By**: Task 1

  **References**:

  **Pattern References**:
  - `packages/backend/convex/lib/excalidrawShareLinks.ts:67-103` - Existing V1 parsing implementation to preserve
  - `.opencode/plugins/sketchi/lib/excalidraw.ts:60-97` - Alternative V1 implementation (nearly identical)

  **External References**:
  - Excalidraw `encode.ts:254-291` - `splitBuffers()` implementation with exact byte offsets
  - Excalidraw `encode.ts:374-412` - `decompressData()` flow
  - Excalidraw `encode.ts:161-168` - Constants: `CONCAT_BUFFERS_VERSION=1`, `VERSION_DATAVIEW_BYTES=4`, `NEXT_CHUNK_SIZE_DATAVIEW_BYTES=4`
  - Excalidraw `excalidraw-app/data/index.ts:202-242` - `importFromBackend()` showing try-V2-catch-V1 pattern
  - Excalidraw `encryption.ts:5-48` - `IV_LENGTH_BYTES=12`, key import params

  **WHY Each Reference Matters**:
  - Existing V1 code shows exact API shape to preserve
  - Excalidraw source provides authoritative byte offsets - must match exactly or decryption fails
  - `importFromBackend` shows the fallback pattern used in production

  **Acceptance Criteria**:

  ```bash
  # Verify module compiles
  cd packages/shared && bunx tsc --noEmit
  # Assert: Exit code 0
  
  # Verify exports are correct
  bun -e "import { parseExcalidrawShareLink } from './packages/shared/src/excalidraw-share-links'; console.log(typeof parseExcalidrawShareLink)"
  # Assert: Output is "function"
  ```

  **Commit**: YES
  - Message: `feat(shared): implement V2 share link parsing with V1 fallback`
  - Files: `packages/shared/src/excalidraw-share-links.ts`
  - Pre-commit: `cd packages/shared && bunx tsc --noEmit`

---

- [x] 4. Update backend to use shared package

  **What to do**:
  - Add `@sketchi/shared: workspace:*` to `packages/backend/package.json` dependencies
  - Update `packages/backend/convex/lib/excalidrawShareLinks.ts` to import `parseExcalidrawShareLink` from `@sketchi/shared`
  - Keep `createExcalidrawShareLink` in backend (not shared - it's V1 only)
  - Remove the old `parseExcalidrawShareLink` implementation (now imported)
  - Update exports if needed

  **Must NOT do**:
  - Move `createExcalidrawShareLink` to shared (stays in backend)
  - Change any behavior - just change where the code lives

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Import refactoring, straightforward
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Task 5)
  - **Blocks**: Task 6
  - **Blocked By**: Task 3

  **References**:

  **Pattern References**:
  - `packages/backend/package.json:16-31` - Dependencies section to update
  - `packages/backend/convex/lib/excalidrawShareLinks.ts` - File to update

  **WHY Each Reference Matters**:
  - Need to add workspace dependency and update imports

  **Acceptance Criteria**:

  ```bash
  # Verify existing tests still pass
  cd packages/backend && bun run test -- --grep "share link"
  # Assert: Round-trip test passes (V1 still works)
  
  # Verify TypeScript compiles (run from repo root)
  bun run check-types
  # Assert: Exit code 0 (note: this runs at monorepo level, not in packages/backend)
  ```

  **Commit**: YES
  - Message: `refactor(backend): use @sketchi/shared for share link parsing`
  - Files: `packages/backend/package.json`, `packages/backend/convex/lib/excalidrawShareLinks.ts`
  - Pre-commit: `cd packages/backend && bun run test -- --grep "share link"`

---

- [x] 5. Update MCP plugin to use shared package

  **What to do**:
  - Add `@sketchi/shared: workspace:*` to `.opencode/package.json` dependencies
  - Update `.opencode/plugins/sketchi/lib/excalidraw.ts` to import `parseExcalidrawShareLink` from `@sketchi/shared`
  - Remove the old `parseExcalidrawShareLink` implementation
  - Keep other functions (`readExcalidrawFile`, `summarizeElements`, etc.) in place

  **Must NOT do**:
  - Move any other functions to shared
  - Change `extractShareLink` function (it's fine where it is)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Import refactoring, straightforward
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Task 4)
  - **Blocks**: Task 7
  - **Blocked By**: Task 3

  **References**:

  **Pattern References**:
  - `.opencode/package.json` - Dependencies section to update
  - `.opencode/plugins/sketchi/lib/excalidraw.ts:60-97` - Old implementation to remove

  **WHY Each Reference Matters**:
  - Need to update imports and remove duplicated code

  **Acceptance Criteria**:

  ```bash
  # Verify TypeScript compiles
  cd .opencode && bunx tsc --noEmit
  # Assert: Exit code 0
  
  # Verify package installs
  bun install
  # Assert: No errors
  ```

  **Commit**: YES
  - Message: `refactor(opencode): use @sketchi/shared for share link parsing`
  - Files: `.opencode/package.json`, `.opencode/plugins/sketchi/lib/excalidraw.ts`
  - Pre-commit: `bun install && bun run check-types`

---

- [x] 6. Add V2 test cases to backend

  **What to do**:
  - Update `packages/backend/convex/excalidrawShareLinks.test.ts`
  - Add test: "parses V2 format share link" using fixture from Task 2
    - Read URL from `packages/backend/convex/test-fixtures/v2-share-link.txt`
    - Call `parseShareLinkToElements` and verify `elements` array returned
  - Add test: "V2 parsing error message is meaningful" 
    - Use corrupted/invalid V2 data to trigger error
    - Assert error message contains context (not generic "OperationError")

  **Must NOT do**:
  - Mock the V2 format - use real URL from fixture
  - Remove or modify existing tests
  - Re-add V1 round-trip test (already exists at line 275)
  - Re-add invalid URL test (already exists at line 340)
  - Add empty-scene test (would require separate real fixture)

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Test additions following existing patterns
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 4 (with Task 7)
  - **Blocks**: Task 8
  - **Blocked By**: Tasks 2, 4

  **References**:

  **Pattern References**:
  - `packages/backend/convex/excalidrawShareLinks.test.ts` - Existing test file with patterns to follow
  - `packages/backend/convex/excalidrawShareLinks.test.ts:275-338` - V1 round-trip test (ALREADY EXISTS - do not duplicate)
  - `packages/backend/convex/excalidrawShareLinks.test.ts:340-346` - Invalid URL test (ALREADY EXISTS - do not duplicate)

  **Test References**:
  - `packages/backend/convex/test-fixtures/v2-share-link.txt` - V2 URL fixture (from Task 2)

  **WHY Each Reference Matters**:
  - Follow existing test patterns for consistency
  - Use real V2 URL to validate actual format support
  - Existing V1 tests already cover backward compatibility - just verify they still pass

  **Acceptance Criteria**:

  ```bash
  cd packages/backend && bun run test -- --grep "share link"
  # Assert: All tests pass including new V2 test
  # Assert: Test output shows "parses V2 format" test ran
  # Assert: Existing round-trip and invalid URL tests still pass
  ```

  **Commit**: YES
  - Message: `test(backend): add V2 share link parsing tests`
  - Files: `packages/backend/convex/excalidrawShareLinks.test.ts`
  - Pre-commit: `cd packages/backend && bun run test -- --grep "share link"`

---

- [x] 7. Add Stagehand E2E test for MCP V2 support (AC3)

  **What to do**:
  - Create `tests/e2e/src/scenarios/unauthenticated/mcp-v2-share-link.ts`
  - Test scenario: Use `diagram_to_png` tool with V2 share URL
  - Verify PNG is generated without errors
  - Add scenario description comment at top
  - Add script entry to `tests/e2e/package.json`: `"mcp-v2-share-link": "bun run src/scenarios/unauthenticated/mcp-v2-share-link.ts"`

  **Must NOT do**:
  - Test complex scenarios - just verify V2 parsing works via MCP
  - Place file in wrong location (must be under `src/scenarios/unauthenticated/`)

  **Recommended Agent Profile**:
  - **Category**: `visual-engineering`
    - Reason: E2E test with visual verification
  - **Skills**: [`playwright`]
    - `playwright`: Stagehand E2E tests use Playwright

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 4 (with Task 6)
  - **Blocks**: Task 8
  - **Blocked By**: Task 5

  **References**:

  **Pattern References**:
  - `tests/e2e/src/scenarios/unauthenticated/visual-sanity.ts` - Existing Stagehand test pattern (file structure, imports, Stagehand setup)
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts` - Alternative pattern for reference
  - `tests/e2e/package.json:4-7` - Script entry format: `"name": "bun run src/scenarios/unauthenticated/name.ts"`

  **Documentation References**:
  - README.md "Testing" section - Stagehand E2E setup instructions

  **WHY Each Reference Matters**:
  - `visual-sanity.ts` shows exact file structure and Stagehand initialization pattern
  - `package.json` shows script entry format needed to make `bun run mcp-v2-share-link` work

  **Acceptance Criteria**:

  ```bash
  # Verify script entry exists
  grep "mcp-v2-share-link" tests/e2e/package.json
  # Assert: Script entry found
  
  # Run the E2E test
  cd tests/e2e && bun run mcp-v2-share-link
  # Assert: Test passes, PNG file created
  # Assert: No "OperationError" in output
  ```

  **Commit**: YES
  - Message: `test(e2e): add MCP V2 share link E2E test`
  - Files: `tests/e2e/src/scenarios/unauthenticated/mcp-v2-share-link.ts`, `tests/e2e/package.json`
  - Pre-commit: None (E2E tests run separately)

---

- [x] 8. Final verification and cleanup

  **What to do**:
  - Run full test suite: `cd packages/backend && bun run test`
  - Run full build: `bun run build`
  - Run type check: `bun run check-types`
  - Run linter: `bun x ultracite check`
  - Update issue #74 with completion status
  - Close issue or add completion comment

  **Must NOT do**:
  - Add new features
  - Refactor working code

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Verification commands only
  - **Skills**: [`git-master`]
    - `git-master`: For proper commit and issue update

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential (Wave 5, final)
  - **Blocks**: None (final task)
  - **Blocked By**: Tasks 6, 7

  **References**:

  **Documentation References**:
  - Issue #74 - Update with completion status

  **Acceptance Criteria**:

  ```bash
  # Full verification suite
  bun run build
  # Assert: Exit code 0
  
  bun run check-types
  # Assert: Exit code 0
  
  bun x ultracite check
  # Assert: Exit code 0
  
  cd packages/backend && bun run test
  # Assert: All tests pass
  
  # Verify V2 parsing works end-to-end
  # (already covered by tests, but confirm manually if needed)
  ```

  **Commit**: NO (verification only)

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1 | `feat(shared): scaffold @sketchi/shared package` | `packages/shared/` | `bun install && bun run check-types` |
| 2 | `test(backend): add V2 share link test fixture` | `packages/backend/convex/test-fixtures/` | None |
| 3 | `feat(shared): implement V2 share link parsing with V1 fallback` | `packages/shared/src/` | `bunx tsc --noEmit` |
| 4 | `refactor(backend): use @sketchi/shared for share link parsing` | `packages/backend/` | `bun run test` |
| 5 | `refactor(opencode): use @sketchi/shared for share link parsing` | `.opencode/` | `bun run check-types` |
| 6 | `test(backend): add V2 share link parsing tests` | `packages/backend/convex/` | `bun run test` |
| 7 | `test(e2e): add MCP V2 share link E2E test` | `tests/e2e/` | Manual E2E run |
| 8 | No commit (verification only) | - | - |

---

## Success Criteria

### Verification Commands
```bash
# Build passes
bun run build  # Expected: Exit 0

# Types compile
bun run check-types  # Expected: Exit 0

# Linting passes
bun x ultracite check  # Expected: Exit 0

# All backend tests pass
cd packages/backend && bun run test  # Expected: All pass, including V2 tests

# V2 share link parses (manual check)
# Use the MCP diagram_to_png tool with a V2 URL
# Expected: PNG renders without OperationError
```

### Final Checklist
- [ ] All "Must Have" present (V2 detection, pako decompression, V1 fallback)
- [ ] All "Must NOT Have" absent (no V2 creation, no retry logic, no V3 support)
- [ ] All tests pass (backend + E2E)
- [ ] Issue #74 ACs met:
  - [ ] AC1: V2 share links parse successfully
  - [ ] AC2: V1 share links continue to work
  - [ ] AC3: MCP tools work with V2 links
  - [ ] AC4: Invalid URLs error gracefully
  - [ ] AC5: Shared package builds
  - [ ] AC6: TypeScript compiles
  - [ ] AC7: Error messages are meaningful
  - [ ] AC8: Linting passes
