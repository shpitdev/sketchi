# Diagram Templates + Visual Testing (Issue #10)

## TL;DR

> **Quick Summary**: Fix arrow binding integrity (P0 bug), then add diagram-type templates with autofill, and extend visual validation suite.
> 
> **Deliverables**:
> - P0: `normalizeArrowBindings()` function ensuring bidirectional binding
> - P1: Templates for flowchart, architecture, mindmap, sequence in `packages/backend/lib/templates/`
> - P2: `applyTemplateDefaults()` autofill utility
> - P3: Extended visual grading tests for template scenarios
> 
> **Estimated Effort**: Medium (10-14 hours)
> **Parallel Execution**: YES - 4 waves
> **Critical Path**: P0 (binding fix) → P1 (templates) → P2 (autofill + pipeline integration) → P3 (tests)

---

## Context

### Original Request
[GitHub Issue #10](https://github.com/anand-testcompare/sketchi/issues/10): Build a template-driven, deterministic pipeline where the LLM outputs minimal semantic structure (IntermediateFormat), and the renderer + templates handle layout/styling/type semantics. Add systematic visual validation.

### Interview Summary
**Key Discussions**:
- P0 (arrow binding) is a **blocker** - arrows are not truly bound to shapes in exported JSON
- Templates should be TypeScript in `packages/backend/lib` (not Convex yet)
- Direct Excalidraw element modification must remain supported
- Visual validation uses existing grader from Issue #5 (already merged)

**Repo Constraints**:
- Shared logic (templates, graders, render helpers) must live in `packages/backend/lib`; Convex should stay thin

**Research Findings**:
- Root cause: `buildShapeElements()` runs BEFORE `buildArrowElements()` in `convertLayoutedToExcalidraw()` - arrows don't exist when shapes are built
- Test fixture `excalidrawShareLinks.test.ts:38-41` shows correct bidirectional binding structure
- Existing `LAYOUT_CONFIGS` in `diagram-layout.ts` already define per-type settings (can extend for templates)

### Metis Review
**Identified Gaps** (addressed):
- Normalization pass location decided: post-processing step in `convertLayoutedToExcalidraw()`
- Edge cases defined: self-referencing arrows, multiple arrows between same shapes, dangling ends
- Template scope locked: flowchart, architecture, mindmap, sequence only
- E2E acceptance criteria added for drag-binding behavior

---

## Issue Acceptance Criteria Mapping (from GitHub Issue #10)

### P0 Acceptance Criteria
| Issue AC | Plan Task | Verification |
|----------|-----------|--------------|
| Exported arrows are bound to shapes (arrow has `startBinding`/`endBinding`, shapes list arrow ids in `boundElements`) | Task 1 | Unit test: `cd packages/backend && bun run test -- lib/excalidraw-elements.test.ts` |
| Manual check: dragging bound shape keeps arrow endpoints attached | Task 10 | E2E test: Extract scene JSON before/after drag, assert arrow endpoint coords changed |

### P0 Test Scenarios (from issue)
| Scenario | Plan Task | How Verified |
|----------|-----------|--------------|
| Simple two-node flowchart where dragging either node keeps arrow attached | Task 10 | E2E scene extraction + coord diff |
| Labelled shape with outbound arrow; `boundElements` retains text + arrow bindings | Task 1 | Unit test case: shape with text + arrow has both in boundElements |

### P1/P2 Acceptance Criteria
| Issue AC | Plan Task | Verification |
|----------|-----------|--------------|
| Diagram type templates exist for: flowchart, architecture, mindmap, sequence | Tasks 2-6 | `cd packages/backend && bun -e "import { getTemplateForType } from './lib/templates'; ..."` |
| Deterministic autofill uses templates to minimize LLM burden | Tasks 7-8 | Unit test + pipeline integration test |
| Optional: `diagramTypeData` for type-specific semantics | Tasks 2-6 | Templates include `kindToShapeMap` for semantic mapping |

### P1/P2 Test Scenarios (from issue)
| Scenario | Plan Task | How Verified |
|----------|-----------|--------------|
| Mindmap with central topic + branches (template + autofill) | Task 9 | Visual grading scenario |
| Sequence diagram with 3 participants + 5 messages (template + autofill) | Task 9 | Visual grading scenario |

### P3 Acceptance Criteria
| Issue AC | Plan Task | Verification |
|----------|-----------|--------------|
| Visual validation uses real grader from Issue #5 (no mocks) | Task 9 | Uses existing `gradeByChartType()` from `lib/grading.ts` |
| Diagram-specific grader prompts exist and are used | Task 9 | Each scenario has chartType; grader uses type-specific prompt |
| Advanced scenarios use grader and produce pass/fail artifacts | Task 9 | Test outputs to `test-results/*.json` + `*.png` |
| Tests write artifacts in `packages/backend/test-results/` (no committed PNGs) | Task 9 | `.gitignore` already excludes; verified via `ls test-results/` |
| CI artifacts published as `test-results-packages-backend-convex-YYYYMMDD-HHMMSS` | Task 9 | GitHub Actions workflow handles artifact upload |

### P3 Test Scenarios (from issue)
| Scenario | Plan Task | How Verified |
|----------|-----------|--------------|
| Architecture: 15+ components (visual grader pass/fail) | Task 9 | Extend architecture scenario to >= 15 nodes |

---

## Work Objectives

### Core Objective
Fix arrow binding integrity so dragging shapes in Excalidraw web keeps arrows attached, then add per-diagram-type templates with autofill behavior, validated by visual grading tests.

### Concrete Deliverables
- `packages/backend/lib/excalidraw-elements.ts` - `normalizeArrowBindings()` function
- `packages/backend/lib/templates/` - Template definitions for 4 diagram types
- `packages/backend/lib/template-autofill.ts` - Autofill utility
- `packages/backend/convex/visualGrading.test.ts` - Extended test scenarios

### Definition of Done
- [ ] `cd packages/backend && bun run test` passes (all backend tests)
- [ ] `cd packages/backend && bun run test -- convex/visualGrading.test.ts` passes (>=6 scenarios, allows 1 failure)
- [ ] Exported diagrams have bidirectional binding (arrow.binding ↔ shape.boundElements)
- [ ] Templates integrated into production pipeline via `renderIntermediateDiagram()`
- [ ] E2E test confirms arrow endpoint follows shape drag in Excalidraw web

### Must Have
- Bidirectional arrow-shape binding in all generated diagrams
- Templates for: flowchart, architecture, mindmap, sequence
- Autofill missing IntermediateFormat fields from templates
- Visual grading for template scenarios

### Must NOT Have (Guardrails)
- NO template storage in Convex (per issue out-of-scope)
- NO template selection UI
- NO "smart" auto-detecting diagram type from content
- NO changes to IntermediateFormat schema
- NO changes to existing grading schemas in `grading.ts`
- NO template inheritance or composition
- NO more than 4 template types initially
- DO NOT remove or block direct Excalidraw element modification paths

### Dependencies
- P3 (visual grading) must land after Issue #5 (visual grader) is merged

---

## Verification Strategy (MANDATORY)

### Test Decision
- **Infrastructure exists**: YES (vitest + convex-test)
- **User wants tests**: YES (issue explicitly requires visual validation)
- **Framework**: vitest + stagehand for E2E
- **QA approach**: TDD for P0, visual grading for P1-P3

### TDD for P0 (Binding Fix)

Each task follows RED-GREEN-REFACTOR:

**Task Structure:**
1. **RED**: Write failing test first
   - Test file: `packages/backend/lib/excalidraw-elements.test.ts`
   - Test command: `cd packages/backend && bun run test -- lib/excalidraw-elements.test.ts`
   - Expected: FAIL (binding not bidirectional yet)
2. **GREEN**: Implement `normalizeArrowBindings()`
   - Command: `cd packages/backend && bun run test -- lib/excalidraw-elements.test.ts`
   - Expected: PASS
3. **REFACTOR**: Optimize if needed (Map-based index)

### Visual Validation (P1-P3)

Use existing `gradeByChartType()` with diagram-specific prompts. Artifacts stored in `packages/backend/test-results/`.

---

## Template Defaults Data Flow (CRITICAL)

**This section explains how template `nodeDefaults`/`edgeDefaults` actually affect rendered elements.**

### Current Pipeline (without templates)
```
IntermediateFormat → layoutIntermediateDiagram() → convertLayoutedToExcalidraw() → elements[]
                     ↓                              ↓
                     Uses LAYOUT_CONFIGS            Uses hardcoded StyleConfig
```

### Target Pipeline (with templates)
```
IntermediateFormat → applyTemplateDefaults() → normalize elements + bindings → layoutIntermediateDiagram() → convertLayoutedToExcalidraw(style) → elements[]
                     ↓                         ↓                              ↓
                     Merges template into      Uses layout from               Uses style from
                     graphOptions + sets       enriched graphOptions          template via style param
                     style context
```

### Data Flow Mapping

| Template Field | Intermediate/Layout Field | Element Field |
|----------------|---------------------------|---------------|
| `template.layout.direction` | `intermediate.graphOptions.layout.direction` | dagre `rankdir` |
| `template.layout.nodesep` | `intermediate.graphOptions.layout.nodesep` | dagre `nodesep` |
| `template.nodeDefaults.fill` | `intermediate.graphOptions.style.shapeFill` | `element.backgroundColor` |
| `template.nodeDefaults.stroke` | `intermediate.graphOptions.style.shapeStroke` | `element.strokeColor` |
| `template.edgeDefaults.stroke` | `intermediate.graphOptions.style.arrowStroke` | Arrow `strokeColor` |
| `template.kindToShapeMap[kind]` | `node.metadata.shape` | `element.type` (rectangle/ellipse/diamond) |
| `template.nodeDefaults.width` | `node.metadata.width` (filled by defaults) | `shape.width` → element `width` |
| `template.nodeDefaults.height` | `node.metadata.height` (filled by defaults) | `shape.height` → element `height` |
| `template.edgeDefaults.arrowhead` | passed to `convertLayoutedToExcalidraw()` | Arrow `endArrowhead` |

### Implementation in `applyTemplateDefaults()`

```typescript
// packages/backend/lib/template-autofill.ts
export function applyTemplateDefaults(
  intermediate: IntermediateFormat,
  template: DiagramTemplate
): IntermediateFormat {
  return {
    ...intermediate,
    nodes: intermediate.nodes.map((node) => {
      const kind = node.kind?.toLowerCase();
      const mappedShape =
        kind && template.kindToShapeMap[kind]
          ? template.kindToShapeMap[kind]
          : undefined;
      return {
        ...node,
        metadata: {
          ...node.metadata,
          shape: node.metadata?.shape ?? mappedShape,
          width: node.metadata?.width ?? template.nodeDefaults.width,
          height: node.metadata?.height ?? template.nodeDefaults.height,
        },
      };
    }),
    graphOptions: {
      ...intermediate.graphOptions,
      // Layout defaults (explicit values win)
      layout: {
        direction: intermediate.graphOptions?.layout?.direction ?? template.layout.direction,
        nodesep: intermediate.graphOptions?.layout?.nodesep ?? template.layout.nodesep,
        ranksep: intermediate.graphOptions?.layout?.ranksep ?? template.layout.ranksep,
        edgeRouting: intermediate.graphOptions?.layout?.edgeRouting ?? template.layout.edgeRouting,
      },
      // Style defaults (this is where nodeDefaults/edgeDefaults flow into the pipeline)
      style: {
        shapeFill: intermediate.graphOptions?.style?.shapeFill ?? template.nodeDefaults.fill,
        shapeStroke: intermediate.graphOptions?.style?.shapeStroke ?? template.nodeDefaults.stroke,
        arrowStroke: intermediate.graphOptions?.style?.arrowStroke ?? template.edgeDefaults.stroke,
        // ... other style fields
      },
    },
  };
}
```

### Verification: Template Defaults Actually Applied

The acceptance criteria for Task 8 includes this verification:
```bash
cd packages/backend && bun -e "import { renderIntermediateDiagram } from './lib/diagram-renderer'; const result = renderIntermediateDiagram({ nodes: [{ id: 'a', label: 'A' }], edges: [], graphOptions: { diagramType: 'architecture' } }); console.log(JSON.stringify(result.elements[0], null, 2));"
# Assert: backgroundColor === "#d0bfff" (architecture purple)
# Assert: strokeColor === "#7950f2" (architecture stroke)
```

If this assertion fails, templates are no-ops and the data flow is broken.

---

## Execution Strategy

### Parallel Execution Waves

```
Wave 1 (Start Immediately):
├── Task 1: P0 - Arrow binding normalization (CRITICAL PATH)
└── (none parallelizable - P0 is foundation)

Wave 2 (After Wave 1):
├── Task 2: P1 - Flowchart template
├── Task 3: P1 - Architecture template  
├── Task 4: P1 - Mindmap template
├── Task 5: P1 - Sequence template
└── Task 6: P1 - Template index and types

Wave 3 (After Wave 2):
├── Task 7: P2 - Autofill utility
└── Task 8: P2 - Pipeline integration (wire templates into renderIntermediateDiagram)

Wave 4 (After Wave 3):
├── Task 9: P3 - Extend visual grading tests
└── Task 10: P3 - E2E drag-binding test

Critical Path: Task 1 → Task 2 → Task 6 → Task 7 → Task 8 → Task 9
```

### Dependency Matrix

| Task | Depends On | Blocks | Can Parallelize With |
|------|------------|--------|---------------------|
| 1 (P0 binding) | None | 2-10 | None (foundation) |
| 2 (flowchart template) | 1 | 6, 7 | 3, 4, 5 |
| 3 (architecture template) | 1 | 6, 7 | 2, 4, 5 |
| 4 (mindmap template) | 1 | 6, 7 | 2, 3, 5 |
| 5 (sequence template) | 1 | 6, 7 | 2, 3, 4 |
| 6 (template index) | 2, 3, 4, 5 | 7 | None |
| 7 (autofill utility) | 6 | 8 | None |
| 8 (pipeline integration) | 7 | 9 | None |
| 9 (visual tests) | 8 | None | 10 |
| 10 (E2E drag test) | 1 | None | 9 |

### Agent Dispatch Summary

| Wave | Tasks | Recommended Approach |
|------|-------|-------------------|
| 1 | 1 | `category="unspecified-low"` - bug fix, well-scoped |
| 2 | 2, 3, 4, 5, 6 | `category="quick"` - template definitions |
| 3 | 7, 8 | `category="unspecified-low"` - utility functions |
| 4 | 9, 10 | `category="unspecified-high"` - testing, E2E |

---

## TODOs

### P0: Arrow Binding Integrity

- [x] 1. Fix bidirectional arrow-shape binding

  **What to do**:
  - Add `normalizeArrowBindings(elements: Record<string, unknown>[])` function after line 253 in `excalidraw-elements.ts`
  - Build `arrowsByShape: Map<shapeId, {id, type}[]>` by iterating arrow elements
  - For each arrow, extract `startBinding.elementId` and `endBinding.elementId`
  - For each shape element, merge arrow bindings into existing `boundElements` array
  - Call `normalizeArrowBindings()` at end of `convertLayoutedToExcalidraw()`
  - Handle edge cases:
    - Self-referencing arrows: same arrow ID appears once (not twice)
    - Multiple arrows between same shapes: all arrow IDs in list
    - Dangling arrows (missing shape): skip, don't crash
    - Preserve existing text bindings

  **Must NOT do**:
  - Change arrow structure (`startBinding`/`endBinding`)
  - Modify shape structure beyond adding to `boundElements`
  - Remove or overwrite existing text bindings

  **Recommended Agent Profile**:
  - **Category**: `unspecified-low`
    - Reason: Well-scoped bug fix, clear implementation path
  - **Skills**: `[]`
    - No special skills needed - pure TypeScript transformation
  - **Skills Evaluated but Omitted**:
    - `frontend-ui-ux`: Not UI work
    - `playwright`: Not browser automation (yet)

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 1 (solo)
  - **Blocks**: Tasks 2-8 (all subsequent work)
  - **Blocked By**: None (can start immediately)

  **References** (CRITICAL):

  **Pattern References**:
  - `packages/backend/lib/excalidraw-elements.ts:47-127` - Shape building pattern (preserve style)
  - `packages/backend/lib/excalidraw-elements.ts:129-235` - Arrow building pattern (extract binding info)
  - `packages/backend/lib/excalidraw-elements.ts:237-254` - Current conversion flow (add normalization at end)

  **API/Type References**:
  - `packages/backend/lib/excalidraw-elements.ts:75` - `boundElements` type: `{ id: string; type: string }[] | null`
  - `packages/backend/lib/excalidraw-elements.ts:166-177` - Arrow binding structure to extract from

  **Test References**:
  - `packages/backend/convex/excalidrawShareLinks.test.ts:38-41` - **Correct bidirectional structure** to replicate:
    ```typescript
    boundElements: [
      { id: "rect-1-text", type: "text" },
      { id: "arrow-1", type: "arrow" },  // <-- This is missing currently
    ],
    ```

  **Documentation References**:
  - Excalidraw binding spec: https://docs.excalidraw.com/docs/@excalidraw/excalidraw/api/excalidraw-element-skeleton#arrow-bindings

  **WHY Each Reference Matters**:
  - `excalidraw-elements.ts:47-127`: Follow same code style for new function
  - `excalidrawShareLinks.test.ts:38-41`: This is the EXPECTED output structure
  - Excalidraw docs: Confirms bidirectional binding requirement

  **Acceptance Criteria**:

  **TDD (tests enabled):**
  - [ ] Test file created: `packages/backend/lib/excalidraw-elements.test.ts`
  - [ ] Test covers: shape with arrow has arrow ID in boundElements
  - [ ] Test covers: shape with text + arrow has both in boundElements
  - [ ] Test covers: self-referencing arrow appears once
  - [ ] `bun run test -- packages/backend/lib/excalidraw-elements.test.ts` → PASS

  **Automated Verification:**
  ```bash
  # Agent runs after implementation (standardized: always cd first):
  cd packages/backend && bun run test -- convex/diagramGenerateFromIntermediate.test.ts
  # Assert: Exit code 0, all tests pass
  
  # Verify binding structure in test output:
  cd packages/backend && cat test-results/visual-grading-simple-flowchart-diagram.json | \
    jq '.diagram.elements[] | select(.type == "rectangle") | .boundElements[] | select(.type == "arrow")'
  # Assert: Non-empty output (arrows exist in shape.boundElements)
  ```

  **Evidence to Capture:**
  - [ ] Terminal output from test run showing PASS
  - [ ] JSON snippet showing arrow ID in shape.boundElements

  **Commit**: YES
  - Message: `fix(backend): add bidirectional arrow-shape binding normalization`
  - Files: `packages/backend/lib/excalidraw-elements.ts`, `packages/backend/lib/excalidraw-elements.test.ts`
  - Pre-commit: `bun run test -- packages/backend/lib/excalidraw-elements.test.ts`

---

### P1: Per-Diagram-Type Templates

- [ ] 2. Create flowchart template

  **What to do**:
  - Create `packages/backend/lib/templates/flowchart.ts`
  - Export `FlowchartTemplate` with:
    - `diagramType: "flowchart"`
    - `layout: { direction: "TB", nodesep: 80, ranksep: 100, edgeRouting: "straight" }`
    - `nodeDefaults: { shapeType: "rectangle", width: 180, height: 80, fill: "#a5d8ff", stroke: "#1971c2" }`
    - `edgeDefaults: { stroke: "#1971c2", arrowhead: "arrow" }`
    - `kindToShapeMap: { start: "ellipse", end: "ellipse", decision: "diamond", process: "rectangle" }`
  - Export type `DiagramTemplate` interface

  **Must NOT do**:
  - Add template selection logic
  - Store template in Convex
  - Add more than defined fields

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Single file creation, clear structure
  - **Skills**: `[]`
  - **Skills Evaluated but Omitted**:
    - None needed - data definition only

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 3, 4, 5)
  - **Blocks**: Task 6 (autofill needs templates)
  - **Blocked By**: Task 1 (need binding fix first)

  **References**:

  **Pattern References**:
  - `packages/backend/lib/diagram-layout.ts:43-50` - Existing flowchart config structure
  - `packages/backend/lib/excalidraw-elements.ts:35-45` - Style config structure

  **WHY Each Reference Matters**:
  - `diagram-layout.ts:43-50`: Base layout values to include
  - `excalidraw-elements.ts:35-45`: Style defaults to align with

  **Acceptance Criteria**:

  **Automated Verification:**
  ```bash
  # Agent runs (from packages/backend):
  cd packages/backend && bun -e "import { FlowchartTemplate } from './lib/templates/flowchart'; console.log(JSON.stringify(FlowchartTemplate, null, 2))"
  # Assert: Output contains diagramType, layout, nodeDefaults, edgeDefaults, kindToShapeMap
  
  # Type check:
  cd packages/backend && bun run check-types
  # Assert: Exit code 0
  ```

  **Evidence to Capture:**
  - [ ] Template JSON structure output
  - [ ] Type check passing

  **Commit**: YES (group with 3, 4, 5)
  - Message: `feat(backend): add diagram templates (flowchart, architecture, mindmap, sequence)`
  - Files: `packages/backend/lib/templates/*.ts`
  - Pre-commit: `bun run check-types`

---

- [ ] 3. Create architecture template

  **What to do**:
  - Create `packages/backend/lib/templates/architecture.ts`
  - Export `ArchitectureTemplate` with:
    - `diagramType: "architecture"`
    - `layout: { direction: "TB", nodesep: 100, ranksep: 150, edgeRouting: "elbow" }`
    - `nodeDefaults: { shapeType: "rectangle", width: 200, height: 100, fill: "#d0bfff", stroke: "#7950f2" }`
    - `edgeDefaults: { stroke: "#7950f2", arrowhead: "arrow" }`
    - `kindToShapeMap: { component: "rectangle", database: "rectangle", service: "rectangle", client: "ellipse" }`

  **Must NOT do**:
  - Same guardrails as Task 2

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 2, 4, 5)
  - **Blocks**: Task 6
  - **Blocked By**: Task 1

  **References**:
  - `packages/backend/lib/diagram-layout.ts:58-64` - Architecture config
  - Task 2 template structure (follow same pattern)

  **Acceptance Criteria**:
  Same verification pattern as Task 2:
  ```bash
  cd packages/backend && bun -e "import { ArchitectureTemplate } from './lib/templates/architecture'; console.log(JSON.stringify(ArchitectureTemplate, null, 2))"
  ```

  **Commit**: YES (group with 2, 4, 5)

---

- [ ] 4. Create mindmap template

  **What to do**:
  - Create `packages/backend/lib/templates/mindmap.ts`
  - Export `MindmapTemplate` with:
    - `diagramType: "mindmap"`
    - `layout: { direction: "LR", nodesep: 60, ranksep: 150, edgeRouting: "straight" }`
    - `nodeDefaults: { shapeType: "ellipse", width: 150, height: 60, fill: "#ffc078", stroke: "#fd7e14" }`
    - `edgeDefaults: { stroke: "#fd7e14", arrowhead: null }` (mindmaps often no arrowhead)
    - `kindToShapeMap: { root: "ellipse", topic: "ellipse", subtopic: "ellipse" }`
  - Note: mindmap uses radial layout, but template provides defaults for non-radial fallback

  **Must NOT do**:
  - Same guardrails as Task 2

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 2, 3, 5)
  - **Blocks**: Task 6
  - **Blocked By**: Task 1

  **References**:
  - `packages/backend/lib/diagram-layout.ts:65-71` - Mindmap config
  - `packages/backend/lib/diagram-layout-radial.ts` - Radial layout (FYI, not for template)

  **Acceptance Criteria**:
  Same verification pattern as Task 2.

  **Commit**: YES (group with 2, 3, 5)

---

- [ ] 5. Create sequence template

  **What to do**:
  - Create `packages/backend/lib/templates/sequence.ts`
  - Export `SequenceTemplate` with:
    - `diagramType: "sequence"`
    - `layout: { direction: "LR", nodesep: 120, ranksep: 80, edgeRouting: "straight" }`
    - `nodeDefaults: { shapeType: "rectangle", width: 120, height: 60, fill: "#b2f2bb", stroke: "#40c057" }`
    - `edgeDefaults: { stroke: "#40c057", arrowhead: "arrow" }`
    - `kindToShapeMap: { participant: "rectangle", lifeline: "rectangle", activation: "rectangle" }`

  **Must NOT do**:
  - Same guardrails as Task 2

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 2, 3, 4)
  - **Blocks**: Task 6
  - **Blocked By**: Task 1

  **References**:
  - `packages/backend/lib/diagram-layout.ts:72-78` - Sequence config

  **Acceptance Criteria**:
  Same verification pattern as Task 2.

  **Commit**: YES (group with 2, 3, 4)

---

- [ ] 6. Create template index and types

  **What to do**:
  - Create `packages/backend/lib/templates/index.ts` barrel file
  - Export all templates + `DiagramTemplate` type
  - Export `getTemplateForType(diagramType: string): DiagramTemplate` utility
  - Fallback to flowchart for unknown types

  **Must NOT do**:
  - Add template selection UI logic
  - Add template validation

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: After Wave 2
  - **Blocks**: Task 7 (autofill)
  - **Blocked By**: Tasks 2, 3, 4, 5

  **References**:
  - Tasks 2-5 template files

  **Acceptance Criteria**:
  ```bash
  cd packages/backend && bun -e "import { getTemplateForType } from './lib/templates'; console.log(getTemplateForType('flowchart').diagramType)"
  # Assert: "flowchart"
  
  cd packages/backend && bun -e "import { getTemplateForType } from './lib/templates'; console.log(getTemplateForType('unknown').diagramType)"
  # Assert: "flowchart" (fallback)
  ```

  **Commit**: YES
  - Message: `feat(backend): add template index and getTemplateForType utility`
  - Files: `packages/backend/lib/templates/index.ts`

---

### P2: Deterministic Autofill + Pipeline Integration

- [ ] 7. Create template autofill utility

  **What to do**:
  - Create `packages/backend/lib/template-autofill.ts`
  - Export `applyTemplateDefaults(intermediate: IntermediateFormat, template: DiagramTemplate): IntermediateFormat`
  - **CRITICAL: Wire template defaults into graphOptions.style** (see "Template Defaults Data Flow" section above)
    - `template.nodeDefaults.fill` → `graphOptions.style.shapeFill`
    - `template.nodeDefaults.stroke` → `graphOptions.style.shapeStroke`
    - `template.edgeDefaults.stroke` → `graphOptions.style.arrowStroke`
    - `template.layout.*` → `graphOptions.layout.*`
  - For each node missing `kind`, keep it undefined (don't infer)
  - If `node.metadata.shape` is missing, map `node.kind` → `template.kindToShapeMap` and set `metadata.shape`
  - If `node.metadata.width/height` missing, fill from `template.nodeDefaults.width/height`
  - Explicit values in intermediate ALWAYS win over template defaults
  - Add unit tests in `packages/backend/lib/template-autofill.test.ts`

  **Must NOT do**:
  - Infer node kind from position
  - Add nodes that don't exist in intermediate
  - Override existing explicit values
  - Fail if template is missing (fallback to flowchart)

  **Recommended Agent Profile**:
  - **Category**: `unspecified-low`
    - Reason: Pure function, well-scoped transformation
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 3 (sequential)
  - **Blocks**: Task 8 (visual tests need autofill)
  - **Blocked By**: Task 6 (needs templates)

  **References**:

  **Pattern References**:
  - `packages/backend/lib/diagram-renderer.ts:64-74` - Existing normalization pattern

  **API/Type References**:
  - `packages/backend/lib/diagram-intermediate.ts:108-115` - IntermediateFormat schema

  **Test References**:
  - `packages/backend/convex/visualGrading.test.ts:113-128` - `normalizeIntermediate()` example

  **WHY Each Reference Matters**:
  - `diagram-renderer.ts:64-74`: Follow same normalization style
  - `diagram-intermediate.ts`: Source of truth for IntermediateFormat type
  - `visualGrading.test.ts`: Shows how intermediate is normalized (extend pattern)

  **Acceptance Criteria**:

  **TDD:**
  - [ ] Test file: `packages/backend/lib/template-autofill.test.ts`
  - [ ] Test: intermediate with empty graphOptions gets template defaults
  - [ ] Test: intermediate with explicit direction keeps explicit value
  - [ ] Test: **nodeDefaults.fill maps to graphOptions.style.shapeFill** (CRITICAL)
  - [ ] Test: **edgeDefaults.stroke maps to graphOptions.style.arrowStroke** (CRITICAL)
  - [ ] Test: **nodeDefaults.width/height map to node.metadata.width/height** (CRITICAL)
  - [ ] Test: **kindToShapeMap maps node.kind → node.metadata.shape** (CRITICAL)
  - [ ] Test: unknown diagramType falls back to flowchart template
  - [ ] `cd packages/backend && bun run test -- lib/template-autofill.test.ts` → PASS

  **Automated Verification:**
  ```bash
  # Run from packages/backend (standardized workdir)
  cd packages/backend && bun run test -- lib/template-autofill.test.ts
  # Assert: Exit code 0
  
  # Integration: type check entire lib
  cd packages/backend && bun run check-types
  # Assert: Exit code 0
  ```

  **Evidence to Capture:**
  - [ ] Test output showing merge behavior

  **Commit**: YES
  - Message: `feat(backend): add applyTemplateDefaults autofill utility`
  - Files: `packages/backend/lib/template-autofill.ts`, `packages/backend/lib/template-autofill.test.ts`

---

- [ ] 8. Integrate templates into production pipeline

  **What to do**:
  - Modify `packages/backend/lib/diagram-renderer.ts` `renderIntermediateDiagram()` to:
    1. Get template via `getTemplateForType(intermediate.graphOptions?.diagramType)`
    2. Apply defaults via `applyTemplateDefaults(intermediate, template)`
    3. Pass enriched intermediate to existing layout/conversion
  - Update `convertIntermediateToDiagram()` to read `node.metadata.width/height` (if present) into shape width/height
  - Update `convertLayoutedToExcalidraw()` (or `buildArrowElements()`) to honor template `edgeDefaults.arrowhead`
  - This wires templates into the ACTUAL generation flow, not just tests
  - Update existing tests to verify template defaults are applied

  **Must NOT do**:
  - Change IntermediateFormat schema
  - Add template selection logic
  - Break existing diagrams that don't specify diagramType

  **Recommended Agent Profile**:
  - **Category**: `unspecified-low`
    - Reason: Wiring existing functions together, clear integration point
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 3 (after Task 7)
  - **Blocks**: Tasks 9, 10 (tests need integrated pipeline)
  - **Blocked By**: Task 7 (needs autofill utility)

  **References**:

  **Pattern References**:
  - `packages/backend/lib/diagram-renderer.ts:42-62` - Current `renderIntermediateDiagram()` implementation

  **API/Type References**:
  - `packages/backend/lib/templates/index.ts` - `getTemplateForType()`
  - `packages/backend/lib/template-autofill.ts` - `applyTemplateDefaults()`

  **WHY Each Reference Matters**:
  - `diagram-renderer.ts:42-62`: This is THE integration point - add template logic here

  **Acceptance Criteria**:

  **Automated Verification:**
  ```bash
  # Verify pipeline uses templates (standardized workdir)
  cd packages/backend && bun run test -- convex/diagramGenerateFromIntermediate.test.ts
  # Assert: Exit code 0
  
  # Verify template defaults applied (check diagram has template colors/spacing)
  cd packages/backend && bun -e "import { renderIntermediateDiagram } from './lib/diagram-renderer'; const result = renderIntermediateDiagram({ nodes: [{ id: 'a', label: 'A' }], edges: [], graphOptions: { diagramType: 'architecture' } }); console.log(JSON.stringify(result.elements[0], null, 2));"
  # Assert: Output shows architecture template colors (purple: #d0bfff, #7950f2)

  # Verify template size + arrowhead defaults (diagram + arrow element)
  cd packages/backend && bun -e "import { renderIntermediateDiagram } from './lib/diagram-renderer'; const result = renderIntermediateDiagram({ nodes: [{ id: 'a', label: 'A', kind: 'component' }], edges: [{ fromId: 'a', toId: 'a', label: 'self' }], graphOptions: { diagramType: 'architecture' } }); console.log(JSON.stringify(result.diagram.shapes[0], null, 2)); console.log(JSON.stringify(result.elements.find(e => e.type === 'arrow'), null, 2));"
  # Assert: shape width/height match template defaults
  # Assert: arrow endArrowhead matches template edgeDefaults.arrowhead
  ```

  **Evidence to Capture:**
  - [ ] Test output showing pass
  - [ ] Element JSON showing template styles applied
  - [ ] Diagram + arrow JSON showing width/height + arrowhead defaults

  **Commit**: YES
  - Message: `feat(backend): integrate templates into renderIntermediateDiagram pipeline`
  - Files: `packages/backend/lib/diagram-renderer.ts`
  - Pre-commit: `cd packages/backend && bun run test`

---

### P3: Visual Validation Suite

- [ ] 9. Extend visual grading tests for templates

  **What to do**:
  - Add new scenarios to `packages/backend/convex/visualGrading.test.ts`:
    - Mindmap: "Create a mindmap with central topic 'Project' and 4 branches"
    - Sequence: "Create a sequence diagram with 3 participants (User, API, Database) and 5 messages"
    - Architecture: "Create an architecture diagram with at least 15 components"
  - Use `applyTemplateDefaults()` in test to apply template before rendering
  - Keep minScore at 60 for new scenarios (LLM grading has variance)
  - Verify artifacts written to `test-results/`

  **Must NOT do**:
  - Change existing grading schemas
  - Commit PNG artifacts
  - Change minScores for existing scenarios

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: Test integration, multiple scenarios, LLM interaction
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 10)
  - **Parallel Group**: Wave 4
  - **Blocks**: None
  - **Blocked By**: Task 8 (needs pipeline integration)

  **References**:

  **Pattern References**:
  - `packages/backend/convex/visualGrading.test.ts:45-70` - Existing SCENARIOS array structure

  **Test References**:
  - `packages/backend/convex/visualGrading.test.ts:197-296` - `runScenario()` implementation

  **WHY Each Reference Matters**:
  - SCENARIOS array: Add new entries following same structure
  - runScenario(): Shows full test flow, integrate autofill before `t.action()`

  **Acceptance Criteria**:

  **Automated Verification:**
  ```bash
  # Run from packages/backend (standardized workdir)
  cd packages/backend && OPENROUTER_API_KEY=$OPENROUTER_API_KEY bun run test -- convex/visualGrading.test.ts
  # Assert: Exit code 0, allows up to 1 failure per existing tolerance
  
  # Verify artifacts exist:
  cd packages/backend && ls test-results/visual-grading-*.png | wc -l
  # Assert: >= 6 (3 existing + 3 new)
  
  # Verify grading JSON:
  cd packages/backend && cat test-results/visual-grading.json | jq '.scenarios | length'
  # Assert: >= 6
  ```

  **Evidence to Capture:**
  - [ ] Test output showing 6 scenarios ran
  - [ ] List of PNG files in test-results/
  - [ ] Grading JSON with scores

  **Commit**: YES
  - Message: `test(backend): add visual grading scenarios for mindmap, sequence, architecture`
  - Files: `packages/backend/convex/visualGrading.test.ts`
  - Pre-commit: `cd packages/backend && bun run test -- convex/visualGrading.test.ts` (may skip in CI if API key missing)

---

- [ ] 10. Add E2E drag-binding test

  **What to do**:
  - Create `tests/e2e/arrow-binding-drag.ts` with scenario comment at top (per AGENTS.md)
  - **Confirm approach before implementing** (per AGENTS.md workflow)
  - Generate a simple 2-node diagram with 1 arrow via Convex action
  - Get share link from Excalidraw
  - Start dev server locally OR use `STAGEHAND_TARGET_URL` for preview
  - Use Stagehand/Playwright to:
    1. Navigate to share link
    2. Screenshot before drag (capture arrow endpoint position)
    3. Select and drag shape A by (100, 100) pixels
    4. Screenshot after drag
    5. **Assert ARROW endpoint position changed** (not just shape position)
    6. Use screenshot diff to verify arrow visually followed shape
  - This is the ULTIMATE validation of P0 fix

  **Must NOT do**:
  - Require manual verification
  - Use brittle CSS selectors
  - Only check shape moved (MUST check arrow endpoint)

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
    - Reason: E2E test, browser automation, Stagehand
  - **Skills**: `["playwright", "dev-browser"]`
    - `playwright`: Browser automation
    - `dev-browser`: Persistent page state

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 9)
  - **Parallel Group**: Wave 4
  - **Blocks**: None (final validation)
  - **Blocked By**: Task 1 (needs binding fix deployed)

  **References**:

  **Pattern References**:
  - `tests/e2e/visual-sanity.ts` - Existing Stagehand test structure, scenario comment pattern
  - `tests/e2e/icon-library-generator-happy-path.ts` - Full user flow pattern

  **Documentation References**:
  - Stagehand docs: https://docs.stagehand.dev/
  - Playwright drag: https://playwright.dev/docs/api/class-locator#locator-drag-to

  **Local Spec Capture (Excalidraw Arrow Binding)**:
  > Per https://docs.excalidraw.com/docs/@excalidraw/excalidraw/api/excalidraw-element-skeleton#arrow-bindings:
  > - Arrow needs `startBinding: { elementId, focus, gap, fixedPoint }` and `endBinding: { ... }`
  > - Target shape needs `boundElements: [{ id: arrowId, type: "arrow" }]`
  > - BOTH sides required for drag behavior to work
  > - Without shape.boundElements, arrow endpoints remain static when shape moves

  **WHY Each Reference Matters**:
  - `visual-sanity.ts`: Follow same setup/teardown and scenario comment pattern
  - Playwright drag docs: Exact API for drag operation
  - Local spec capture: Offline reference for binding requirements

  **Acceptance Criteria**:

  **Test file structure (scenario comment per AGENTS.md):**
  ```typescript
  /**
   * TEST SCENARIO: Arrow binding drag verification
   *
   * Goal: Verify that when a shape is dragged in Excalidraw, connected arrows
   * move with it (not left behind).
   *
   * Pre-conditions:
   * - P0 binding fix deployed (normalizeArrowBindings)
   * - Dev server running OR STAGEHAND_TARGET_URL set
   *
   * Steps:
   * 1. Generate 2-node diagram with arrow via Convex
   * 2. Load share link in Excalidraw web
   * 3. Extract scene JSON via Excalidraw API (get arrow.points coordinates)
   * 4. Drag source shape by (100, 100) using Stagehand act()
   * 5. Extract scene JSON again
   * 6. Assert arrow endpoint coordinates changed (not same as before)
   *
   * Expected: Arrow points[last] coordinates differ pre/post drag
   */
  ```

  **Automated Verification (scene JSON extraction - more reliable than DOM):**
  ```typescript
  test("arrow endpoints follow shapes when dragged", async () => {
    // 1. Generate diagram and get share link
    const shareLink = await generateDiagramShareLink();
    
    // 2. Navigate with Stagehand
    await stagehand.page.goto(shareLink);
    await stagehand.page.waitForLoadState('networkidle');
    
    // 3. Screenshot BEFORE drag
    await stagehand.page.screenshot({ path: 'test-results/arrow-drag-before.png' });
    
    // 4. Extract scene JSON via Excalidraw's window API (MORE RELIABLE than DOM selectors)
    // Excalidraw exposes window.excalidrawAPI or we can parse from URL hash
    const getArrowEndpoint = async () => {
      return await stagehand.page.evaluate(() => {
        // Excalidraw stores scene in URL hash as compressed JSON
        // Or use excalidrawAPI.getSceneElements() if available
        const hash = window.location.hash;
        if (hash.startsWith('#json=')) {
          const data = JSON.parse(decodeURIComponent(hash.slice(6)));
          const arrow = data.elements?.find((e: any) => e.type === 'arrow');
          if (arrow?.points) {
            const lastPoint = arrow.points[arrow.points.length - 1];
            return { x: arrow.x + lastPoint[0], y: arrow.y + lastPoint[1] };
          }
        }
        // Fallback: try excalidrawAPI if exposed
        const api = (window as any).excalidrawAPI;
        if (api) {
          const elements = api.getSceneElements();
          const arrow = elements.find((e: any) => e.type === 'arrow');
          if (arrow?.points) {
            const lastPoint = arrow.points[arrow.points.length - 1];
            return { x: arrow.x + lastPoint[0], y: arrow.y + lastPoint[1] };
          }
        }
        return null;
      });
    };
    
    const initialArrowEnd = await getArrowEndpoint();
    expect(initialArrowEnd).not.toBeNull();
    
    // 5. Use Stagehand act() for reliable interaction (LLM-guided, not brittle selectors)
    await stagehand.act('Click on the first rectangle shape to select it');
    await stagehand.act('Drag the selected shape about 100 pixels to the right and down');
    
    // 6. Wait for Excalidraw to update scene
    await stagehand.page.waitForTimeout(500);
    
    // 7. Screenshot AFTER drag
    await stagehand.page.screenshot({ path: 'test-results/arrow-drag-after.png' });
    
    // 8. Extract arrow endpoint AFTER drag
    const finalArrowEnd = await getArrowEndpoint();
    expect(finalArrowEnd).not.toBeNull();
    
    // 9. CRITICAL: Assert ARROW ENDPOINT moved (not just shape)
    // If binding works, arrow endpoint should have moved with the shape
    const deltaX = Math.abs((finalArrowEnd?.x ?? 0) - (initialArrowEnd?.x ?? 0));
    const deltaY = Math.abs((finalArrowEnd?.y ?? 0) - (initialArrowEnd?.y ?? 0));
    
    // Expect at least 50px movement (we dragged ~100px)
    expect(deltaX + deltaY).toBeGreaterThan(50);
    
    console.log(`Arrow endpoint moved: dx=${deltaX}, dy=${deltaY}`);
  });
  ```

  **Why scene JSON extraction is more reliable:**
  - DOM selectors like `[data-type="arrow"]` may not exist in Excalidraw's SVG structure
  - `boundingBox()` gives visual position, not logical coordinates
  - Excalidraw's internal scene elements have exact point coordinates
  - URL hash or `excalidrawAPI.getSceneElements()` gives authoritative data

  **Evidence to Capture:**
  - [ ] Screenshot `test-results/arrow-drag-before.png`
  - [ ] Screenshot `test-results/arrow-drag-after.png` (showing arrow followed)
  - [ ] Test output showing PASS with arrow position delta

  **Commit**: YES
  - Message: `test(e2e): add arrow binding drag verification test`
  - Files: `tests/e2e/arrow-binding-drag.ts`
  - Pre-commit: `cd tests/e2e && bun run arrow-binding-drag.ts` (requires BROWSERBASE_API_KEY)

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1 | `fix(backend): add bidirectional arrow-shape binding normalization` | excalidraw-elements.ts, *.test.ts | `cd packages/backend && bun run test -- lib/excalidraw-elements.test.ts` |
| 2-5 | `feat(backend): add diagram templates (flowchart, architecture, mindmap, sequence)` | templates/*.ts | `cd packages/backend && bun run check-types` |
| 6 | `feat(backend): add template index and getTemplateForType utility` | templates/index.ts | `cd packages/backend && bun run check-types` |
| 7 | `feat(backend): add applyTemplateDefaults autofill utility` | template-autofill.ts, *.test.ts | `cd packages/backend && bun run test -- lib/template-autofill.test.ts` |
| 8 | `feat(backend): integrate templates into renderIntermediateDiagram pipeline` | diagram-renderer.ts | `cd packages/backend && bun run test` |
| 9 | `test(backend): add visual grading scenarios for mindmap, sequence, architecture` | visualGrading.test.ts | `cd packages/backend && bun run test -- convex/visualGrading.test.ts` |
| 10 | `test(e2e): add arrow binding drag verification test` | tests/e2e/arrow-binding-drag.ts | `cd tests/e2e && bun run arrow-binding-drag.ts` |

---

## Success Criteria

### Verification Commands (standardized: always cd first)
```bash
# Full backend test suite
cd packages/backend && bun run test
# Expected: All tests pass

# Type check
cd packages/backend && bun run check-types
# Expected: No errors

# Visual grading (requires OPENROUTER_API_KEY)
cd packages/backend && OPENROUTER_API_KEY=$OPENROUTER_API_KEY bun run test -- convex/visualGrading.test.ts
# Expected: 6 scenarios, allows 1 failure (5/6 pass)

# E2E drag test (requires BROWSERBASE_API_KEY)
cd tests/e2e && BROWSERBASE_API_KEY=$BROWSERBASE_API_KEY bun run arrow-binding-drag.ts
# Expected: Arrow endpoint moves when shape dragged
```

### Final Checklist
- [ ] All "Must Have" present
  - [ ] Bidirectional binding works (P0)
  - [ ] 4 templates exist (P1)
  - [ ] Autofill utility works (P2)
  - [ ] Templates integrated into pipeline (P2)
  - [ ] Visual grading extended with 3 new scenarios (P3)
  - [ ] E2E drag test validates arrow behavior (P3)
- [ ] All "Must NOT Have" absent
  - [ ] No Convex template storage
  - [ ] No template selection UI
  - [ ] No IntermediateFormat schema changes
- [ ] All tests pass
  - [ ] `cd packages/backend && bun run test` passes
  - [ ] Visual grading 5/6 pass
  - [ ] E2E drag test passes (arrow endpoint moved)
