# Lint Cleanup and Test Artifact Organization

## Context

### Original Request
1. Move 2 test-generated files to appropriate location (later decided: DELETE them)
2. Fix significant linting warnings, but not pedantic ones that don't improve type checking or clarity

### Interview Summary
**Key Discussions**:
- User confirmed DELETE for `evidence-sketchy-svg.txt` and `test-icon.svg` (not needed)
- User confirmed ADD biome-ignore comments for `noMisplacedAssertion` false positives (assertions in helper functions)
- Verified deleted files have no references in codebase

**Research Findings**:
- 74 total lint errors, categorized by value:
  - 47-48 `noMisplacedAssertion`: False positives in 2 test files (helper function pattern)
  - 7 `useAwait`: Redundant async keywords
  - 5 `useTopLevelRegex`: Regex created in function scope (performance)
  - 2 `noUselessCatch`: Dead try-catch blocks
  - 1 `noExcessiveCognitiveComplexity`: export-button.tsx at 22 (max 20)
  - 1 `noUndeclaredVariables`: Bun global in scripts/test-svg-conversion.ts
  - 6+ `noExplicitAny/noConfusingVoidType`: Framework types in logging.ts (SKIP)
  - 1 `noLabelWithoutControl`: shadcn component false positive (SKIP)

### Metis Review
**Identified Gaps** (addressed):
- Need to verify deleted files aren't referenced → Confirmed: no references found
- biome-ignore comments must include reason text → Added to guardrails
- useAwait fixes must preserve caller compatibility → Added verification step
- scripts/test-svg-conversion.ts needs decision → Add bun-types reference (dev script)

---

## Work Objectives

### Core Objective
Clean up test artifacts from repo root and fix meaningful lint warnings that improve code quality.

### Concrete Deliverables
1. Delete `evidence-sketchy-svg.txt`, `test-icon.svg`, and empty `test-results/` from repo root
2. Add `tests/e2e/artifacts/` to `.gitignore`
3. Add biome-ignore comments to 2 test files (48 assertions in helper functions)
4. Fix 15 lint errors across 9 files (useAwait, useTopLevelRegex, noUselessCatch, cognitive complexity)
5. Add bun-types reference to scripts/test-svg-conversion.ts

### Definition of Done
- [x] `git status` shows no untracked test artifacts in repo root
- [x] `bun x ultracite check` shows 0 errors in fixed categories
- [x] All biome-ignore comments include `: reason` suffix
- [x] `bun run test` in packages/backend still passes
- [x] `bun run build` completes successfully

### Must Have
- All biome-ignore comments follow format: `// biome-ignore lint/category/rule: reason`
- Cognitive complexity refactor is behavior-neutral
- No functional changes to any production code

### Must NOT Have (Guardrails)
- DO NOT change regex logic when moving to module scope
- DO NOT refactor export-button.tsx beyond complexity reduction
- DO NOT extract new components or change props/state in export-button.tsx
- DO NOT add .gitignore entries beyond `tests/e2e/artifacts/`
- DO NOT change function signatures when fixing useAwait (preserve Promise return type for callers)

---

## Verification Strategy

### Test Decision
- **Infrastructure exists**: YES (`packages/backend` has Vitest)
- **User wants tests**: Manual verification (lint check + existing test suite)
- **Framework**: bun test (Vitest)

### Verification Commands
```bash
# After each file change
bun x ultracite check

# After all changes
bun run test --filter=backend
bun run build
```

---

## Task Flow

```
Task 1 (File Cleanup) → Task 2 (.gitignore)
                             ↓
Task 3 (biome-ignore) → Task 4 (useAwait fixes)
         ↓                    ↓
Task 5 (useTopLevelRegex) → Task 6 (noUselessCatch)
                                  ↓
                           Task 7 (cognitive complexity)
                                  ↓
                           Task 8 (bun-types)
                                  ↓
                           Task 9 (Final verification)
```

## Parallelization

| Group | Tasks | Reason |
|-------|-------|--------|
| A | 3, 4, 5, 6 | Independent files, can run in parallel after file cleanup |

| Task | Depends On | Reason |
|------|------------|--------|
| 2 | 1 | .gitignore update after file deletion |
| 9 | 1-8 | Final verification requires all fixes complete |

---

## TODOs

- [x] 1. Delete test artifacts from repo root

  **What to do**:
  - Delete `evidence-sketchy-svg.txt` from repo root
  - Delete `test-icon.svg` from repo root
  - Delete empty `test-results/` directory from repo root

  **Must NOT do**:
  - Delete anything in `packages/backend/test-results/`
  - Delete anything in `tests/e2e/artifacts/`

  **Parallelizable**: NO (must be first)

  **References**:
  - `evidence-sketchy-svg.txt` (root) - Test evidence file, confirmed no references
  - `test-icon.svg` (root) - Test icon file, confirmed no references
  - `test-results/` (root) - Empty directory, not the backend test-results

  **Acceptance Criteria**:
  - [ ] `ls evidence-sketchy-svg.txt test-icon.svg test-results/ 2>&1` → "No such file or directory" for all 3
  - [ ] `ls packages/backend/test-results/` → Still exists (untouched)

  **Commit**: YES
  - Message: `chore: delete stray test artifacts from repo root`
  - Files: `evidence-sketchy-svg.txt`, `test-icon.svg`, `test-results/`

---

- [x] 2. Add tests/e2e/artifacts/ to .gitignore

  **What to do**:
  - Add `tests/e2e/artifacts/` to `.gitignore`
  - Place near other test-related ignores

  **Must NOT do**:
  - Add any other entries
  - Modify existing ignore patterns

  **Parallelizable**: NO (depends on task 1)

  **References**:
  - `.gitignore:4` - Current pattern for `packages/backend/test-results/`
  - `.gitignore:46-47` - Current coverage patterns
  - `tests/e2e/src/runner/config.ts:72-82` - Defines artifacts path

  **Acceptance Criteria**:
  - [ ] `grep "tests/e2e/artifacts" .gitignore` → Shows the new entry
  - [ ] `git check-ignore tests/e2e/artifacts/test.txt` → Outputs path (ignored)

  **Commit**: YES (groups with task 1)
  - Message: `chore: add e2e artifacts to gitignore`
  - Files: `.gitignore`

---

- [x] 3. Add biome-ignore comments to test helper functions

  **What to do**:
  - Add `// biome-ignore lint/suspicious/noMisplacedAssertion: assertions in helper called from test()` before helper function definitions
  - Files: `arrowOptimization.test.ts` (1 helper), `excalidrawShareLinks.test.ts` (1 helper)

  **Must NOT do**:
  - Restructure tests
  - Move assertions into test() blocks

  **Parallelizable**: YES (with 4, 5, 6)

  **References**:
  - `packages/backend/convex/arrowOptimization.test.ts:260-275` - `expectArrowOptimized()` helper function with 5 assertions
  - `packages/backend/convex/excalidrawShareLinks.test.ts:156-226` - `assertValidExcalidrawElements()` helper function with ~43 assertions
  - Biome docs: https://biomejs.dev/linter/rules/no-misplaced-assertion/

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check packages/backend/convex/arrowOptimization.test.ts` → 0 noMisplacedAssertion errors
  - [ ] `bun x ultracite check packages/backend/convex/excalidrawShareLinks.test.ts` → 0 noMisplacedAssertion errors
  - [ ] `bun run test --filter=backend` → All tests still pass (helper functions work correctly)

  **Commit**: YES
  - Message: `chore: suppress false positive lint errors in test helpers`
  - Files: `packages/backend/convex/arrowOptimization.test.ts`, `packages/backend/convex/excalidrawShareLinks.test.ts`

---

- [x] 4. Fix useAwait lint errors (remove redundant async)

  **What to do**:
  - Remove `async` keyword from functions that don't use `await` but return Promise
  - Verify caller compatibility by checking if function is awaited at call sites

  **Files to fix**:
  1. `tests/e2e/src/runner/wait.ts:10` - `sleep()` function
  2. `tests/e2e/src/runner/wait.ts:47` - `waitForVisible()` function
  3. `tests/e2e/src/runner/wait.ts:94` - `waitForUrl()` function
  4. `packages/backend/convex/healthCheck.ts:4` - health check function
  5. `packages/backend/convex/iconLibraries.ts:187` - function
  6. `packages/backend/experiments/lib/render-png.ts:126` - function
  7. `packages/backend/experiments/lib/render-png.ts:138` - function

  **Must NOT do**:
  - Change function logic
  - Change return types (keep Promise return for callers)

  **Parallelizable**: YES (with 3, 5, 6)

  **References**:
  - `tests/e2e/src/runner/wait.ts:10-12` - `sleep()` returns `new Promise()` directly
  - `tests/e2e/src/runner/wait.ts:47-55` - `waitForVisible()` returns `waitForCondition()` call
  - `tests/e2e/src/runner/wait.ts:94-100` - `waitForUrl()` returns `waitForCondition()` call
  - Biome docs: https://biomejs.dev/linter/rules/use-await/

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check tests/e2e/src/runner/wait.ts` → 0 useAwait errors
  - [ ] `bun x ultracite check packages/backend/convex/healthCheck.ts` → 0 useAwait errors
  - [ ] `bun x ultracite check packages/backend/convex/iconLibraries.ts` → 0 useAwait errors
  - [ ] `bun x ultracite check packages/backend/experiments/lib/render-png.ts` → 0 useAwait errors

  **Commit**: YES
  - Message: `fix: remove redundant async from Promise-returning functions`
  - Files: Listed above

---

- [x] 5. Fix useTopLevelRegex lint errors

  **What to do**:
  - Move regex literals from function scope to module (top-level) scope
  - DO NOT change regex patterns

  **Files to fix**:
  1. `packages/backend/convex/iconLibrariesActions.ts:23` - regex pattern
  2. `packages/backend/convex/iconLibrariesActions.ts:31` - 2 regex patterns
  3. `tests/e2e/src/runner/utils.ts:8` - regex pattern
  4. `tests/e2e/src/runner/config.ts:118` - regex pattern

  **Must NOT do**:
  - Change regex logic or patterns
  - Add flags that weren't there

  **Parallelizable**: YES (with 3, 4, 6)

  **References**:
  - `packages/backend/convex/iconLibrariesActions.ts:23,31` - Regexes for icon processing
  - `tests/e2e/src/runner/utils.ts:8` - Utility regex
  - `tests/e2e/src/runner/config.ts:118` - Config regex
  - Biome docs: https://biomejs.dev/linter/rules/use-top-level-regex/

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check packages/backend/convex/iconLibrariesActions.ts` → 0 useTopLevelRegex errors
  - [ ] `bun x ultracite check tests/e2e/src/runner/utils.ts` → 0 useTopLevelRegex errors
  - [ ] `bun x ultracite check tests/e2e/src/runner/config.ts` → 0 useTopLevelRegex errors

  **Commit**: YES
  - Message: `perf: move regex literals to module scope`
  - Files: Listed above

---

- [x] 6. Fix noUselessCatch lint errors

  **What to do**:
  - Remove try-catch blocks that only rethrow the error
  - Both instances are identical pattern: `try { return JSON.parse(raw); } catch (error) { throw error; }`

  **Files to fix**:
  1. `packages/backend/convex/diagramGenerateFromIntermediate.test.ts:54-58`
  2. `packages/backend/convex/diagramLayout.test.ts:52-56`

  **Must NOT do**:
  - Change JSON.parse logic
  - Remove other try-catch blocks

  **Parallelizable**: YES (with 3, 4, 5)

  **References**:
  - `packages/backend/convex/diagramGenerateFromIntermediate.test.ts:54-58` - Useless catch around JSON.parse
  - `packages/backend/convex/diagramLayout.test.ts:52-56` - Same pattern
  - Biome docs: https://biomejs.dev/linter/rules/no-useless-catch/

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check packages/backend/convex/diagramGenerateFromIntermediate.test.ts` → 0 noUselessCatch errors
  - [ ] `bun x ultracite check packages/backend/convex/diagramLayout.test.ts` → 0 noUselessCatch errors

  **Commit**: YES
  - Message: `fix: remove useless try-catch blocks in test files`
  - Files: Listed above

---

- [x] 7. Refactor export-button.tsx to reduce cognitive complexity

  **What to do**:
  - Reduce cognitive complexity from 22 to under 20 in `handleExportZip()` function
  - Extract helper functions for distinct responsibilities
  - Keep all changes behavior-neutral

  **Suggested approach**:
  - Extract early validation into `validateExportInputs()`
  - Extract zip creation logic into `createZipFile()`
  - Keep main orchestration flow clear

  **Must NOT do**:
  - Change any user-facing behavior
  - Modify component props or state
  - Extract new React components
  - Change the export output format

  **Parallelizable**: NO (complex refactor, needs focus)

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:210-280` - `handleExportZip()` function
  - Current complexity: 22, target: <20 (recommend 18 for safety margin)
  - Biome docs: https://biomejs.dev/linter/rules/no-excessive-cognitive-complexity/

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check apps/web/src/components/icon-library/export-button.tsx` → 0 noExcessiveCognitiveComplexity errors
  - [ ] Manual verification: Export ZIP functionality works identically
  - [ ] `bun run build` → Compiles without errors

  **Commit**: YES
  - Message: `refactor: reduce cognitive complexity in export-button handleExportZip`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`

---

- [x] 8. Add bun-types reference to scripts/test-svg-conversion.ts

  **What to do**:
  - Add `/// <reference types="bun-types" />` at top of file
  - This resolves the `Bun` global undeclared variable error

  **Must NOT do**:
  - Modify script logic
  - Delete the script

  **Parallelizable**: YES (independent file)

  **References**:
  - `scripts/test-svg-conversion.ts:35` - Uses `Bun.build()` global
  - Bun types: https://bun.sh/docs/typescript

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check scripts/test-svg-conversion.ts` → 0 noUndeclaredVariables errors

  **Commit**: YES
  - Message: `fix: add bun-types reference to script`
  - Files: `scripts/test-svg-conversion.ts`

---

- [x] 9. Final verification and lint check

  **What to do**:
  - Run full lint check
  - Run test suite
  - Run build
  - Verify error count reduced

  **Parallelizable**: NO (must be last)

  **References**:
  - All previous tasks

  **Acceptance Criteria**:
  - [ ] `bun x ultracite check 2>&1 | grep "Found"` → Shows reduced error count (expected: ~6-8 remaining for skipped rules)
  - [ ] `bun run test --filter=backend` → All tests pass
  - [ ] `bun run build` → Builds successfully

  **Commit**: NO (verification only)

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1+2 | `chore: clean up test artifacts and gitignore` | 3 deleted files + .gitignore | `git status` clean |
| 3 | `chore: suppress false positive lint errors in test helpers` | 2 test files | `bun x ultracite check` |
| 4 | `fix: remove redundant async from Promise-returning functions` | 4 files | `bun x ultracite check` |
| 5 | `perf: move regex literals to module scope` | 3 files | `bun x ultracite check` |
| 6 | `fix: remove useless try-catch blocks in test files` | 2 test files | `bun x ultracite check` |
| 7 | `refactor: reduce cognitive complexity in export-button handleExportZip` | 1 component | `bun x ultracite check` + manual test |
| 8 | `fix: add bun-types reference to script` | 1 script | `bun x ultracite check` |

---

## Success Criteria

### Verification Commands
```bash
# Lint check - expect ~6-8 remaining (skipped rules)
bun x ultracite check

# Tests pass
bun run test --filter=backend

# Build succeeds
bun run build

# No stray files
ls evidence-sketchy-svg.txt test-icon.svg test-results/ 2>&1
# Expected: "No such file or directory" for all
```

### Final Checklist
- [x] All "Must Have" requirements present
- [x] All "Must NOT Have" guardrails respected
- [x] Error count reduced from 74 to ~6-8 (skipped rules only)
- [x] No functional changes to production code
- [x] All commits follow conventional format
