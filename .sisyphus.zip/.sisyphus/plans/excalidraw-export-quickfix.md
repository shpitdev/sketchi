# Excalidraw Export Quick Fix

## Context

### Original Request
Fix Excalidraw export issues identified from user testing:
1. **Embedded export** - Shows placeholder images (broken)
2. **Normal/Clean exports** - Missing cross-hatch fills

### Problem Analysis

**Root Causes Identified:**

1. **Embedded Export Broken**: `.excalidrawlib` format doesn't support the `files` object - only full scenes (`.excalidraw`) support embedded images. Excalidraw maintainers confirm: "images in libraries are in our backlog" (GitHub #5034).

2. **Fills Don't Render**: Two bugs in `svg-to-excalidraw.ts`:
   - `roughness: 0` - No hand-drawn effect at all
   - `polygon: false` - Open paths don't render fills in Excalidraw

3. **Double-Roughing** (Normal export): Svg2Roughjs applies roughness, then Excalidraw applies it again.

### Research Findings (Oracle Consultation)
- Excalidraw only renders fills on closed polygons (`polygon: true`)
- `roughness >= 1` needed for sketchy effect (1.5-2 is sweet spot)
- Skip Svg2Roughjs for Excalidraw export, let Excalidraw handle roughness
- `.excalidrawlib` cannot support images - this is a known limitation

---

## Work Objectives

### Core Objective
Fix the Excalidraw export so icons render with proper cross-hatch fills and sketchy effect.

### Concrete Deliverables
1. Fix `polygon` and `roughness` settings in svg-to-excalidraw.ts
2. Remove broken Embedded export option
3. Update Normal export to skip Svg2Roughjs (use Clean approach)
4. Create GitHub issue for full fix (future work)

### Definition of Done
- [x] Clean export shows cross-hatch fills correctly
- [x] Icons have sketchy/hand-drawn appearance
- [x] Embedded export removed from menu
- [x] Build succeeds
- [x] GitHub issue created for future improvements

---

## TODOs

- [x] 1. Fix polygon setting for filled shapes

  **What to do**:
  In `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`, change the polygon setting to be `true` when the shape has a fill (backgroundColor !== "transparent").

  **Current code (line ~319)**:
  ```typescript
  polygon: false,
  ```

  **Change to**:
  ```typescript
  polygon: colors.backgroundColor !== "transparent",
  ```

  **Why**: Excalidraw only renders fills on closed polygons. With `polygon: false`, the fill is ignored.

  **References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:319` - current polygon setting
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:201-206` - extractColors function

  **Acceptance Criteria**:
  - [x] polygon is true when backgroundColor is not transparent
  - [x] polygon is false for stroke-only shapes

  **Commit**: NO (groups with task 2)

---

- [x] 2. Fix roughness to use styleSettings

  **What to do**:
  In `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`, change the hardcoded `roughness: 0` to use the style settings.

  **Current code (line ~300)**:
  ```typescript
  roughness: 0,
  ```

  **Change to**:
  ```typescript
  roughness: styleSettings.roughness,
  ```

  **Why**: `roughness: 0` disables all hand-drawn effects. Using styleSettings allows the sketchy appearance.

  **References**:
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:300` - current roughness setting
  - `apps/web/src/lib/icon-library/svg-to-excalidraw.ts:175-183` - StyleSettings interface

  **Acceptance Criteria**:
  - [x] roughness uses styleSettings.roughness instead of hardcoded 0
  - [x] Icons have sketchy appearance when exported

  **Commit**: YES
  - Message: `fix(icon-library): enable cross-hatch fills and roughness in Excalidraw export`
  - Files: `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`
  - Pre-commit: `bun run build && bun x ultracite check`

---

- [x] 3. Remove Embedded export option

  **What to do**:
  In `apps/web/src/components/icon-library/export-button.tsx`:
  1. Remove the `handleExportExcalidrawEmbedded` function
  2. Remove the menu item for "Export as .excalidrawlib (Embedded)"

  **Current menu (lines 530-535)**:
  ```tsx
  <DropdownMenuItem
    disabled={disabled}
    onClick={handleExportExcalidrawEmbedded}
  >
    Export as .excalidrawlib (Embedded)
  </DropdownMenuItem>
  ```

  **Remove**: Both the menu item and the handler function (lines 358-506)

  **Why**: `.excalidrawlib` format doesn't support embedded images. This option is fundamentally broken and cannot be fixed without Excalidraw changes.

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:358-506` - handleExportExcalidrawEmbedded function
  - `apps/web/src/components/icon-library/export-button.tsx:530-535` - menu item

  **Acceptance Criteria**:
  - [x] Embedded export menu item removed
  - [x] handleExportExcalidrawEmbedded function removed
  - [x] No TypeScript errors

  **Commit**: NO (groups with task 4)

---

- [x] 4. Update Normal export to use Clean approach

  **What to do**:
  In `apps/web/src/components/icon-library/export-button.tsx`, modify `handleExportExcalidraw` to skip the Svg2Roughjs preprocessing step (same as Clean export).

  **Current code (around line 146)**:
  ```typescript
  const sketchySvg = renderSketchySvg(svgText, icon.name, styleSettings);
  const elements = svgToExcalidrawElements(sketchySvg, styleSettings, icon.name);
  ```

  **Change to**:
  ```typescript
  // Skip Svg2Roughjs - let Excalidraw handle roughness
  const elements = svgToExcalidrawElements(svgText, styleSettings, icon.name);
  ```

  **Why**: Double-roughing (Svg2Roughjs + Excalidraw RoughJS) causes distortion. Let Excalidraw be the single source of roughness.

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:120-190` - handleExportExcalidraw function
  - `apps/web/src/components/icon-library/export-button.tsx:286-355` - handleExportExcalidrawClean (reference for the fix)

  **Acceptance Criteria**:
  - [x] Normal export skips Svg2Roughjs
  - [x] Normal export produces same output as Clean export
  - [x] No double-roughing artifacts

  **Commit**: NO (groups with task 5)

---

- [x] 5. Remove Clean export (now redundant)

  **What to do**:
  Since Normal export will now use the Clean approach:
  1. Remove `handleExportExcalidrawClean` function
  2. Remove "Export as .excalidrawlib (Clean)" menu item
  3. Keep only one "Export as .excalidrawlib" option

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:286-355` - handleExportExcalidrawClean function
  - `apps/web/src/components/icon-library/export-button.tsx:524-529` - Clean menu item

  **Acceptance Criteria**:
  - [x] Clean export handler removed
  - [x] Clean menu item removed
  - [x] Only one Excalidraw export option remains

  **Commit**: YES
  - Message: `fix(icon-library): fix Excalidraw export and remove broken options`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`
  - Pre-commit: `bun run build && bun x ultracite check`

---

- [x] 6. Test the fix with sample icons

  **What to do**:
  1. Start dev server
  2. Navigate to library generator
  3. Add test icons (training-app, code-app, model-app from screenshot)
  4. Export as .excalidrawlib
  5. Import into excalidraw.com
  6. Verify:
     - Cross-hatch fills render correctly
     - Sketchy/hand-drawn appearance
     - Colors preserved
     - Shapes not distorted

  **Acceptance Criteria**:
  - [x] Cross-hatch fills visible in Excalidraw
  - [x] Icons have sketchy appearance
  - [x] No distortion or missing elements

  **Commit**: NO (testing only)

---

- [x] 7. Create GitHub issue for full fix

  **What to do**:
  Create a GitHub issue documenting future improvements:
  - Smart path closure detection (check for Z command, endpoint matching)
  - Compound path/hole handling
  - Better color extraction from computed styles
  - Investigate PNG rasterization for true pixel-perfect export

  **Issue content**:
  ```markdown
  ## Excalidraw Export Full Fix - Future Improvements

  ### Context
  Quick fix implemented in [commit]. This issue tracks additional improvements.

  ### Remaining Work

  #### 1. Smart Path Closure Detection
  Currently we set `polygon: true` for any filled shape. Better approach:
  - Check if SVG path contains close command (Z/z)
  - Check if first/last points are within epsilon (≤0.5px)
  - Only close paths that are actually meant to be closed

  #### 2. Compound Path/Hole Handling
  Excalidraw polygons don't support boolean subtraction. Icons with holes (donuts, letters with counters) will "fill in" the holes. Options:
  - Split into multiple polygons in correct z-order
  - Detect and warn about icons with holes

  #### 3. Better Color Extraction
  Current `extractColors` only reads `stroke` and `fill` attributes. Should also:
  - Handle computed styles
  - Handle gradient references (extract dominant color)
  - Handle `currentColor`

  #### 4. PNG Rasterization Option
  For true pixel-perfect export (where vector approximation isn't enough):
  - Render SVG to canvas
  - Export as PNG data URL
  - Create `.excalidraw` scene format (not library)
  - Only viable for scene export, not library

  ### References
  - Oracle consultation: [session ID]
  - Excalidraw image-in-library limitation: GitHub #5034
  ```

  **Acceptance Criteria**:
  - [x] GitHub issue created
  - [x] Issue linked in code comments

  **Commit**: NO (documentation only)

---

## Commit Strategy

| After Task | Message | Files |
|------------|---------|-------|
| 2 | `fix(icon-library): enable cross-hatch fills and roughness in Excalidraw export` | svg-to-excalidraw.ts |
| 5 | `fix(icon-library): fix Excalidraw export and remove broken options` | export-button.tsx |

---

## Success Criteria

### Expected Outcomes
- Icons export with proper cross-hatch/hachure fills
- Sketchy/hand-drawn appearance matches style settings
- Single, working Excalidraw export option
- No broken embedded export confusing users

### Verification Commands
```bash
bun run build  # Should pass
bun x ultracite check  # Should pass
```

### Final Checklist
- [x] Cross-hatch fills render in Excalidraw
- [x] Icons have sketchy appearance
- [x] Only one .excalidrawlib export option
- [x] Build passes
- [x] GitHub issue created for future improvements
