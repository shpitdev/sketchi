# Excalidraw Export Experiments

## Context

### Original Request
Add two experimental export options to test different approaches for Excalidraw export. Current export produces heavily distorted icons (see comparison: left is direct SVG drag, right is our export - completely different shapes).

### Problem Analysis
**Root Cause**: Double roughing - Svg2Roughjs pre-processes SVG, then Excalidraw applies RoughJS again to line elements.

### Research Findings
1. Line elements ALWAYS go through RoughJS (even with roughness: 0)
2. Freedraw elements bypass RoughJS for strokes
3. Current export flow: Original SVG → Svg2Roughjs → svgToExcalidrawElements → distorted output

---

## Work Objectives

### Core Objective
Add two experimental export options to compare approaches and find the best solution for Excalidraw export fidelity.

### Concrete Deliverables
1. **Experiment 1**: "Export as .excalidrawlib (Clean)" - Export from original SVG, skip Svg2Roughjs
2. **Experiment 2**: "Export as .excalidrawlib (Embedded)" - Embed roughed SVG as Excalidraw image elements

### Definition of Done
- [x] Both export options added to dropdown menu
- [x] Test with fusion-app.svg icon
- [x] Test with one other Palantir icon
- [x] Document visual results comparison
- [x] Build succeeds

---

## TODOs

- [x] 1. Add Experiment 1: Clean Export Handler

  **What to do**:
  Add `handleExportExcalidrawClean` function to `export-button.tsx`:
  - Copy structure from `handleExportExcalidraw`
  - SKIP the `renderSketchySvg()` call
  - Pass original `svgText` directly to `svgToExcalidrawElements()`
  - Use filename suffix `-clean.excalidrawlib`

  **Key change** (line 146-148 equivalent):
  ```typescript
  // Current (skip this):
  // const sketchySvg = renderSketchySvg(svgText, icon.name, styleSettings);
  
  // Experiment 1: Use original SVG directly
  const elements = svgToExcalidrawElements(
    svgText,  // <-- Original SVG, not sketchySvg
    styleSettings,
    icon.name
  );
  ```

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:120-190` - current handleExportExcalidraw

  **Acceptance Criteria**:
  - [x] New handler function exists
  - [x] Uses original SVG text instead of Svg2Roughjs output
  - [x] Filename ends with `-clean.excalidrawlib`

  **Commit**: NO (groups with task 2)

---

- [x] 2. Add Experiment 2: Embedded SVG Export Handler

  **What to do**:
  Add `handleExportExcalidrawEmbedded` function to `export-button.tsx`:
  - Create Excalidraw `image` elements instead of `line` elements
  - Render SVG through Svg2Roughjs (like current flow)
  - Convert roughed SVG to data URL
  - Create image element with `fileId` reference
  - Add `files` object to payload with SVG data URLs

  **Excalidraw image element structure**:
  ```typescript
  {
    type: "image",
    id: randomId(),
    x: 0,
    y: 0,
    width: 100,
    height: 100,
    fileId: fileId,  // References files object
    status: "saved",
    scale: [1, 1],
    // ... standard element properties
  }
  ```

  **Files object structure**:
  ```typescript
  files: {
    [fileId]: {
      mimeType: "image/svg+xml",
      id: fileId,
      dataURL: "data:image/svg+xml;base64,...",
      created: Date.now()
    }
  }
  ```

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:66-111` - renderSketchySvg function
  - Excalidraw image element docs: https://docs.excalidraw.com/docs/@excalidraw/excalidraw/api/props/initialdata#files

  **Acceptance Criteria**:
  - [x] New handler function exists
  - [x] Creates image elements with embedded SVG
  - [x] Files object included in payload
  - [x] Filename ends with `-embedded.excalidrawlib`

  **Commit**: NO (groups with task 3)

---

- [x] 3. Add Menu Items for Both Experiments

  **What to do**:
  Update the DropdownMenuContent in `export-button.tsx` (around line 298-308):

  ```tsx
  <DropdownMenuContent align="end">
    <DropdownMenuItem disabled={disabled} onClick={handleExportExcalidraw}>
      Export as .excalidrawlib
    </DropdownMenuItem>
    {/* NEW: Experiment 1 */}
    <DropdownMenuItem disabled={disabled} onClick={handleExportExcalidrawClean}>
      Export as .excalidrawlib (Clean)
    </DropdownMenuItem>
    {/* NEW: Experiment 2 */}
    <DropdownMenuItem disabled={disabled} onClick={handleExportExcalidrawEmbedded}>
      Export as .excalidrawlib (Embedded)
    </DropdownMenuItem>
    <DropdownMenuItem disabled={disabled} onClick={handleExportZip}>
      Export as ZIP (SVGs)
    </DropdownMenuItem>
    <DropdownMenuItem disabled={disabled} onClick={handleExportSketchyZip}>
      Export as Sketchy SVGs (ZIP)
    </DropdownMenuItem>
  </DropdownMenuContent>
  ```

  **References**:
  - `apps/web/src/components/icon-library/export-button.tsx:288-310` - current dropdown

  **Acceptance Criteria**:
  - [x] Both new menu items visible
  - [x] Menu items trigger correct handlers
  - [x] Labels clearly indicate experimental nature

  **Commit**: YES
  - Message: `feat(icon-library): add experimental export options for Excalidraw`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`
  - Pre-commit: `bun run build && bun x ultracite check`

---

- [x] 4. Test with fusion-app icon

  **What to do**:
  Use Playwright MCP to test both experimental exports:
  
  1. Start dev server if needed
  2. Navigate to library generator
  3. Create library with fusion-app.svg (from seed folder or upload)
  4. Export using all 3 methods:
     - Current: `.excalidrawlib`
     - Experiment 1: `-clean.excalidrawlib`
     - Experiment 2: `-embedded.excalidrawlib`
  5. Import each into excalidraw.com
  6. Screenshot and compare results
  7. Document findings

  **Test SVG location**: `/packages/backend/seed/palantir-icons/svgs/fusion-app.svg`

  **Expected comparison**:
  - Current: Distorted (as shown in user's screenshot)
  - Clean: Should be cleaner, let Excalidraw control roughness
  - Embedded: Should match preview exactly (but not editable as shapes)

  **Acceptance Criteria**:
  - [x] All 3 exports generated
  - [x] All 3 imported into Excalidraw successfully
  - [x] Screenshots captured for comparison
  - [x] Findings documented in notepad

  **Commit**: NO (testing only)

---

- [x] 5. Test with another Palantir icon

  **What to do**:
  Repeat test with simpler icon (e.g., palantir-ontology.svg - circle with center dot):
  
  1. Export using all 3 methods
  2. Import into Excalidraw
  3. Compare results
  4. Document findings

  **Test SVG location**: `/packages/backend/seed/palantir-icons/svgs/palantir-ontology.svg`

  **Acceptance Criteria**:
  - [x] All 3 exports tested
  - [x] Results compared and documented

  **Commit**: NO (testing only)

---

- [x] 6. Document Results and Recommendation

  **What to do**:
  Create summary in notepad with:
  - Screenshots of all comparisons
  - Pros/cons of each approach
  - Recommendation for which to keep

  **Acceptance Criteria**:
  - [x] Clear comparison table
  - [x] Recommendation with rationale

  **Commit**: NO (documentation only)

---

## Commit Strategy

| After Task | Message | Files |
|------------|---------|-------|
| 3 | `feat(icon-library): add experimental export options for Excalidraw` | export-button.tsx |

---

## Success Criteria

### Expected Outcomes
- **Clean Export**: Should produce less distorted output by letting Excalidraw handle all roughness
- **Embedded Export**: Should produce pixel-perfect match to preview (but as image, not editable shapes)

### Comparison Points
1. Shape fidelity (does it look like the original?)
2. Roughness level (too much? too little? just right?)
3. Editability in Excalidraw (can user modify the shapes?)
4. Color preservation

### Final Checklist
- [x] Both experimental exports work
- [x] Visual comparison documented
- [x] Recommendation provided based on results
