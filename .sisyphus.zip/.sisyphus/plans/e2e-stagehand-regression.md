# E2E Stagehand Regression Suite

## Context

### Original Request
Re-enable E2E regression tests using Stagehand + Browserbase that run on PR preview deployments. Tests should be self-contained (create own data via UI).

GitHub Issue: https://github.com/anand-testcompare/sketchi/issues/20

### Interview Summary
**Key Discussions**:
- Tests disabled via `exit 0` in workflow - need to re-enable
- Two scenarios: visual-sanity (ready) + happy-path (needs setInputFiles update)
- LLM-driven approach preferred for flexibility, but file uploads require deterministic method
- SVG fixtures: copy 3 Palantir icons to test fixtures
- Dark mode toggle: likely timing issue, re-enable with VISUAL_STRICT=false to collect data

**Research Findings**:
- Workflow: `.github/workflows/e2e-web.yml` line 50 has `exit 0`
- visual-sanity.ts: 222 lines, fully implemented, has theme toggle fallback
- happy-path.ts: 176 lines, uses LLM for uploads (won't work with file dialogs)
- svg-uploader.tsx: Hidden file input at line 43-50, NO `data-testid`
- package.json: Only `visual-sanity` script exists, missing `icon-library-generator-happy-path`

### Metis Review
**Identified Gaps** (addressed):
- Missing `data-testid` on file input → Add `data-testid="svg-file-input"`
- Missing package.json script → Add `icon-library-generator-happy-path` script
- File input selector fragility → Use data-testid instead of attribute selector
- Test data cleanup → Noted but not addressed (preview deployments)

---

## Work Objectives

### Core Objective
Re-enable E2E tests so both visual-sanity and icon-library-generator-happy-path scenarios execute on every PR preview deployment, with artifacts uploaded to GitHub Actions.

### Concrete Deliverables
- Workflow file updated with actual test execution command
- SVG fixtures directory with 3 Palantir icons
- Happy-path test updated to use `setInputFiles()` for uploads
- svg-uploader.tsx with `data-testid="svg-file-input"`
- package.json with both scenario scripts

### Definition of Done
- [x] PR preview deployment triggers e2e-web workflow
- [x] Both scenarios execute without `exit 0` bypass
- [x] Artifacts directory contains screenshots and summary files
- [x] No manual intervention required for test execution

### Must Have
- Remove `exit 0` from workflow
- Add `data-testid="svg-file-input"` to file input component
- Create fixtures directory with 3 SVG files
- Update happy-path to use `setInputFiles()`
- Add package.json script for happy-path

### Must NOT Have (Guardrails)
- Do NOT add drag-and-drop testing (future scope)
- Do NOT add reload/persistence verification (too flaky)
- Do NOT validate export file contents (just verify download initiates)
- Do NOT remove `VISUAL_STRICT=false` setting (needed for data collection)
- Do NOT add authentication logic (tests in `unauthenticated/` folder)
- Do NOT reference seed SVGs directly (copy to fixtures to decouple)
- Do NOT add more than 3 fixture icons (minimum viable)

---

## Verification Strategy (MANDATORY)

### Test Decision
- **Infrastructure exists**: YES (Stagehand + Browserbase configured)
- **User wants tests**: Manual verification (E2E tests ARE the tests)
- **Framework**: Stagehand with Playwright underneath

### Manual Execution Verification

Each TODO includes verification via local test run against dev server.

---

## Task Flow

```
Task 1 (Add data-testid) → Task 3 (Update happy-path)
                              ↓
Task 2 (Create fixtures) → Task 3 (Update happy-path)
                              ↓
                          Task 4 (Add package.json script)
                              ↓
                          Task 5 (Update workflow)
                              ↓
                          Task 6 (Local verification)
```

## Parallelization

| Group | Tasks | Reason |
|-------|-------|--------|
| A | 1, 2 | Independent: component change vs file creation |

| Task | Depends On | Reason |
|------|------------|--------|
| 3 | 1, 2 | Needs data-testid and fixture files |
| 4 | 3 | Script needs updated test file |
| 5 | 4 | Workflow needs script to exist |
| 6 | 5 | Verification needs all pieces |

---

## TODOs

- [x] 1. Add data-testid to SVG file input

  **What to do**:
  - Open `apps/web/src/components/icon-library/svg-uploader.tsx`
  - Add `data-testid="svg-file-input"` to the hidden file input element (line 43-50)
  - The input currently has: `accept`, `className`, `multiple`, `onChange`, `ref`, `type`
  - Add `data-testid="svg-file-input"` as an attribute

  **Must NOT do**:
  - Do not change the input's functionality
  - Do not add other test IDs to this component

  **Parallelizable**: YES (with Task 2)

  **References**:
  - `apps/web/src/components/icon-library/svg-uploader.tsx:43-50` - Current file input element without testid
  - `apps/web/src/components/mode-toggle.tsx:28` - Example of existing `data-testid` usage pattern

  **Acceptance Criteria**:
  - [ ] File input has `data-testid="svg-file-input"` attribute
  - [ ] `grep -n "data-testid=\"svg-file-input\"" apps/web/src/components/icon-library/svg-uploader.tsx` returns line number
  - [ ] `bun run check-types` passes (no TypeScript errors)

  **Commit**: YES
  - Message: `test(e2e): add data-testid to svg file input for e2e upload testing`
  - Files: `apps/web/src/components/icon-library/svg-uploader.tsx`

---

- [x] 2. Create SVG fixtures directory with 3 Palantir icons

  **What to do**:
  - Create directory `tests/e2e/fixtures/svgs/`
  - Copy 3 SVG files from `packages/backend/seed/palantir-icons/svgs/`:
    - `palantir-workshop.svg`
    - `palantir-pipeline.svg`
    - `palantir-ontology.svg`
  - These are smaller, simpler icons suitable for testing

  **Must NOT do**:
  - Do not symlink (copy actual files)
  - Do not copy more than 3 icons
  - Do not modify the SVG content

  **Parallelizable**: YES (with Task 1)

  **References**:
  - `packages/backend/seed/palantir-icons/svgs/` - Source directory with 69 SVGs
  - `tests/e2e/` - E2E test root directory

  **Acceptance Criteria**:
  - [ ] Directory exists: `ls tests/e2e/fixtures/svgs/` shows 3 files
  - [ ] Files are valid SVGs: `file tests/e2e/fixtures/svgs/*.svg` shows "SVG" type
  - [ ] Files are under 256KB each (upload limit): `ls -la tests/e2e/fixtures/svgs/`

  **Commit**: YES
  - Message: `test(e2e): add svg fixtures for icon library upload testing`
  - Files: `tests/e2e/fixtures/svgs/palantir-workshop.svg`, `tests/e2e/fixtures/svgs/palantir-pipeline.svg`, `tests/e2e/fixtures/svgs/palantir-ontology.svg`

---

- [x] 3. Update happy-path test to use setInputFiles for uploads

  **What to do**:
  - Open `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts`
  - Replace the `uploadSvgFiles()` function (lines 48-54) to use Playwright's `setInputFiles()`
  - Import `path` and `fileURLToPath` for resolving fixture paths
  - New implementation should:
    1. Get the page from stagehand
    2. Locate the file input using `[data-testid="svg-file-input"]`
    3. Call `setInputFiles()` with array of fixture paths
    4. Wait for upload to complete
  - Keep LLM-driven approach for all other interactions (navigation, verification, export)

  **Must NOT do**:
  - Do not change navigation logic (keep LLM-driven)
  - Do not change verification logic (keep LLM-driven)
  - Do not change export logic (keep LLM-driven)
  - Do not add reload/persistence verification

  **Parallelizable**: NO (depends on Task 1 and 2)

  **References**:
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts:48-54` - Current uploadSvgFiles function using LLM
  - `tests/e2e/src/scenarios/unauthenticated/visual-sanity.ts:60-83` - Pattern for getting page and using Playwright methods
  - Playwright docs: `page.locator().setInputFiles()` - https://playwright.dev/docs/api/class-locator#locator-set-input-files

  **Code Pattern**:
  ```typescript
  import { dirname, join } from "node:path";
  import { fileURLToPath } from "node:url";
  
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename);
  const fixturesDir = join(__dirname, "../../../../fixtures/svgs");
  
  async function uploadSvgFiles(page: any): Promise<void> {
    const fixtures = [
      join(fixturesDir, "palantir-workshop.svg"),
      join(fixturesDir, "palantir-pipeline.svg"),
      join(fixturesDir, "palantir-ontology.svg"),
    ];
    
    await page.locator('[data-testid="svg-file-input"]').setInputFiles(fixtures);
    await sleep(1500); // Wait for uploads to process
  }
  ```

  **Acceptance Criteria**:
  - [ ] `uploadSvgFiles()` uses `page.locator('[data-testid="svg-file-input"]').setInputFiles()`
  - [ ] Function receives `page` parameter (not `stagehand`)
  - [ ] Fixture paths correctly resolve from test file location
  - [ ] `bun run check-types` passes in `tests/e2e/` directory

  **Commit**: YES
  - Message: `test(e2e): use setInputFiles for deterministic svg upload in happy-path`
  - Files: `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts`

---

- [x] 4. Add package.json script for happy-path scenario

  **What to do**:
  - Open `tests/e2e/package.json`
  - Add script entry for `icon-library-generator-happy-path`
  - Follow existing pattern from `visual-sanity` script

  **Must NOT do**:
  - Do not modify dependencies
  - Do not change existing scripts

  **Parallelizable**: NO (depends on Task 3)

  **References**:
  - `tests/e2e/package.json:5` - Existing `visual-sanity` script pattern
  - `tests/e2e/src/scenarios/unauthenticated/icon-library-generator-happy-path.ts` - Target file

  **Acceptance Criteria**:
  - [ ] `bun run icon-library-generator-happy-path --help` doesn't error (script exists)
  - [ ] Script path matches: `src/scenarios/unauthenticated/icon-library-generator-happy-path.ts`

  **Commit**: YES (groups with Task 5)
  - Message: `test(e2e): add package.json scripts and update workflow`
  - Files: `tests/e2e/package.json`, `.github/workflows/e2e-web.yml`

---

- [x] 5. Update GitHub Actions workflow to run both scenarios

  **What to do**:
  - Open `.github/workflows/e2e-web.yml`
  - Remove the `exit 0` bypass (lines 47-50)
  - Replace with actual test execution command
  - Run both scenarios sequentially using `run-scenarios.ts` or individual scripts
  - Keep `STAGEHAND_VISUAL_STRICT: "false"` setting

  **Must NOT do**:
  - Do not remove `STAGEHAND_VISUAL_STRICT: "false"` (needed for data collection)
  - Do not change artifact upload configuration
  - Do not modify secrets or environment variables

  **Parallelizable**: NO (depends on Task 4)

  **References**:
  - `.github/workflows/e2e-web.yml:35-50` - Current run step with exit 0
  - `tests/e2e/scripts/run-scenarios.ts` - Multi-scenario runner (optional to use)

  **New Run Command**:
  ```yaml
  run: |
    cd tests/e2e
    bun run visual-sanity
    bun run icon-library-generator-happy-path
  ```
  
  OR using run-scenarios.ts:
  ```yaml
  run: |
    cd tests/e2e
    bun run scripts/run-scenarios.ts visual-sanity icon-library-generator-happy-path
  ```

  **Acceptance Criteria**:
  - [ ] No `exit 0` in workflow file: `grep -c "exit 0" .github/workflows/e2e-web.yml` returns 0
  - [ ] Run command includes both scenario names
  - [ ] `STAGEHAND_VISUAL_STRICT` remains `"false"`

  **Commit**: YES (groups with Task 4)
  - Message: `test(e2e): add package.json scripts and update workflow`
  - Files: `tests/e2e/package.json`, `.github/workflows/e2e-web.yml`

---

- [x] 6. Local verification of both scenarios

  **What to do**:
  - Start local dev server: `bun run dev`
  - Run visual-sanity locally: `cd tests/e2e && STAGEHAND_ENV=LOCAL STAGEHAND_TARGET_URL=http://localhost:3001 bun run visual-sanity`
  - Run happy-path locally: `cd tests/e2e && STAGEHAND_ENV=LOCAL STAGEHAND_TARGET_URL=http://localhost:3001 bun run icon-library-generator-happy-path`
  - Verify artifacts are created in `tests/e2e/artifacts/`
  - Check for any errors or warnings in output

  **Must NOT do**:
  - Do not skip this step
  - Do not push without local verification

  **Parallelizable**: NO (final verification)

  **References**:
  - `tests/e2e/.env.example` - Environment variable examples
  - `tests/e2e/artifacts/` - Output directory for screenshots and summaries

  **Acceptance Criteria**:
  - [ ] visual-sanity exits with code 0 (or warnings only, no errors)
  - [ ] icon-library-generator-happy-path exits with code 0 (or warnings only)
  - [ ] `ls tests/e2e/artifacts/*.png` shows screenshot files created
  - [ ] `cat tests/e2e/artifacts/e2e-run-summary.txt` shows scenario summaries

  **Commit**: NO (verification only)

---

## Commit Strategy

| After Task(s) | Message | Files |
|---------------|---------|-------|
| 1 | `test(e2e): add data-testid to svg file input for e2e upload testing` | svg-uploader.tsx |
| 2 | `test(e2e): add svg fixtures for icon library upload testing` | fixtures/svgs/*.svg |
| 3 | `test(e2e): use setInputFiles for deterministic svg upload in happy-path` | icon-library-generator-happy-path.ts |
| 4, 5 | `test(e2e): add package.json scripts and update workflow` | package.json, e2e-web.yml |

---

## Success Criteria

### Verification Commands
```bash
# Verify data-testid added
grep "data-testid=\"svg-file-input\"" apps/web/src/components/icon-library/svg-uploader.tsx

# Verify fixtures exist
ls -la tests/e2e/fixtures/svgs/

# Verify package.json scripts
grep "icon-library-generator-happy-path" tests/e2e/package.json

# Verify workflow updated
grep -v "exit 0" .github/workflows/e2e-web.yml | grep -c "bun run"

# Local test run (requires dev server running)
cd tests/e2e && STAGEHAND_ENV=LOCAL STAGEHAND_TARGET_URL=http://localhost:3001 bun run visual-sanity
```

### Final Checklist
- [x] All "Must Have" items present
- [x] All "Must NOT Have" items absent
- [x] Both scenarios execute locally without fatal errors
- [x] Workflow file has no `exit 0` bypass
- [x] TypeScript compiles without errors
