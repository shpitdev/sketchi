# Excalidraw Scene Export (.excalidraw)

## Context

### Original Request
User wants:
1. **New export option**: `.excalidraw` scene format with embedded SVG images (matches UI preview exactly)
2. **Update existing**: Mark `.excalidrawlib` option as "Work in Progress"

### Why This Works
- `.excalidraw` (scene format) **DOES** support the `files` object for embedded images
- `.excalidrawlib` (library format) does NOT support images
- Scene format = open directly in Excalidraw with all icons visible
- Library format = import into library panel for reuse

---

## Work Objectives

### Core Objective
Add `.excalidraw` export that embeds the sketchy SVGs as images, matching the UI preview exactly.

### Concrete Deliverables
1. New `handleExportExcalidrawScene` function
2. New menu item "Export as .excalidraw (Recommended)"
3. Update existing menu item to "Export as .excalidrawlib (WIP)"

### Definition of Done
- [x] New .excalidraw export works
- [x] Embedded images match UI preview
- [x] Menu labels updated
- [x] Build succeeds

---

## TODOs

- [x] 1. Add handleExportExcalidrawScene function

  **What to do**:
  Add new function after `handleExportExcalidraw` in `export-button.tsx`:

  ```typescript
  // Export as .excalidraw scene format with embedded SVG images
  // This matches the UI preview exactly (unlike .excalidrawlib which is vector approximation)
  const handleExportExcalidrawScene = async () => {
    if (icons.length === 0) {
      toast.error("Add at least one icon before exporting.");
      return;
    }

    setIsExporting(true);

    try {
      const elements: Array<{
        type: "image";
        id: string;
        x: number;
        y: number;
        width: number;
        height: number;
        fileId: string;
        status: "saved";
        scale: [number, number];
        version: number;
        versionNonce: number;
        isDeleted: boolean;
        fillStyle: "solid";
        strokeWidth: number;
        strokeStyle: "solid";
        roughness: number;
        opacity: number;
        angle: number;
        strokeColor: string;
        backgroundColor: string;
        seed: number;
        groupIds: string[];
        roundness: null;
        frameId: null;
        boundElements: null;
        updated: number;
        link: null;
        locked: boolean;
      }> = [];

      const files: Record<
        string,
        { mimeType: string; id: string; dataURL: string; created: number }
      > = {};

      const iconSize = 100;
      const padding = 20;
      const iconsPerRow = Math.ceil(Math.sqrt(icons.length));

      for (let i = 0; i < icons.length; i++) {
        const icon = icons[i];
        if (!icon.url) {
          throw new Error(`Missing icon URL for ${icon.name}.`);
        }

        const response = await fetch(icon.url);
        if (!response.ok) {
          throw new Error(`Failed to load ${icon.name}.`);
        }
        const svgText = await response.text();

        // Render through Svg2Roughjs to match UI preview
        const sketchySvg = renderSketchySvg(svgText, icon.name, styleSettings);

        // Convert to base64 data URL
        const svgBlob = new Blob([sketchySvg], { type: "image/svg+xml" });
        const dataURL = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(svgBlob);
        });

        const fileId = randomId();
        const elementId = randomId();

        // Calculate grid position
        const row = Math.floor(i / iconsPerRow);
        const col = i % iconsPerRow;
        const x = col * (iconSize + padding);
        const y = row * (iconSize + padding);

        elements.push({
          type: "image",
          id: elementId,
          x,
          y,
          width: iconSize,
          height: iconSize,
          fileId,
          status: "saved",
          scale: [1, 1],
          version: 1,
          versionNonce: Math.floor(Math.random() * 2 ** 31),
          isDeleted: false,
          fillStyle: "solid",
          strokeWidth: 2,
          strokeStyle: "solid",
          roughness: 0,
          opacity: 100,
          angle: 0,
          strokeColor: "#000000",
          backgroundColor: "transparent",
          seed: Math.floor(Math.random() * 2 ** 31),
          groupIds: [],
          roundness: null,
          frameId: null,
          boundElements: null,
          updated: Date.now(),
          link: null,
          locked: false,
        });

        files[fileId] = {
          mimeType: "image/svg+xml",
          id: fileId,
          dataURL,
          created: Date.now(),
        };
      }

      // Scene format (not library format)
      const payload = {
        type: "excalidraw",
        version: 2,
        source: "https://excalidraw.com",
        elements,
        appState: {
          viewBackgroundColor: "#ffffff",
          gridSize: null,
        },
        files,
      };

      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: "application/vnd.excalidraw+json",
      });

      const fileName = `${sanitizeFileName(libraryName)}.excalidraw`;

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success(`Exported ${icons.length} icons as Excalidraw scene.`);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Export failed unexpectedly.";
      toast.error(message);
    } finally {
      setIsExporting(false);
    }
  };
  ```

  **Insert location**: After `handleExportExcalidraw` function (around line 190), before `handleExportZip`

  **Key differences from library format**:
  - Uses `type: "excalidraw"` (not `"excalidrawlib"`)
  - Has `elements` array (not `libraryItems`)
  - Has `appState` object
  - Has `files` object (works in scene format!)
  - Icons arranged in grid on canvas

  **Acceptance Criteria**:
  - [x] Function added
  - [x] Uses renderSketchySvg (matches UI preview)
  - [x] Creates scene format with files object
  - [x] Icons arranged in grid layout

  **Commit**: NO (groups with task 2)

---

- [x] 2. Update menu items

  **What to do**:
  Update the DropdownMenuContent (around line 298-309):

  **Current**:
  ```tsx
  <DropdownMenuContent align="end">
    <DropdownMenuItem disabled={disabled} onClick={handleExportExcalidraw}>
      Export as .excalidrawlib
    </DropdownMenuItem>

    <DropdownMenuItem disabled={disabled} onClick={handleExportZip}>
      Export as ZIP (SVGs)
    </DropdownMenuItem>
    <DropdownMenuItem disabled={disabled} onClick={handleExportSketchyZip}>
      Export as Sketchy SVGs (ZIP)
    </DropdownMenuItem>
  </DropdownMenuContent>
  ```

  **Change to**:
  ```tsx
  <DropdownMenuContent align="end">
    <DropdownMenuItem
      disabled={disabled}
      onClick={handleExportExcalidrawScene}
    >
      Export as .excalidraw (Recommended)
    </DropdownMenuItem>
    <DropdownMenuItem disabled={disabled} onClick={handleExportExcalidraw}>
      Export as .excalidrawlib (WIP)
    </DropdownMenuItem>

    <DropdownMenuItem disabled={disabled} onClick={handleExportZip}>
      Export as ZIP (SVGs)
    </DropdownMenuItem>
    <DropdownMenuItem disabled={disabled} onClick={handleExportSketchyZip}>
      Export as Sketchy SVGs (ZIP)
    </DropdownMenuItem>
  </DropdownMenuContent>
  ```

  **Changes**:
  1. Add new menu item for `.excalidraw` scene export (first, marked Recommended)
  2. Update `.excalidrawlib` label to include "(WIP)"

  **Acceptance Criteria**:
  - [x] New .excalidraw option at top
  - [x] .excalidrawlib marked as (WIP)
  - [x] Menu order: .excalidraw → .excalidrawlib → ZIP → Sketchy ZIP

  **Commit**: YES
  - Message: `feat(icon-library): add .excalidraw scene export with embedded images`
  - Files: `apps/web/src/components/icon-library/export-button.tsx`
  - Pre-commit: `bun run build && bun x ultracite check`

---

- [x] 3. Test the new export

  **What to do**:
  1. Start dev server (or use existing)
  2. Navigate to library generator
  3. Add some test icons
  4. Test "Export as .excalidraw (Recommended)"
  5. Open the downloaded file in excalidraw.com
  6. Verify icons appear and match UI preview

  **Acceptance Criteria**:
  - [x] Export downloads successfully
  - [x] File opens in Excalidraw
  - [x] Icons visible and match UI preview
  - [x] Icons arranged in grid layout

  **Commit**: NO (testing only)

---

## Commit Strategy

| After Task | Message | Files |
|------------|---------|-------|
| 2 | `feat(icon-library): add .excalidraw scene export with embedded images` | export-button.tsx |

---

## Success Criteria

### Expected Outcomes
- New `.excalidraw` export matches UI preview exactly
- Embedded SVG images render correctly in Excalidraw
- Clear distinction between scene format (recommended) and library format (WIP)

### Menu Order After Changes
1. Export as .excalidraw (Recommended) - NEW
2. Export as .excalidrawlib (WIP) - Updated label
3. Export as ZIP (SVGs)
4. Export as Sketchy SVGs (ZIP)

### Final Checklist
- [x] .excalidraw export works
- [x] Images match UI preview
- [x] .excalidrawlib marked as WIP
- [x] Build passes
