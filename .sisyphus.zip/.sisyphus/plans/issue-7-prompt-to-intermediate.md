# Issue #7: Prompt to IntermediateFormat Agent

## Context

### Original Request
Implement GitHub Issue #7: Create a Convex action that converts raw, unstructured prompts into validated IntermediateFormat using AI SDK v6 ToolLoopAgent pattern with extensible profile registry. Full end-to-end testing required from prompt through to PNG export and Excalidraw share links.

### Interview Summary
**Key Discussions**:
- User explicitly requires full pipeline testing: prompt → intermediate → Excalidraw → share link → PNG
- Must work with ANY scenario, not just hardcoded test cases
- AI SDK v6 ToolLoopAgent pattern is mandatory (not generateObject)
- Profile registry should be extensible for future specialized agents (Palantir/GCP)

**Research Findings**:
- AI SDK 6.0.49 confirmed with `ToolLoopAgent` class, `stepCountIs()`, `tool()` exports
- Existing `content-analyzer.ts` has good system prompt to build from
- `validateEdgeReferences()` exists in `diagram-renderer.ts` for referential integrity
- Share link encryption and PNG rendering functions already tested

### Metis Review
**Identified Gaps** (addressed):
- Convex 60s timeout concern → Agent runs outside Convex, thin wrapper for action
- Validation feedback format → Use structured errors for LLM to self-correct
- Exhausted retries behavior → Throw with accumulated errors (no silent failures)
- Gateway + ToolLoopAgent combination untested → Added spike task

---

## Work Objectives

### Core Objective
Create a production-ready Convex action that uses AI SDK v6 ToolLoopAgent to convert any natural language prompt into validated IntermediateFormat, with extensible profile support and comprehensive end-to-end testing.

### Concrete Deliverables
- `packages/backend/lib/agents/types.ts` - Profile types and validation result schema
- `packages/backend/lib/agents/profiles/general.ts` - General system prompt profile
- `packages/backend/lib/agents/intermediate-generator.ts` - ToolLoopAgent implementation
- `packages/backend/lib/agents/index.ts` - Profile registry with getProfile()
- `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts` - Convex action wrapper
- `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts` - Comprehensive E2E test
- Test artifacts in `packages/backend/test-results/prompt-intermediate-*.json`
- Summary report in `packages/backend/test-results/prompt-intermediate-summary.md`

### Definition of Done
- [x] `bun run dev` passes with no type errors
- [x] `bun run test --filter diagramGenerateIntermediateFromPrompt` passes
- [x] Test artifacts include PNG files, share links, and original prompts for each scenario
- [x] All artifacts committed to `packages/backend/test-results/`
- [x] Issue #7 acceptance criteria checklist complete

### Must Have
- ToolLoopAgent with validation tool (NOT generateObject pattern)
- Max 5 iteration limit via `stopWhen: stepCountIs(5)`
- Referential integrity validation (all edges reference existing nodes)
- Profile registry with `getProfile(id)` function
- Full pipeline test: prompt → intermediate → diagram → share link → PNG
- Two test scenarios from issue + one "adversarial" scenario
- Convex logging with traceId, linked events

### Must NOT Have (Guardrails)
- NO hardcoded scenario handling - agent must work for arbitrary prompts
- NO Excalidraw terminology in IntermediateFormat (use nodes/edges/graphOptions)
- NO HTTP mocking in tests - use real LLM calls
- NO silent failures on validation exhaustion - throw with errors
- NO specialized profiles in this PR (general only)
- NO UI changes
- NO changes to existing IntermediateFormat schema

---

## Verification Strategy (MANDATORY)

### Test Decision
- **Infrastructure exists**: YES (Vitest + convex-test)
- **User wants tests**: YES (mandatory from issue requirements)
- **Framework**: Vitest with convex-test
- **QA approach**: Automated tests with real LLM + visual artifact generation

### Test Pattern
Following `visualGrading.test.ts` structure:
1. Run scenario through full pipeline
2. Save JSON artifacts (intermediate, diagram, share link)
3. Save PNG artifact
4. Write summary.md with all results
5. Assert on structural validity (not exact content)

---

## Task Flow

```
1 (spike) → 2 (types) → 3 (profile) → 4 (agent) → 5 (registry)
                                           ↓
                                      6 (action) → 7 (test) → 8 (docs)
```

## Parallelization

| Task | Depends On | Reason |
|------|------------|--------|
| 2 | 1 | Need spike confirmation before building |
| 3 | 2 | Profile needs types |
| 4 | 2, 3 | Agent needs types and profile |
| 5 | 3, 4 | Registry needs profile and agent |
| 6 | 4, 5 | Action needs agent and registry |
| 7 | 6 | Test needs action |
| 8 | 7 | Docs after everything works |

---

## TODOs

- [x] 0. Spike: Verify ToolLoopAgent + gateway() + Output.object compatibility

  **What to do**:
  - Create minimal test script at `packages/backend/experiments/tests/spike-toolloop-agent.ts`
  - Test pattern:
    ```typescript
    import { ToolLoopAgent, Output, tool, stepCountIs, gateway } from 'ai';
    const agent = new ToolLoopAgent({
      model: gateway("google/gemini-3-flash"),
      output: Output.object({ schema: z.object({ test: z.string() }) }),
      tools: { validate: tool({ ... }) },
      stopWhen: stepCountIs(3),
    });
    const result = await agent.generate({ prompt: "test" });
    console.log(result.output);
    ```
  - Run: `AI_GATEWAY_API_KEY=... bun run packages/backend/experiments/tests/spike-toolloop-agent.ts`
  - Confirm: output is typed, tools are called, loop terminates

  **Must NOT do**:
  - Do NOT implement full validation logic yet
  - Do NOT create production files

  **Parallelizable**: NO (blocking - must pass before continuing)

  **References**:
  - `packages/backend/experiments/lib/ai-utils.ts:129-131` - gateway() function pattern
  - `packages/backend/node_modules/ai/dist/index.d.ts` - ToolLoopAgent exports (see grep output)
  - AI SDK docs: https://ai-sdk.dev/docs/agents/building-agents

  **Acceptance Criteria**:
  - [ ] Spike script runs without errors
  - [ ] Agent returns typed output matching schema
  - [ ] Tools are invoked (confirmed via console.log in execute)
  - [ ] Loop terminates at stopWhen condition or on success
  - [ ] Command: `bun run packages/backend/experiments/tests/spike-toolloop-agent.ts` → exits 0

  **Commit**: NO (experimental, delete after confirming)

---

- [x] 1. Create agent type definitions

  **What to do**:
  - Create `packages/backend/lib/agents/types.ts`
  - Define interfaces:
    ```typescript
    export interface ValidationResult {
      ok: boolean;
      errors?: ValidationError[];
    }
    
    export interface ValidationError {
      type: 'schema' | 'reference' | 'semantic';
      path?: string;
      message: string;
      suggestion?: string;
    }
    
    export interface PromptAgentProfile {
      id: string;
      description: string;
      instructions: string;
      validate?: (intermediate: IntermediateFormat) => ValidationResult;
    }
    
    export interface GenerateIntermediateResult {
      intermediate: IntermediateFormat;
      profileId: string;
      iterations: number;
      tokens: number;
      durationMs: number;
      traceId: string;
    }
    ```
  - Export validation result Zod schema for tool input

  **Must NOT do**:
  - Do NOT add any profile-specific logic here
  - Do NOT import from experiments/

  **Parallelizable**: NO (depends on spike)

  **References**:
  - `packages/backend/lib/diagram-intermediate.ts:1-118` - IntermediateFormat types to import
  - `packages/backend/lib/diagram-renderer.ts:76-93` - validateEdgeReferences pattern

  **Acceptance Criteria**:
  - [ ] File exists at `packages/backend/lib/agents/types.ts`
  - [ ] TypeScript compiles without errors
  - [ ] `bun run check-types` → passes (workdir: packages/backend)
  - [ ] All interfaces exported and documented with JSDoc

  **Commit**: YES
  - Message: `feat(backend): add prompt agent type definitions`
  - Files: `packages/backend/lib/agents/types.ts`

---

- [x] 2. Create general profile with system prompt

  **What to do**:
  - Create `packages/backend/lib/agents/profiles/general.ts`
  - Port and refine system prompt from `content-analyzer.ts`
  - Export profile object matching `PromptAgentProfile` interface
  - Include:
    - Chart type selection guidelines (23 types)
    - Node/edge extraction rules
    - Shape guidelines (rectangle, ellipse, diamond)
    - Layout direction recommendations (TB, LR, BT, RL)
  - Add profile-specific validation: at least 2 nodes, at least 1 edge for non-trivial diagrams

  **Must NOT do**:
  - Do NOT include any Excalidraw-specific terminology in prompt
  - Do NOT hardcode specific scenarios

  **Parallelizable**: NO (depends on types)

  **References**:
  - `packages/backend/experiments/agents/content-analyzer.ts:13-70` - Existing system prompt to refine
  - `packages/backend/lib/diagram-intermediate.ts:3-27` - DiagramTypeSchema for chart types

  **Acceptance Criteria**:
  - [ ] File exists at `packages/backend/lib/agents/profiles/general.ts`
  - [ ] Exports `generalProfile` matching PromptAgentProfile interface
  - [ ] System prompt covers all 23 diagram types
  - [ ] No Excalidraw terminology in prompt (search for "excalidraw")
  - [ ] `bun run check-types` → passes

  **Commit**: YES
  - Message: `feat(backend): add general prompt agent profile`
  - Files: `packages/backend/lib/agents/profiles/general.ts`

---

- [x] 3. Implement ToolLoopAgent-based generator

  **What to do**:
  - Create `packages/backend/lib/agents/intermediate-generator.ts`
  - Implement `generateIntermediate(prompt: string, options?: { profileId?: string })`:
    ```typescript
    import { ToolLoopAgent, Output, tool, stepCountIs, gateway } from 'ai';
    
    export async function generateIntermediate(
      prompt: string,
      options: GenerateOptions = {}
    ): Promise<GenerateIntermediateResult> {
      const traceId = crypto.randomUUID();
      const profile = getProfile(options.profileId ?? 'general');
      
      const agent = new ToolLoopAgent({
        model: gateway('google/gemini-3-flash'),
        instructions: profile.instructions,
        output: Output.object({ schema: IntermediateFormatSchema }),
        tools: {
          validateIntermediate: tool({
            description: 'Validate the generated IntermediateFormat. Call this after generating to check for errors.',
            inputSchema: IntermediateFormatSchema,
            execute: async (intermediate) => {
              const errors: ValidationError[] = [];
              
              // 1. Referential integrity
              const refErrors = validateEdgeReferences(intermediate.nodes, intermediate.edges);
              for (const msg of refErrors) {
                errors.push({ type: 'reference', message: msg });
              }
              
              // 2. Semantic checks
              if (intermediate.nodes.length === 0) {
                errors.push({ type: 'semantic', message: 'At least one node required' });
              }
              
              // 3. Profile validation
              if (profile.validate) {
                const profileResult = profile.validate(intermediate);
                if (!profileResult.ok && profileResult.errors) {
                  errors.push(...profileResult.errors);
                }
              }
              
              return errors.length === 0
                ? { ok: true }
                : { ok: false, errors: errors.map(e => `${e.type}: ${e.message}`) };
            },
          }),
        },
        stopWhen: stepCountIs(5),
        onStepFinish: ({ usage, toolCalls }) => {
          console.log(`[${traceId}] Step: tools=${toolCalls?.length ?? 0}, tokens=${usage.totalTokens}`);
        },
      });
      
      const start = Date.now();
      const result = await agent.generate({ prompt });
      
      if (!result.output) {
        throw new Error(`Validation failed after ${result.steps.length} attempts: ${JSON.stringify(result.steps.map(s => s.toolCalls))}`);
      }
      
      return {
        intermediate: result.output,
        profileId: options.profileId ?? 'general',
        iterations: result.steps.length,
        tokens: result.usage.totalTokens,
        durationMs: Date.now() - start,
        traceId,
      };
    }
    ```
  - Handle edge case: output is undefined (exhausted retries)
  - Log each step with traceId

  **Must NOT do**:
  - Do NOT use generateObject or generateObjectWithRetry (must use ToolLoopAgent)
  - Do NOT catch and swallow errors silently
  - Do NOT hardcode any specific prompts

  **Parallelizable**: NO (depends on types and profile)

  **References**:
  - `packages/backend/experiments/lib/ai-utils.ts:129-131` - gateway() usage
  - `packages/backend/lib/diagram-renderer.ts:76-93` - validateEdgeReferences to reuse
  - `packages/backend/lib/diagram-intermediate.ts:108-115` - IntermediateFormatSchema

  **Acceptance Criteria**:
  - [ ] File exists at `packages/backend/lib/agents/intermediate-generator.ts`
  - [ ] Uses ToolLoopAgent (NOT generateObject)
  - [ ] Exports `generateIntermediate()` function
  - [ ] Returns typed `GenerateIntermediateResult`
  - [ ] Throws on validation exhaustion (no silent failures)
  - [ ] `bun run check-types` → passes

  **Commit**: YES
  - Message: `feat(backend): implement ToolLoopAgent-based intermediate generator`
  - Files: `packages/backend/lib/agents/intermediate-generator.ts`

---

- [x] 4. Create profile registry

  **What to do**:
  - Create `packages/backend/lib/agents/index.ts`
  - Implement registry:
    ```typescript
    import { generalProfile } from './profiles/general';
    import type { PromptAgentProfile } from './types';
    
    const profiles: Map<string, PromptAgentProfile> = new Map([
      ['general', generalProfile],
    ]);
    
    export function getProfile(id: string): PromptAgentProfile {
      const profile = profiles.get(id);
      if (!profile) {
        console.warn(`Profile '${id}' not found, falling back to 'general'`);
        return profiles.get('general')!;
      }
      return profile;
    }
    
    export function listProfiles(): string[] {
      return Array.from(profiles.keys());
    }
    
    export * from './types';
    export { generateIntermediate } from './intermediate-generator';
    ```
  - Log warning when falling back to general

  **Must NOT do**:
  - Do NOT throw on unknown profile (fallback with warning)
  - Do NOT implement specialized profiles yet

  **Parallelizable**: NO (depends on profile and agent)

  **References**:
  - `packages/backend/lib/agents/profiles/general.ts` - General profile to register
  - `packages/backend/lib/agents/intermediate-generator.ts` - Generator to export

  **Acceptance Criteria**:
  - [ ] File exists at `packages/backend/lib/agents/index.ts`
  - [ ] Exports `getProfile()`, `listProfiles()`, `generateIntermediate()`
  - [ ] Unknown profile falls back to 'general' with console.warn
  - [ ] `bun run check-types` → passes

  **Commit**: YES
  - Message: `feat(backend): add prompt agent profile registry`
  - Files: `packages/backend/lib/agents/index.ts`

---

- [x] 5. Create Convex action wrapper

  **What to do**:
  - Create `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts`
  - Implement thin action wrapper:
    ```typescript
    import { v } from "convex/values";
    import { action } from "./_generated/server";
    import { generateIntermediate } from "../lib/agents";
    
    export const generateIntermediateFromPrompt = action({
      args: {
        prompt: v.string(),
        profileId: v.optional(v.string()),
      },
      handler: async (ctx, args) => {
        const result = await generateIntermediate(args.prompt, {
          profileId: args.profileId,
        });
        
        // Log with Convex pattern
        console.log(JSON.stringify({
          event: 'intermediate_generated',
          traceId: result.traceId,
          profileId: result.profileId,
          nodeCount: result.intermediate.nodes.length,
          edgeCount: result.intermediate.edges.length,
          iterations: result.iterations,
          tokens: result.tokens,
          durationMs: result.durationMs,
        }));
        
        return result;
      },
    });
    ```
  - Use Convex structured logging pattern

  **Must NOT do**:
  - Do NOT add complex logic in action (keep thin)
  - Do NOT catch errors (let Convex handle)

  **Parallelizable**: NO (depends on agent and registry)

  **References**:
  - `packages/backend/convex/diagramGenerateFromIntermediate.ts:1-42` - Existing action pattern
  - `packages/backend/lib/agents/index.ts` - Agent to import

  **Acceptance Criteria**:
  - [ ] File exists at `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts`
  - [ ] Action is named `generateIntermediateFromPrompt`
  - [ ] Appears in generated API (check `convex/_generated/api.d.ts` after `bun run dev:server`)
  - [ ] Logs structured event with traceId
  - [ ] `bun run check-types` → passes (workdir: packages/backend)

  **Commit**: YES
  - Message: `feat(backend): add Convex action for prompt to intermediate conversion`
  - Files: `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts`

---

- [x] 6. Create comprehensive E2E test with full pipeline

  **What to do**:
  - Create `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts`
  - Follow `visualGrading.test.ts` pattern exactly
  - Three test scenarios:
    1. **SME interview transcript (pharma)**: Voice-to-text interview about batch disposition process
    2. **Rambling technical narration**: Unstructured with mid-course correction
    3. **Adversarial edge case**: Very short prompt ("user login flow")
  - For each scenario:
    - Call `generateIntermediateFromPrompt` action
    - Call `generateDiagramFromIntermediate` action
    - Call `createExcalidrawShareLink` on elements
    - Call `renderDiagramToPng` for PNG
    - Save artifacts: `prompt-intermediate-{slug}.json`, `prompt-intermediate-{slug}.png`
    - Record: original prompt, share link URL, intermediate, timings
  - Write summary to `packages/backend/test-results/prompt-intermediate-summary.md`

  **Must NOT do**:
  - Do NOT mock HTTP calls
  - Do NOT hardcode expected node/edge counts (validate structurally)
  - Do NOT assert on exact content (LLM output varies)

  **Parallelizable**: NO (depends on action)

  **References**:
  - `packages/backend/convex/visualGrading.test.ts:1-378` - Test pattern to follow exactly
  - `packages/backend/convex/diagramGenerateFromIntermediate.ts` - Existing action to call
  - `packages/backend/experiments/lib/render-png.ts:126-136` - renderDiagramToPng usage
  - `packages/backend/convex/lib/excalidrawShareLinks.ts:18-65` - createExcalidrawShareLink

  **Acceptance Criteria**:
  - [ ] Test file exists at `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts`
  - [ ] Command: `cd packages/backend && bun run test --filter diagramGenerateIntermediateFromPrompt`
  - [ ] All 3 scenarios pass (allow 1 failure for LLM variance)
  - [ ] Artifacts generated:
    - `test-results/prompt-intermediate-pharma-interview.json`
    - `test-results/prompt-intermediate-pharma-interview.png`
    - `test-results/prompt-intermediate-rambling-tech.json`
    - `test-results/prompt-intermediate-rambling-tech.png`
    - `test-results/prompt-intermediate-short-prompt.json`
    - `test-results/prompt-intermediate-short-prompt.png`
    - `test-results/prompt-intermediate-summary.md`
  - [ ] Each JSON artifact contains: `{ prompt, shareUrl, intermediate, tokens, durationMs }`
  - [ ] Each PNG is a valid image (file size > 1KB)
  - [ ] Summary.md contains table with all scenarios and pass/fail status

  **Commit**: YES
  - Message: `test(backend): add comprehensive E2E test for prompt to intermediate pipeline`
  - Files: `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts`

---

- [x] 7. Update documentation

  **What to do**:
  - Update `packages/backend/experiments/README.md`:
    - Add entry for prompt→IntermediateFormat (now migrated to Convex)
    - Mark content-analyzer.ts as superseded
  - Update `docs/TODO.md` (if exists) or create brief notes
  - Add JSDoc to all exported functions in `lib/agents/`

  **Must NOT do**:
  - Do NOT create new README files (update existing)
  - Do NOT write lengthy documentation (brief updates only)

  **Parallelizable**: NO (depends on test passing)

  **References**:
  - `packages/backend/experiments/README.md` - Existing experiments doc to update
  - `packages/backend/lib/agents/index.ts` - Functions needing JSDoc

  **Acceptance Criteria**:
  - [ ] `experiments/README.md` updated with migration status
  - [ ] All exported functions have JSDoc comments
  - [ ] `bun run check-types` → passes

  **Commit**: YES
  - Message: `docs(backend): update experiments README and add agent JSDoc`
  - Files: `packages/backend/experiments/README.md`, `packages/backend/lib/agents/*.ts`

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1 | `feat(backend): add prompt agent type definitions` | lib/agents/types.ts | bun run check-types |
| 2 | `feat(backend): add general prompt agent profile` | lib/agents/profiles/general.ts | bun run check-types |
| 3 | `feat(backend): implement ToolLoopAgent-based intermediate generator` | lib/agents/intermediate-generator.ts | bun run check-types |
| 4 | `feat(backend): add prompt agent profile registry` | lib/agents/index.ts | bun run check-types |
| 5 | `feat(backend): add Convex action for prompt to intermediate conversion` | convex/diagramGenerateIntermediateFromPrompt.ts | bun run dev passes |
| 6 | `test(backend): add comprehensive E2E test for prompt to intermediate pipeline` | convex/diagramGenerateIntermediateFromPrompt.test.ts, test-results/* | bun run test passes |
| 7 | `docs(backend): update experiments README and add agent JSDoc` | experiments/README.md, lib/agents/*.ts | bun run check-types |

---

## Success Criteria

### Verification Commands
```bash
# Type check
cd packages/backend && bun run check-types
# Expected: exits 0

# Run test suite
cd packages/backend && bun run test --filter diagramGenerateIntermediateFromPrompt
# Expected: 3/3 scenarios pass (or 2/3 with LLM variance tolerance)

# Verify artifacts exist
ls packages/backend/test-results/prompt-intermediate-*.json
# Expected: 3 JSON files

ls packages/backend/test-results/prompt-intermediate-*.png
# Expected: 3 PNG files

cat packages/backend/test-results/prompt-intermediate-summary.md
# Expected: Markdown table with scenario results, share links
```

### Final Checklist
- [x] All "Must Have" present (ToolLoopAgent, validation tool, profile registry, full pipeline test)
- [x] All "Must NOT Have" absent (no hardcoding, no Excalidraw terms in intermediate, no HTTP mocks)
- [x] All tests pass
- [x] Artifacts contain: original prompt, share link URL, PNG file
- [x] Issue #7 acceptance criteria met
