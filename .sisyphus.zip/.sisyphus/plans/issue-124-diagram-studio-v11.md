# Issue #124 - Diagram Studio v1.1 UX Polish + Recents + E2E Coverage

## TL;DR

> **Quick Summary**: Polish Diagram Studio v1 by replacing internal "Restructure" terminology with user-facing copy, routing blank-canvas prompts through a true generate-from-prompt pipeline, adding clear in-sidebar progress + completion feedback, adding client-only "Recent diagrams" (localStorage), and expanding Stagehand E2E screenshot coverage so regressions are visually reviewable.
>
> **Deliverables**:
> - Updated studio UI: `apps/web/src/components/diagram-studio/chat-sidebar.tsx`
> - Updated session page wiring + skeleton: `apps/web/src/app/diagrams/[sessionId]/page.tsx`
> - Updated landing + client recents: `apps/web/src/app/diagrams/page.tsx`
> - New Convex studio generate action: `packages/backend/convex/diagrams.ts`
> - Backend tests: `packages/backend/convex/diagrams.test.ts`
> - Expanded E2E screenshots: `tests/e2e/src/scenarios/unauthenticated/diagram-studio-happy-path.ts`, `tests/e2e/src/scenarios/unauthenticated/diagram-studio-occ-conflict.ts`
>
> **Estimated Effort**: Medium
> **Parallel Execution**: YES - 3 waves
> **Critical Path**: Backend action + web prompt routing -> E2E updates -> CI green loop

---

## Context

### Original Request
Create a single end-to-end plan to implement GitHub issue #124, including tests, lint/format/typecheck/build, commits, push, PR creation, and an iterate-until-green loop (CodeRabbit + GitHub Actions) so the only manual step left is merge.

### Issue #124 Summary (source of truth)
Issue: https://github.com/anand-testcompare/sketchi/issues/124

Key requested changes:
- Chat sidebar should not be labeled `Restructure`; use user-facing copy (default: `AI Assistant`).
- Destructive warning must be conditional (only relevant on non-empty canvas).
- Blank canvas prompt must use a generate-from-prompt backend path (not `diagrams.restructureFromScene`).
- During AI work, show an in-sidebar status row (`Generating...` or `Updating...`, optionally elapsed seconds). Clear on completion; subtle completion affordance; do NOT append synthetic assistant success message.
- `/diagrams/:sessionId` initial loading should show a studio-shaped skeleton (not a centered spinner).
- `/diagrams` landing should feel intentional and include a client-only recents list (localStorage) with a capability-token warning.
- Expand Stagehand E2E screenshot coverage (happy path + OCC conflict banner/resolution + import/export intermediate states).

Constraints / Non-goals:
- No auth, no server-side session listing, capability-token session URLs.
- Do not persist chat to Convex / agent threads.
- Do not change restructure semantics on non-empty diagrams.

---

## Work Objectives

### Core Objective
Make Diagram Studio v1 feel finished and less anxiety-inducing while preserving v1 semantics, and harden regressions by capturing key UI states in E2E screenshots.

### Concrete Deliverables
- Web UI polish + correct semantics for empty vs non-empty prompt routing.
- New Convex action `diagrams.generateFromPromptForStudio` that returns elements (no share link).
- Backend tests validating new action + keeping current contract (no shareLink/intermediate exposure).
- Stagehand E2E scenarios updated to capture and (lightly) assert:
  - Landing, empty canvas, generating/updating status, recents list, import/export UI, conflict banner, conflict resolved.

### Definition of Done
- All Acceptance Criteria AC1-AC9 from issue #124 are satisfied.
- Local verification passes:
  - `bun x ultracite fix` (no unformatted diffs afterward)
  - `bun x ultracite check` (PASS)
  - `bun run check-types` (PASS)
  - `bun run build` (PASS)
  - `cd packages/backend && bunx convex codegen && bun run test` (PASS)
- Stagehand scenarios pass locally OR pass on Vercel preview (and artifacts include the requested screenshots).
- PR is open, checks are green, CodeRabbit feedback is resolved, and no failing Actions remain.

### Must NOT Have (guardrails)
- No auth, ownership, or server-side session listing.
- No chat persistence to Convex.
- No redesign beyond what is required to make `/diagrams` and initial load feel intentional.
- No new animation libraries (use CSS only for completion pulse).
- No hardcoded theme-breaking colors (prefer existing tokens like `bg-muted`, `text-muted-foreground`).
- No emojis in UI.

---

## Verification Strategy (MANDATORY)

> UNIVERSAL RULE: ZERO HUMAN INTERVENTION
>
> Every task in this plan must be verifiable by the executing agent via commands and automated tooling.
> Visual checks must be done via Stagehand `captureScreenshot` + OpenRouter vision review and/or Playwright automation screenshots.

### Test Decision
- **Infrastructure exists**: YES
- **Automated tests**: Tests-after (E2E + backend Vitest)
- **Frameworks**:
  - Backend: Vitest + `convex-test` (`packages/backend/convex/*.test.ts`)
  - Web unit: Vitest (`apps/web/vitest.config.ts`) (optional for this issue)
  - E2E: Stagehand (`tests/e2e/src/scenarios/**`) with screenshot artifacts

### Agent-Executed QA Scenarios (global)

The executor must run and capture evidence for:
- Stagehand happy path scenario (with new screenshots)
- Stagehand OCC conflict scenario (with new screenshots)
- Backend unit tests for new Convex action

Evidence locations:
- Stagehand screenshots: `tests/e2e/artifacts/*.png` (see `tests/e2e/src/runner/config.ts` default)
- Backend reports (CI): `packages/backend/test-results/vitest.json`, `packages/backend/test-results/summary.md`

---

## Execution Strategy

### Parallel Execution Waves

Wave 1 (Start Immediately):
- Task 1 (Backend: studio generate action + tests)
- Task 2 (Web: ChatSidebar copy/warning/status row/autoscroll)
- Task 4 (Web: /diagrams landing polish + client-only recents)

Wave 2 (After Wave 1):
- Task 3 (Web: session page wiring: generate vs restructure, skeleton, live element count, completion pulse, recents write)

Wave 3 (After Wave 2):
- Task 5 (E2E: happy path screenshots + blank-canvas prompt + recents assertions)
- Task 6 (E2E: OCC conflict screenshots)
- Task 7 (Full verification: lint/typecheck/build/tests)
- Task 8-9 (Git/PR + CI iteration)

Critical Path: 1 -> 3 -> 5/6 -> 8/9

---

## TODOs

### 0. Preflight: create branch + baseline check

**What to do**:
- Ensure working tree is clean enough to start (do not revert unrelated user changes).
- Create a new branch with a prefix (issue is `enhancement`): `feature/issue-124-diagram-studio-v11`.
- Install deps if needed: `bun install`.
- Run a baseline of key commands to know current status:
  - `bun x ultracite check`
  - `bun run check-types`
  - `bun run build`

**Recommended Agent Profile**:
- Category: `quick`
- Skills: `git-master`

**Parallelization**: NO (foundation)

**References**:
- `AGENTS.md` - repo pre-push sanity commands and workflow expectations.

**Acceptance Criteria (agent-executable)**:
- Branch exists and is checked out: `git branch --show-current` contains `feature/issue-124-diagram-studio-v11`.
- `bun x ultracite check` exits 0 OR failures are recorded as baseline notes.

**QA Scenario**:
Scenario: Ensure baseline dev workflow is runnable
  Tool: Bash
  Steps:
    1. `bun install`
    2. `bun x ultracite check`
    3. `bun run check-types`
    4. `bun run build`
  Expected Result: Commands complete; any existing failures are known before changes.

---

### 1. Backend: add `diagrams.generateFromPromptForStudio` (no share link) + tests

**What to do**:
- Add a new Convex action in `packages/backend/convex/diagrams.ts`:
  - Name: `diagrams.generateFromPromptForStudio`
  - Input: `{ prompt: string; traceId?: string; sessionId?: string }` (match issue suggestion; include sessionId for logging only)
  - Output: `{ status: "success" | "failed"; elements?: unknown[]; appState?: Record<string, unknown>; issues?; reason?; stats }`
  - Must NOT create Excalidraw share link.
  - Reuse existing pipeline pieces from `packages/backend/convex/diagrams.ts`:
    - `generateIntermediate` -> `IntermediateFormatSchema.safeParse` -> `renderIntermediateDiagram`
  - Follow existing `createLoggedAction` patterns for args/result logging.

- Add Vitest coverage in `packages/backend/convex/diagrams.test.ts`:
  - Success case: action returns `status=success`, `elements.length > 0`, has `stats.traceId`, and does NOT include `shareLink` or `intermediate` keys.
  - Failure case: mock `generateIntermediate` to throw; action returns `status=failed` with `issues` including `ai-error` (mirror `restructureFromScene` behavior).

**Must NOT do**:
- Do not modify existing `diagrams.generateDiagram` contract.
- Do not add share-link creation for studio path.

**Recommended Agent Profile**:
- Category: `unspecified-high`
- Skills: (none required)

**Parallelization**: YES (Wave 1)

**References**:
- `packages/backend/convex/diagrams.ts:209` - existing `generateDiagram` pipeline including share link creation.
- `packages/backend/convex/diagrams.ts:570` - `restructureFromSceneAction` contract (no share link).
- `packages/backend/convex/diagrams.ts:824` - `export const restructureFromScene` pattern for returning elements only.
- `packages/backend/convex/diagrams.test.ts:237` - tests asserting `restructureFromScene` returns elements with no `shareLink`/`intermediate`.
- `packages/backend/lib/agents/index.ts` - `generateIntermediate` export (used by diagrams.ts).
- `packages/backend/lib/diagram-renderer.ts` - `renderIntermediateDiagram` return shape.

**Acceptance Criteria (agent-executable)**:
- `cd packages/backend && bunx convex codegen` succeeds.
- `cd packages/backend && bun run test` passes, including new tests for `generateFromPromptForStudio`.

**QA Scenarios**:
Scenario: Backend action returns elements (no share link)
  Tool: Bash
  Preconditions: Backend deps installed
  Steps:
    1. `cd packages/backend && bunx convex codegen`
    2. `cd packages/backend && bun run test diagrams.test.ts`
  Expected Result: Vitest PASS; new action test validates no share link.

---

### 2. Web: ChatSidebar terminology + conditional warning + status row + autoscroll

**What to do**:
- Update `apps/web/src/components/diagram-studio/chat-sidebar.tsx`:
  - Rename header from `Restructure` to `AI Assistant` (default; adjust if desired).
  - Add `nonDeletedElementCount` (or `isCanvasEmpty`) prop.
  - Placeholder copy:
    - Empty canvas: `Describe your diagram...`
    - Non-empty canvas: `Describe changes to your diagram...`
  - Render destructive warning ONLY when non-empty.
  - Replace "assistant success message" reliance by adding a status row area:
    - When processing empty canvas: show `Generating...`
    - When processing non-empty: show `Updating...`
    - Optional elapsed seconds after ~2s.
  - Ensure the messages list autoscrolls to the latest user prompt (use existing `messagesEndRef` + `useEffect`).
  - Add testids for stable E2E assertions:
    - `diagram-chat-header`
    - `diagram-chat-placeholder`
    - `diagram-status-row`
    - Keep existing `diagram-restructure-warning` testid on the warning container.

**Must NOT do**:
- Do not show destructive warning on empty canvas.
- Do not introduce new dependencies.

**Recommended Agent Profile**:
- Category: `visual-engineering`
- Skills: `frontend-ui-ux`

**Parallelization**: YES (Wave 1)

**References**:
- `apps/web/src/components/diagram-studio/chat-sidebar.tsx` - current header, warning, placeholder, and missing autoscroll.
- `tests/e2e/src/scenarios/unauthenticated/diagram-studio-happy-path.ts` - expects `diagram-restructure-warning` to exist when non-empty.

**Acceptance Criteria (agent-executable)**:
- On empty canvas, E2E can assert:
  - header text is not `Restructure`
  - placeholder text equals `Describe your diagram...`
  - `diagram-restructure-warning` is absent
- On non-empty canvas, `diagram-restructure-warning` exists.

**QA Scenarios**:
Scenario: Empty canvas sidebar copy is correct
  Tool: Stagehand (E2E)
  Steps:
    1. Create new session (empty canvas)
    2. Assert header and placeholder
    3. Assert warning absent
  Expected Result: Sidebar feels jargon-free and non-anxiety-inducing.

---

### 3. Web: session page prompt routing + live element count + skeleton + completion pulse + recents write

**What to do**:
- Update `apps/web/src/app/diagrams/[sessionId]/page.tsx`:
  - Rename `handleRestructure` -> `handlePrompt` (or similar) since it now routes generate vs restructure.
  - Track live non-deleted element count from Excalidraw scene:
    - Use `excalidrawApi.getSceneElements()` and filter `isDeleted !== true`.
    - Do NOT rely only on `session.latestScene?.elements?.length`.
    - Pass this count to ChatSidebar so warning + placeholder respond instantly.
  - Prompt routing:
    - If live non-deleted count is 0: call new backend action `api.diagrams.generateFromPromptForStudio`.
    - Else: keep current `api.diagrams.restructureFromScene` flow.
  - Progress + completion feedback:
    - Replace `isRestructuring` with a broader `isProcessing` (or `processingMode: "generating" | "updating" | null`).
    - Show status row in ChatSidebar while in-flight.
    - Remove synthetic success message append:
      - Delete `setChatMessages(... "Restructured diagram")` (currently at `apps/web/src/app/diagrams/[sessionId]/page.tsx:281`).
      - Keep explicit errors (toast + assistant bubble is acceptable per issue).
    - Add subtle completion affordance (CSS-only pulse on sidebar header/status row or container) after success.
  - Loading affordance:
    - Replace centered spinner shown when `session === undefined` with a studio-shaped skeleton.
    - Add `data-testid="diagram-studio-skeleton"` for E2E screenshot.
  - Client-only recents write:
    - On mount (when `sessionId` exists), write to localStorage key (new): `sketchi.diagramRecents.v1`.
    - Store shape: `Array<{ sessionId: string; visitedAt: number }>`.
    - Behavior: dedup by `sessionId`, move to top, cap length at 10.
    - Must handle invalid JSON gracefully (reset to empty).
    - Must guard for `typeof window !== "undefined"`.
    - Wrap `localStorage.setItem` in try/catch (quota).

**Must NOT do**:
- Do not change restructure semantics.
- Do not add share-link creation in studio generate.

**Recommended Agent Profile**:
- Category: `visual-engineering`
- Skills: `frontend-ui-ux`

**Parallelization**: NO (Wave 2, depends on Tasks 1-2)

**References**:
- `apps/web/src/app/diagrams/[sessionId]/page.tsx:226` - current `handleRestructure` implementation.
- `apps/web/src/app/diagrams/[sessionId]/page.tsx:281` - synthetic assistant success message to remove.
- `apps/web/src/app/diagrams/[sessionId]/page.tsx:333` - current centered spinner to replace with skeleton.
- `packages/backend/convex/diagrams.ts:824` - `restructureFromScene` (no share link).
- `packages/backend/convex/diagrams.test.ts:237` - guarantees "no shareLink" pattern for scene-based actions.

**Acceptance Criteria (agent-executable)**:
- Blank-canvas prompt shows `Generating...` status row and results in non-empty canvas.
- Non-empty prompt shows `Updating...` status row.
- No synthetic assistant success bubble is appended after success.
- Skeleton exists during load (`session === undefined`) and is not a centered spinner.
- Session page updates localStorage recents on visit.

**Agent-Executed QA Scenarios**:
Scenario: Blank canvas prompt generates diagram
  Tool: Stagehand
  Preconditions: Dev server running; OPENROUTER_API_KEY configured
  Steps:
    1. Visit `/diagrams` and create new session.
    2. Confirm canvas is empty (non-deleted elements = 0).
    3. Fill `diagram-chat-input` with prompt like "Flowchart: Start -> End".
    4. Click `diagram-chat-send`.
    5. Wait for `diagram-status-row` to exist and contain `Generating...`.
    6. Wait for canvas elements > 0.
    7. Wait for `diagram-save-status` contains `Saved`.
    8. Screenshot: `tests/e2e/artifacts/diagram-studio-generating.png` (while status row visible).
  Expected Result: Canvas becomes non-empty and autosaves.

Scenario: Non-empty prompt uses update path
  Tool: Stagehand
  Steps:
    1. With non-empty canvas, send a second prompt.
    2. Wait for `diagram-status-row` contains `Updating...`.
    3. Wait for status row to clear and save status `Saved`.
  Expected Result: Update path runs (observable via status text).

---

### 4. Web: `/diagrams` landing polish + client-only recents list UI

**What to do**:
- Update `apps/web/src/app/diagrams/page.tsx`:
  - Improve layout so it feels intentional (hero copy + short bullets + CTA). Keep within existing visual language.
- Add "Recent diagrams" list sourced from localStorage.
 - Add "Recent diagrams" list sourced from localStorage key `sketchi.diagramRecents.v1`.
  - Each item provides:
    - Open (link to `/diagrams/:sessionId`)
    - Remove item
  - Provide "Clear all".
  - Show a warning that session URLs are capability tokens and grant edit access.
  - Display format (default): show truncated session id (`abcd1234...`) and a relative time based on `visitedAt`.
  - Add testids:
    - `diagram-recents-list`
    - `diagram-recents-item`
    - `diagram-recents-remove`
    - `diagram-recents-clear`

**Edge cases to handle**:
- localStorage missing / invalid JSON -> render empty state (no crash).
- Dedup on repeat visits; move to top.
- Quota errors -> ignore write failure.

**Recommended Agent Profile**:
- Category: `visual-engineering`
- Skills: `frontend-ui-ux`

**Parallelization**: YES (Wave 1)

**References**:
- `apps/web/src/app/diagrams/page.tsx` - current minimal landing.
- `tests/e2e/src/scenarios/unauthenticated/diagram-studio-happy-path.ts:87` - session creation uses `diagram-new-session` testid; keep stable.

**Acceptance Criteria (agent-executable)**:
- After visiting a session, returning to `/diagrams` shows a recents list with that session.
- UI includes explicit capability-token warning.
- Remove and clear affordances work.

**Agent-Executed QA Scenarios**:
Scenario: Recents list populates
  Tool: Stagehand
  Steps:
    1. Create a session.
    2. Navigate back to `/diagrams`.
    3. Assert `diagram-recents-list` exists and contains at least one `diagram-recents-item`.
    4. Screenshot: `tests/e2e/artifacts/diagram-studio-recents.png`.
  Expected Result: Recents list shows latest session.

---

### 5. E2E: expand `diagram-studio-happy-path` screenshots + blank-canvas prompt + recents assertions

**What to do**:
- Update `tests/e2e/src/scenarios/unauthenticated/diagram-studio-happy-path.ts` to add:
  - Screenshot: landing page before creating session (`diagram-studio-landing.png`).
  - Screenshot: empty canvas (`diagram-studio-empty-canvas.png`).
  - Blank-canvas prompt step:
    - Assert status row shows `Generating...`.
    - Capture in-flight screenshot (`diagram-studio-generating.png`).
    - Assert non-deleted element count > 0.
  - Assert AC1 + AC2 via DOM checks:
    - Header is not `Restructure`.
    - Placeholder is `Describe your diagram...` when empty.
    - Warning absent when empty; present when non-empty.
  - After session creation, navigate back to `/diagrams` and assert recents list includes session; capture `diagram-studio-recents.png`.
  - Import/export intermediate screenshots:
    - Capture screenshot when import input visible: `diagram-studio-import.png`.
    - Capture screenshot when export menu visible: `diagram-studio-export.png`.

**Flake mitigation**:
- Status-row screenshot timing is inherently racy; make it reliable:
  - Wait for `diagram-status-row` to exist before screenshot.
  - Choose a prompt likely to take >500ms.

**Recommended Agent Profile**:
- Category: `unspecified-high`
- Skills: `playwright`

**Parallelization**: YES (Wave 3)

**References**:
- `tests/e2e/src/scenarios/unauthenticated/diagram-studio-happy-path.ts` - existing scenario baseline.
- `tests/e2e/src/runner/stagehand.ts:160` - screenshot naming and output directory.
- `apps/web/src/components/diagram-studio/chat-sidebar.tsx` - testids and copy to assert.

**Acceptance Criteria (agent-executable)**:
- Running the scenario produces new PNG files in `tests/e2e/artifacts/`:
  - `diagram-studio-landing.png`
  - `diagram-studio-empty-canvas.png`
  - `diagram-studio-generating.png`
  - `diagram-studio-recents.png`
  - `diagram-studio-import.png`
  - `diagram-studio-export.png`

**QA Scenario**:
Scenario: Diagram Studio happy path includes all key screenshots
  Tool: Bash
  Steps:
    1. `cd tests/e2e && STAGEHAND_ENV=LOCAL bun run diagram-studio-happy-path`
    2. Verify screenshots exist under `tests/e2e/artifacts/`.
  Expected Result: Scenario passes; screenshots saved.

---

### 6. E2E: expand `diagram-studio-occ-conflict` screenshots

**What to do**:
- Update `tests/e2e/src/scenarios/unauthenticated/diagram-studio-occ-conflict.ts`:
  - Import and use `captureScreenshot` similarly to happy-path.
  - When conflict banner appears, capture `diagram-studio-conflict-banner.png`.
  - After clicking reload and banner disappears, capture `diagram-studio-conflict-resolved.png`.

**Recommended Agent Profile**:
- Category: `unspecified-high`
- Skills: `playwright`

**Parallelization**: YES (Wave 3)

**References**:
- `tests/e2e/src/scenarios/unauthenticated/diagram-studio-occ-conflict.ts` - existing conflict flow.
- `apps/web/src/app/diagrams/[sessionId]/page.tsx:399` - conflict banner `data-testid="diagram-conflict-banner"`.

**Acceptance Criteria (agent-executable)**:
- Scenario run creates:
  - `tests/e2e/artifacts/diagram-studio-conflict-banner.png`
  - `tests/e2e/artifacts/diagram-studio-conflict-resolved.png`

---

### 7. Full verification pass (local)

**What to do**:
- Run repo standard checks (do NOT rely solely on CI):
  - `bun x ultracite fix`
  - `bun x ultracite check`
  - `bun run check-types`
  - `bun run build`
  - `cd packages/backend && bunx convex codegen && bun run test`
- Run Stagehand scenarios (LOCAL or BROWSERBASE) depending on available env:
  - `cd tests/e2e && bun run diagram-studio-happy-path`
  - `cd tests/e2e && bun run diagram-studio-occ-conflict`
- Inspect screenshots using agent tooling (no human):
  - Use `look_at` on the key PNGs in `tests/e2e/artifacts/` and confirm they show the expected states.

**Recommended Agent Profile**:
- Category: `unspecified-high`
- Skills: `playwright`

**Parallelization**: NO (gate)

**References**:
- `AGENTS.md` - pre-push command sequence.
- `tests/e2e/src/runner/config.ts` - env vars required (OPENROUTER_API_KEY mandatory).

**Acceptance Criteria (agent-executable)**:
- All commands exit 0.
- The required PNGs exist under `tests/e2e/artifacts/`.

---

### 8. Git: commit(s), push, PR creation

**What to do**:
- Make small, readable commits (suggested grouping):
  1. `feat(backend): add studio generate-from-prompt action`
  2. `feat(web): polish diagram studio chat sidebar UX`
  3. `feat(web): route empty-canvas prompts to generate + add skeleton/progress`
  4. `feat(web): add client-only recent diagrams on /diagrams`
  5. `test(e2e): expand diagram studio screenshots (happy path + occ)`
- Push branch to origin.
- Create PR with a clear body including:
  - Link to issue #124
  - List of AC1-AC9 with where they are verified (Stagehand scenario names)
  - Evidence section listing PNG artifact filenames

**Must NOT do**:
- Do not mention Anthropic/Claude in commits/PR.
- Do not force push to main.

**Recommended Agent Profile**:
- Category: `quick`
- Skills: `git-master`

**Parallelization**: NO

**Acceptance Criteria (agent-executable)**:
- `git status` clean after commit.
- Remote branch exists: `git ls-remote --heads origin feature/issue-124-diagram-studio-v11` returns a ref.
- PR exists: `gh pr view --json url,state,title` returns URL and OPEN state.

---

### 9. CI + CodeRabbit iteration loop until 100% green

**What to do**:
- After PR creation, iterate until all checks are green:
  - Watch checks: `gh pr checks --watch`
  - If failing workflows:
    - Use `gh run view` and `gh run download` to inspect artifacts/logs.
    - Fix and push incremental commits (keep commits focused).
  - If CodeRabbit comments:
    - Address feedback with minimal changes (keep scope inside #124 guardrails).
    - Re-run local gates (Task 7) before pushing.
- Stop when:
  - All required checks are green
  - No unresolved CodeRabbit threads
  - PR is merge-ready

**Recommended Agent Profile**:
- Category: `unspecified-high`
- Skills: `git-master`

**Parallelization**: NO (loop)

**Acceptance Criteria (agent-executable)**:
- `gh pr checks` shows all checks PASS.
- `gh pr view --json reviewDecision` indicates no pending required decisions.

---

## Commit Strategy

| After Task | Message | Notes |
|------------|---------|-------|
| 1 | `feat(backend): add studio generate-from-prompt action` | Include backend Vitest tests in same commit |
| 2 | `feat(web): polish diagram studio sidebar UX` | Copy + warning + status row + autoscroll |
| 3 | `feat(web): route blank prompts to generate + add skeleton/progress` | Remove success bubble; add recents write |
| 4 | `feat(web): add client-only recent diagrams on /diagrams` | localStorage list + warning |
| 5-6 | `test(e2e): expand diagram studio screenshot coverage` | Add PNG names matching issue |

---

## Success Criteria

### Verification Commands

```bash
bun x ultracite fix
bun x ultracite check
bun run check-types
bun run build

cd packages/backend && bunx convex codegen && bun run test

cd tests/e2e && bun run diagram-studio-happy-path
cd tests/e2e && bun run diagram-studio-occ-conflict
```

### Final Checklist
- [ ] AC1-AC9 satisfied (issue #124)
- [ ] Screenshots exist in `tests/e2e/artifacts/` for all requested states
- [ ] No synthetic assistant success message added (success path)
- [ ] PR green; CodeRabbit threads resolved; Actions green
