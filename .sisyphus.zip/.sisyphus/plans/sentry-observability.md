# Fix Sentry Log Messages/Tags + Observability Tests

## TL;DR

> **Quick Summary**: The root cause of 477/502 empty-message Sentry Log entries is architectural: `captureMessage()` sends to the Issues/Events dataset, NOT the Logs dataset. The code has `enableLogs: true` but never calls `Sentry.logger.*`. Fix: add `Sentry.logger.*` calls to both backend and web observability modules, enable logs in web sentry configs, add vitest to web, write all 4 test scenarios, and document dashboard specs.
>
> **Deliverables**:
> - Backend `sendToSentry` updated to also call `logger.info/warn/error` for Logs dataset
> - Web sentry configs updated with `enableLogs: true`
> - Web `sendToSentry` updated to also call `logger.info/warn/error`
> - Vitest infrastructure in `apps/web`
> - 4 test scenarios (TS-OBS-1..4) covering message + tag + logger behavior
> - PR with all changes, lint/typecheck/build/tests green
>
> **Estimated Effort**: Medium
> **Parallel Execution**: YES - 2 waves
> **Critical Path**: Task 1 → Task 4 → Task 6 → Task 7 → Task 8
> **GitHub Issue**: https://github.com/anand-testcompare/sketchi/issues/92

---

## Context

### Original Request
Implement GitHub issue #92: Fix Sentry log messages/tags + finish Sketchi observability dashboards. Full implementation including tests, build, typecheck, commit/PR, handling CR feedback, and iterating until 100% done and confident.

### Root Cause Analysis

**The Problem**: 477 out of 502 Sentry Log dataset entries have missing/empty `message` fields (95%).

**Why**: The code uses TWO DIFFERENT Sentry systems that go to DIFFERENT datasets:

| API | Target Dataset | Current Usage | Has message? |
|-----|---------------|---------------|-------------|
| `captureMessage(msg)` | Issues/Events | YES — with `formatSentryMessage` | YES — but in WRONG dataset |
| `Sentry.logger.info(msg, attrs)` | **Logs** | **NEVER CALLED** | N/A — never used |
| `console.log(JSON.stringify(...))` | Stdout only | YES | N/A — not captured to Sentry |

**Evidence**:
- Backend `packages/backend/convex/lib/observability.ts:170-176`: `init({ enableLogs: true })` — enables the logger API, but nobody calls `logger.*`
- Backend `sendToSentry()` at line 202-229: calls `captureMessage()` only → Issues/Events dataset
- Web `apps/web/sentry.server.config.ts`: does NOT have `enableLogs: true` at all
- Web `apps/web/sentry.client.config.ts`: does NOT have `enableLogs: true`
- Web `apps/web/sentry.edge.config.ts`: does NOT have `enableLogs: true`
- Web `sendToSentry()` at `apps/web/src/lib/observability.ts:144-170`: calls `captureMessage()` only

**The 95% empty rate explained**: Entries in the Logs dataset are coming from Vercel platform log drains or other auto-instrumentation — NOT from the application code, which never writes to the Logs dataset. These drain entries have no structured `message` field.

### Research Findings (Sentry SDK 10.x)
- `enableLogs: true` alone does NOT auto-capture `console.log()`. Requires explicit `consoleLoggingIntegration`.
- `captureMessage()` populates Issues/Events dataset only — never appears in Logs.
- `Sentry.logger.info/warn/error(message, attributes)` populates the Logs dataset with structured messages and attributes.
- The `logger.*` API requires `enableLogs: true` in `Sentry.init()`.
- Logger attributes are searchable/filterable in the Sentry Logs UI — replace tags for this dataset.

### Metis Review
**Identified Gaps** (all addressed):
- Module-level env var evaluation → `vi.resetModules()` + dynamic import in tests
- Path alias resolution → `vite-tsconfig-paths` in web vitest
- Dashboard creation → documentation approach
- Backend `enableLogs: true` is set but unused → fix: call `logger.*`
- Web sentry configs miss `enableLogs` → fix: add to server + edge configs

---

## Work Objectives

### Core Objective
Fix the Sentry Logs dataset by adding `Sentry.logger.*` calls alongside existing `captureMessage`, enable logs in web sentry configs, and prove correctness via automated tests.

### Concrete Deliverables
- Modified `packages/backend/convex/lib/observability.ts` — add `logger.*` calls in `sendToSentry`
- Modified `apps/web/sentry.server.config.ts` — add `enableLogs: true`
- Modified `apps/web/sentry.edge.config.ts` — add `enableLogs: true`
- Modified `apps/web/src/lib/observability.ts` — add `logger.*` calls in `sendToSentry`
- New `apps/web/vitest.config.ts` — Vitest configuration
- Updated `apps/web/package.json` — `vitest` devDep + `"test"` script
- New `packages/backend/convex/lib/observability.test.ts` — TS-OBS-1 + TS-OBS-2
- New `apps/web/src/lib/observability.test.ts` — TS-OBS-3 + TS-OBS-4
- GitHub issue #92 comment with dashboard specs + smoke results

### Definition of Done
- [ ] `cd packages/backend && bun run test` → all tests pass (existing + new)
- [ ] `bun --cwd apps/web run test` → all tests pass
- [ ] `bun x ultracite check` → exit 0
- [ ] `bun run check-types` → exit 0
- [ ] `bun run build` → exit 0
- [ ] PR created, CI green, all CR feedback addressed
- [ ] Manual smoke documented in issue #92

### Must Have
- `Sentry.logger.*` calls in both backend and web `sendToSentry` functions
- `enableLogs: true` in web sentry server + edge configs
- All 4 test scenarios (TS-OBS-1..4) passing
- Vitest running in `apps/web`
- No regressions in existing backend tests
- Tags preserved on `captureMessage` (Issues/Events) AND attributes on `logger.*` (Logs)

### Must NOT Have (Guardrails)
- DO NOT remove existing `captureMessage` calls — keep them for Issues/Events/alerts
- DO NOT remove `console.log(JSON.stringify(...))` calls — keep for stdout/local dev
- DO NOT add `consoleLoggingIntegration` — use explicit `logger.*` calls instead for clean messages
- DO NOT add `enableLogs` to `sentry.client.config.ts` — client-side logs not needed
- DO NOT modify `formatSentryMessage` logic — keep existing message format
- DO NOT modify existing test files
- DO NOT upgrade Sentry SDK versions
- DO NOT add DOM testing libraries to web
- DO NOT modify CI workflow files

---

## Verification Strategy (MANDATORY)

> **UNIVERSAL RULE: ZERO HUMAN INTERVENTION**
> ALL tasks verifiable without human action. Exception: Sentry dashboard creation (manual in Sentry UI).

### Test Decision
- **Backend test infrastructure**: YES — Vitest + convex-test
- **Web test infrastructure**: NO → create it (Task 1)
- **Automated tests**: YES — Tests validating both `captureMessage` AND `logger.*`
- **Framework**: Vitest (both workspaces)

---

## Execution Strategy

### Parallel Execution Waves

```
Wave 1 (Start Immediately):
├── Task 1: Set up Vitest in apps/web [no dependencies]
├── Task 2: Fix backend observability — add logger.* calls [no dependencies]
└── Task 3: Fix web sentry configs + observability — add enableLogs + logger.* [no dependencies]

Wave 2 (After Wave 1):
├── Task 4: Write backend observability tests (TS-OBS-1 + TS-OBS-2) [depends: 2]
└── Task 5: Write web observability tests (TS-OBS-3 + TS-OBS-4) [depends: 1, 3]

Wave 3 (After Wave 2):
├── Task 6: Full verification — lint, typecheck, build, all tests [depends: 4, 5]
└── Task 7: Document dashboard specs + manual smoke [depends: 2, 3]

Wave 4 (After Wave 3):
└── Task 8: Commit + create PR [depends: 6, 7]

Wave 5 (After Wave 4):
└── Task 9: CR feedback loop until merge [depends: 8]

Critical Path: Task 2 → Task 4 → Task 6 → Task 8 → Task 9
```

### Dependency Matrix

| Task | Depends On | Blocks | Can Parallelize With |
|------|------------|--------|---------------------|
| 1 | None | 5 | 2, 3 |
| 2 | None | 4, 7 | 1, 3 |
| 3 | None | 5, 7 | 1, 2 |
| 4 | 2 | 6 | 5 |
| 5 | 1, 3 | 6 | 4 |
| 6 | 4, 5 | 8 | 7 |
| 7 | 2, 3 | 8 | 6 |
| 8 | 6, 7 | 9 | None |
| 9 | 8 | None | None (final) |

### Agent Dispatch Summary

| Wave | Tasks | Recommended Agents |
|------|-------|-------------------|
| 1 | 1, 2, 3 | `delegate_task(category="quick", ...)` each, parallel |
| 2 | 4, 5 | `delegate_task(category="quick", ...)` each, parallel |
| 3 | 6, 7 | `delegate_task(category="unspecified-low", ...)` each |
| 4 | 8 | `delegate_task(category="quick", load_skills=["git-master"], ...)` |
| 5 | 9 | `delegate_task(category="unspecified-high", load_skills=["git-master"], ...)` |

---

## TODOs

- [ ] 1. Set up Vitest in apps/web

  **What to do**:
  - Install `vitest` and `vite-tsconfig-paths` as devDependencies:
    ```bash
    bun add -d vitest vite-tsconfig-paths --cwd apps/web
    ```
  - Create `apps/web/vitest.config.ts`:
    ```typescript
    import tsconfigPaths from "vite-tsconfig-paths";
    import { defineConfig } from "vitest/config";

    export default defineConfig({
      plugins: [tsconfigPaths()],
      test: {
        environment: "node",
        include: ["src/**/*.test.ts"],
      },
    });
    ```
  - Add `"test"` script to `apps/web/package.json`:
    ```json
    "test": "vitest run"
    ```

  **Must NOT do**:
  - DO NOT add `jsdom`, `@testing-library/*`, or DOM-related test deps
  - DO NOT modify `tsconfig.json`
  - DO NOT add coverage config

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Single config file + package install
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 2, 3)
  - **Blocks**: Task 5
  - **Blocked By**: None

  **References**:
  - `packages/backend/vitest.config.ts` — Follow this vitest config pattern (node env, include glob)
  - `apps/web/tsconfig.json` — Has `@/*` path alias → `vite-tsconfig-paths` resolves it
  - `apps/web/package.json` — Target for devDep + script additions

  **Acceptance Criteria**:
  - [ ] `vitest` and `vite-tsconfig-paths` in `apps/web/package.json` devDeps
  - [ ] `apps/web/vitest.config.ts` exists with node env + tsconfigPaths plugin
  - [ ] `"test": "vitest run"` script in package.json
  - [ ] `bun --cwd apps/web run test` loads without config errors

  **Agent-Executed QA Scenarios:**
  ```
  Scenario: Vitest loads successfully
    Tool: Bash
    Steps:
      1. Run: bun --cwd apps/web run test 2>&1 || true
      2. Assert: Output does NOT contain "Cannot find module" or "Error loading config"
      3. Assert: Output contains "vitest"
    Expected Result: Vitest config loads
    Evidence: Terminal output
  ```

  **Commit**: YES (group with Tasks 2-5 in single commit)

---

- [ ] 2. Fix backend observability — add Sentry logger calls to sendToSentry

  **What to do**:
  - In `packages/backend/convex/lib/observability.ts`:
    1. Import `logger` from `@sentry/node`:
       ```typescript
       import {
         captureMessage,
         flush,
         init,
         logger,
         startSpan,
         withScope,
       } from "@sentry/node";
       ```
    2. In the `sendToSentry` function (lines 202-229), AFTER the existing `captureMessage` call, add a `logger.*` call based on level:
       ```typescript
       function sendToSentry(event: LogEvent, level: LogLevel): void {
         initSentry();
         if (!sentryInitialized) {
           return;
         }
         withScope((scope) => {
           scope.setLevel(level);
           scope.setTag("traceId", event.traceId);
           if (event.service) scope.setTag("service", event.service);
           if (event.component) scope.setTag("component", event.component);
           scope.setTag("op", event.op);
           if (event.stage) scope.setTag("stage", event.stage);
           if (event.actionName) scope.setTag("action", event.actionName);
           if (event.status) scope.setTag("status", event.status);
           scope.setContext("telemetry", event);
           captureMessage(formatSentryMessage(event));
         });

         // Also send to Sentry Logs dataset via structured logger API
         const loggerAttrs: Record<string, string | number | boolean> = {
           "trace.id": event.traceId,
         };
         if (event.service) loggerAttrs["service"] = event.service;
         if (event.component) loggerAttrs["component"] = event.component;
         loggerAttrs["op"] = event.op;
         if (event.stage) loggerAttrs["stage"] = event.stage;
         if (event.actionName) loggerAttrs["action"] = event.actionName;
         if (event.status) loggerAttrs["status"] = event.status;
         if (typeof event.durationMs === "number") loggerAttrs["duration_ms"] = Math.round(event.durationMs);
         if (event.modelId) loggerAttrs["model"] = event.modelId;
         if (event.tokens) loggerAttrs["tokens"] = event.tokens;
         if (event.iterations) loggerAttrs["iterations"] = event.iterations;
         if (event.errorName) loggerAttrs["error.name"] = event.errorName;
         if (event.errorMessage) loggerAttrs["error.message"] = event.errorMessage;

         const message = formatSentryMessage(event);
         if (level === "error") {
           logger.error(message, loggerAttrs);
         } else if (level === "warning") {
           logger.warn(message, loggerAttrs);
         } else {
           logger.info(message, loggerAttrs);
         }
       }
       ```
    3. **Keep everything else unchanged** — `captureMessage` stays for Issues/Events, `console.log` stays for stdout.

  **Must NOT do**:
  - DO NOT remove `captureMessage` — keep for Issues/Events alerts
  - DO NOT remove `console.log` — keep for stdout/local dev
  - DO NOT change `formatSentryMessage` logic
  - DO NOT change `enableLogs: true` (it's already correct)
  - DO NOT add `consoleLoggingIntegration`
  - DO NOT change sampling logic
  - DO NOT touch `logEvent`, `logEventSafely`, `buildLogEvent`, or other functions

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Small, focused change to one function in one file
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1, 3)
  - **Blocks**: Tasks 4, 7
  - **Blocked By**: None

  **References**:

  **Code to modify**:
  - `packages/backend/convex/lib/observability.ts:1-10` — Import list. Add `logger` to the destructured imports from `@sentry/node`.
  - `packages/backend/convex/lib/observability.ts:202-229` — `sendToSentry` function. Add `logger.*` call AFTER the existing `withScope`/`captureMessage` block.
  - `packages/backend/convex/lib/observability.ts:94-124` — `formatSentryMessage` function. Reuse its output as the `message` parameter to `logger.*`. Do NOT modify this function.
  - `packages/backend/convex/lib/observability.ts:170-176` — `initSentry` with `enableLogs: true`. Already correct — logger API enabled.

  **External docs**:
  - Sentry Node SDK `logger` API: `logger.info(message: string, attributes?: Record<string, string|number|boolean>)`. The `message` becomes the readable `body` in the Logs dataset. `attributes` become searchable/filterable fields.

  **WHY Each Reference Matters**:
  - Lines 1-10: Need to add `logger` to the import. Check exact import style.
  - Lines 202-229: This is THE function to modify. Must add logger call after captureMessage, not replace it.
  - Lines 94-124: Reuse `formatSentryMessage` output — same readable message for both datasets.
  - Lines 170-176: Confirms `enableLogs: true` is already set, so `logger.*` will work.

  **Acceptance Criteria**:
  - [ ] `logger` imported from `@sentry/node`
  - [ ] `sendToSentry` calls `logger.info/warn/error` with formatted message + attributes
  - [ ] Logger attributes include at minimum: `trace.id`, `op`, `service`, `component`, `stage`, `action`, `status`
  - [ ] `captureMessage` call is STILL PRESENT (not removed)
  - [ ] `console.log` call in `logEvent` is STILL PRESENT (not removed)
  - [ ] `cd packages/backend && bun run test` → existing tests still pass (no regressions)

  **Agent-Executed QA Scenarios:**
  ```
  Scenario: Existing backend tests still pass after code change
    Tool: Bash
    Preconditions: sendToSentry modified
    Steps:
      1. Run: cd packages/backend && bun run test 2>&1
      2. Assert: Exit code 0
      3. Assert: All existing test files pass (diagrams, excalidrawShareLinks, etc.)
    Expected Result: Zero regressions
    Evidence: Terminal output

  Scenario: TypeScript compiles without errors
    Tool: Bash
    Steps:
      1. Run: bun run check-types 2>&1
      2. Assert: No errors in observability.ts
    Expected Result: Clean typecheck
    Evidence: Terminal output
  ```

  **Commit**: YES (group with Tasks 1, 3-5 in single commit)

---

- [ ] 3. Fix web sentry configs + add logger calls to web sendToSentry

  **What to do**:

  **Part A — Enable logs in web sentry configs**:
  - `apps/web/sentry.server.config.ts` — Add `enableLogs: true`:
    ```typescript
    import { init } from "@sentry/nextjs";

    const dsn = process.env.NEXT_PUBLIC_SENTRY_DSN;

    init({
      dsn,
      enabled: Boolean(dsn),
      environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
      tracesSampleRate: 0.1,
      enableLogs: true,
    });
    ```
  - `apps/web/sentry.edge.config.ts` — Same change: add `enableLogs: true`.
  - `apps/web/sentry.client.config.ts` — DO NOT CHANGE. Client-side logs not needed.

  **Part B — Add logger calls to web observability**:
  - In `apps/web/src/lib/observability.ts`:
    1. Import `logger` from `@sentry/nextjs`:
       ```typescript
       import { captureMessage, logger, withScope } from "@sentry/nextjs";
       ```
    2. In `sendToSentry` (lines 144-170), AFTER the `captureMessage` call, add `logger.*`:
       ```typescript
       function sendToSentry(event: ApiLogEvent, level: LogLevel) {
         withScope((scope) => {
           scope.setLevel(level);
           scope.setTag("traceId", event.traceId);
           if (event.service) scope.setTag("service", event.service);
           if (event.component) scope.setTag("component", event.component);
           scope.setTag("op", event.op);
           if (event.orpcRoute) scope.setTag("orpc.route", event.orpcRoute);
           if (event.method) scope.setTag("http.method", event.method);
           if (typeof event.responseStatus === "number")
             scope.setTag("http.status_code", String(event.responseStatus));
           if (event.status) scope.setTag("status", event.status);
           scope.setContext("telemetry", event);
           captureMessage(formatSentryMessage(event));
         });

         // Also send to Sentry Logs dataset
         const loggerAttrs: Record<string, string | number | boolean> = {
           "trace.id": event.traceId,
         };
         if (event.service) loggerAttrs["service"] = event.service;
         if (event.component) loggerAttrs["component"] = event.component;
         loggerAttrs["op"] = event.op;
         if (event.orpcRoute) loggerAttrs["orpc.route"] = event.orpcRoute;
         if (event.method) loggerAttrs["http.method"] = event.method;
         if (typeof event.responseStatus === "number")
           loggerAttrs["http.status_code"] = event.responseStatus;
         if (event.status) loggerAttrs["status"] = event.status;
         if (typeof event.durationMs === "number") loggerAttrs["duration_ms"] = Math.round(event.durationMs);
         if (event.errorName) loggerAttrs["error.name"] = event.errorName;
         if (event.errorMessage) loggerAttrs["error.message"] = event.errorMessage;

         const message = formatSentryMessage(event);
         if (level === "error") {
           logger.error(message, loggerAttrs);
         } else if (level === "warning") {
           logger.warn(message, loggerAttrs);
         } else {
           logger.info(message, loggerAttrs);
         }
       }
       ```

  **Must NOT do**:
  - DO NOT modify `sentry.client.config.ts` — no `enableLogs` on client
  - DO NOT remove `captureMessage` — keep for Issues/Events
  - DO NOT modify `formatSentryMessage`
  - DO NOT change sampling logic
  - DO NOT add `consoleLoggingIntegration`

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Small changes across 3 files, well-defined
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1, 2)
  - **Blocks**: Tasks 5, 7
  - **Blocked By**: None

  **References**:

  **Code to modify**:
  - `apps/web/sentry.server.config.ts` — Full file (11 lines). Add `enableLogs: true` to init options.
  - `apps/web/sentry.edge.config.ts` — Full file (11 lines). Add `enableLogs: true` to init options.
  - `apps/web/src/lib/observability.ts:1` — Import line. Add `logger` to destructured imports from `@sentry/nextjs`.
  - `apps/web/src/lib/observability.ts:144-170` — `sendToSentry` function. Add logger call after captureMessage.

  **Code NOT to modify**:
  - `apps/web/sentry.client.config.ts` — Leave as-is. No `enableLogs` on client.
  - `apps/web/src/lib/observability.ts:43-75` — `formatSentryMessage`. Read but don't change.
  - `apps/web/src/lib/observability.ts:172-186` — `logApiEvent`. Don't change.

  **WHY Each Reference Matters**:
  - `sentry.server.config.ts`: Must add `enableLogs: true` for `logger.*` to work server-side
  - `sentry.edge.config.ts`: Same — edge runtime also needs it
  - `observability.ts:1`: Import `logger` alongside `captureMessage` and `withScope`
  - `observability.ts:144-170`: THE function to modify — add logger after captureMessage

  **Acceptance Criteria**:
  - [ ] `sentry.server.config.ts` has `enableLogs: true`
  - [ ] `sentry.edge.config.ts` has `enableLogs: true`
  - [ ] `sentry.client.config.ts` is UNCHANGED
  - [ ] `logger` imported from `@sentry/nextjs` in `observability.ts`
  - [ ] `sendToSentry` calls `logger.info/warn/error` with formatted message + attributes
  - [ ] Logger attributes include: `trace.id`, `op`, `service`, `component`, `orpc.route`, `http.method`, `http.status_code`, `status`
  - [ ] `captureMessage` still present
  - [ ] `bun run build` → exit 0 (web builds without errors)

  **Agent-Executed QA Scenarios:**
  ```
  Scenario: Web builds after sentry config changes
    Tool: Bash
    Steps:
      1. Run: bun run build 2>&1
      2. Assert: Exit code 0
      3. Assert: No errors related to @sentry/nextjs
    Expected Result: Clean build
    Evidence: Terminal output

  Scenario: TypeScript compiles web observability
    Tool: Bash
    Steps:
      1. Run: bun run check-types 2>&1
      2. Assert: No errors in apps/web/src/lib/observability.ts
    Expected Result: Clean typecheck
    Evidence: Terminal output
  ```

  **Commit**: YES (group with Tasks 1, 2, 4, 5)

---

- [ ] 4. Write backend observability tests (TS-OBS-1 + TS-OBS-2)

  **What to do**:
  - Create `packages/backend/convex/lib/observability.test.ts`
  - Add scenario comment at top
  - **CRITICAL**: Mock BOTH `captureMessage` AND `logger` from `@sentry/node`:
    ```typescript
    const mockLoggerInfo = vi.fn();
    const mockLoggerWarn = vi.fn();
    const mockLoggerError = vi.fn();

    vi.mock("@sentry/node", () => ({
      captureMessage: vi.fn(),
      withScope: vi.fn((cb) => {
        const scope = {
          setLevel: vi.fn(),
          setTag: vi.fn(),
          setContext: vi.fn(),
        };
        cb(scope);
        return scope;
      }),
      logger: {
        info: mockLoggerInfo,
        warn: mockLoggerWarn,
        error: mockLoggerError,
      },
      init: vi.fn(),
      flush: vi.fn(),
      startSpan: vi.fn(),
    }));
    ```
  - **CRITICAL**: Set env vars BEFORE module loads:
    ```typescript
    beforeEach(() => {
      vi.stubEnv("SENTRY_CONVEX_ENABLED", "1");
      vi.stubEnv("SENTRY_DSN", "https://example.invalid/123");
      vi.stubEnv("SENTRY_LOG_SAMPLE_RATE", "1");
      vi.resetModules();
    });
    ```
    Use `const { logEvent } = await import("./observability");` inside each test.

  - **TS-OBS-1**: Convex formatted message is non-empty
    - Call `await logEvent({ traceId: "trace-test-1", op: "action.complete", stage: "convex.action", status: "success", durationMs: 123 })`
    - Assert: `captureMessage` called with string containing `convex` AND `action.complete`, non-empty
    - Assert: `logger.info` called with the SAME non-empty string as first arg
    - Assert: `logger.info` second arg has `"trace.id": "trace-test-1"` and `"op": "action.complete"`

  - **TS-OBS-2**: Convex tags are attached
    - Call `await logEvent({ traceId: "trace-test-2", op: "action.complete", stage: "convex.action", status: "success", actionName: "diagrams:modifyDiagram" })`
    - Assert: `scope.setTag` called with: `("traceId", ...)`, `("op", ...)`, `("stage", ...)`, `("status", ...)`, `("action", ...)`
    - Assert: `logger.info` attributes include: `stage`, `action`, `status`

  **Must NOT do**:
  - DO NOT use `convex-test` — pure unit test with `vi.mock`
  - DO NOT import from `test.setup.ts`
  - DO NOT modify `observability.ts`

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Single test file, 2 focused test cases
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Task 5)
  - **Blocks**: Task 6
  - **Blocked By**: Task 2

  **References**:
  - `packages/backend/convex/diagrams.test.ts:1-21` — Test file convention: scenario comment, describe/test blocks, vi.mock
  - `packages/backend/convex/lib/observability.ts:94-124` — `formatSentryMessage` produces `"convex [component?] [op] stage=... action=... status=... durMs=... model=..."`
  - `packages/backend/convex/lib/observability.ts:202-229+` — `sendToSentry` after modification (Task 2): calls both `captureMessage` and `logger.*`
  - `packages/backend/convex/lib/observability.ts:61-71` — Module-level env vars: MUST use `vi.resetModules()` + dynamic import

  **Acceptance Criteria**:
  - [ ] File exists: `packages/backend/convex/lib/observability.test.ts`
  - [ ] TS-OBS-1: `captureMessage` AND `logger.info` both called with non-empty string containing "convex" + "action.complete"
  - [ ] TS-OBS-1: logger attributes include `trace.id`, `op`
  - [ ] TS-OBS-2: `scope.setTag` called with all required tags
  - [ ] TS-OBS-2: logger attributes include `stage`, `action`, `status`
  - [ ] `cd packages/backend && bun run test` → PASS (new + existing tests)

  **Agent-Executed QA Scenarios:**
  ```
  Scenario: Backend observability tests pass
    Tool: Bash
    Steps:
      1. Run: cd packages/backend && bun run test 2>&1
      2. Assert: Exit code 0
      3. Assert: Output shows observability test suite passing
      4. Assert: All existing tests still pass
    Expected Result: All tests green
    Evidence: Terminal output in .sisyphus/evidence/task-4-backend-tests.txt
  ```

  **Commit**: YES (group with Tasks 1-3, 5)

---

- [ ] 5. Write web observability tests (TS-OBS-3 + TS-OBS-4)

  **What to do**:
  - Create `apps/web/src/lib/observability.test.ts`
  - Mock BOTH `captureMessage` AND `logger` from `@sentry/nextjs`:
    ```typescript
    const mockLoggerInfo = vi.fn();
    const mockLoggerWarn = vi.fn();
    const mockLoggerError = vi.fn();

    vi.mock("@sentry/nextjs", () => ({
      captureMessage: vi.fn(),
      withScope: vi.fn((cb) => {
        const scope = { setLevel: vi.fn(), setTag: vi.fn(), setContext: vi.fn() };
        cb(scope);
        return scope;
      }),
      logger: { info: mockLoggerInfo, warn: mockLoggerWarn, error: mockLoggerError },
    }));

    vi.mock("@sketchi/shared", () => ({
      createTraceId: vi.fn(() => "mock-trace-id"),
    }));

    beforeEach(() => {
      vi.stubEnv("SENTRY_LOG_SAMPLE_RATE", "1");
      vi.resetModules();
    });
    ```

  - **TS-OBS-3**: Web formatted message is non-empty
    - Call `logApiEvent({ traceId: "trace-test-3", op: "request.complete", method: "POST", path: "/api/diagrams/modify", orpcRoute: "diagrams.modify", responseStatus: 200, durationMs: 50 })`
    - Assert: `captureMessage` called with string containing `web` AND `request.complete`, non-empty
    - Assert: `logger.info` called with same non-empty string
    - Assert: logger attributes include `trace.id`, `op`, `orpc.route`, `http.method`, `http.status_code`

  - **TS-OBS-4**: Web tags are attached
    - Same call as TS-OBS-3
    - Assert: `scope.setTag` called with: `("traceId", ...)`, `("op", ...)`, `("orpc.route", ...)`, `("http.method", ...)`, `("http.status_code", ...)`
    - Assert: logger attributes match tag values

  - **Note**: `logApiEvent` is synchronous. Do NOT `await` it.

  **Must NOT do**:
  - DO NOT modify `observability.ts`
  - DO NOT add DOM testing libraries
  - DO NOT add extra test scenarios

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: Single test file, mirrors Task 4
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Task 4)
  - **Blocks**: Task 6
  - **Blocked By**: Tasks 1, 3

  **References**:
  - `apps/web/src/lib/observability.ts:43-75` — `formatSentryMessage` for web
  - `apps/web/src/lib/observability.ts:144-170+` — `sendToSentry` after modification (Task 3)
  - `apps/web/src/lib/observability.ts:6-25` — `ApiLogEvent` interface
  - `apps/web/src/lib/observability.ts:29-30` — Module-level `SAMPLE_RATE`

  **Acceptance Criteria**:
  - [ ] File exists: `apps/web/src/lib/observability.test.ts`
  - [ ] TS-OBS-3: `captureMessage` AND `logger.info` both called with non-empty string
  - [ ] TS-OBS-3: logger attributes include web-specific fields
  - [ ] TS-OBS-4: `scope.setTag` called with all required tags
  - [ ] `bun --cwd apps/web run test` → PASS

  **Agent-Executed QA Scenarios:**
  ```
  Scenario: Web observability tests pass
    Tool: Bash
    Steps:
      1. Run: bun --cwd apps/web run test 2>&1
      2. Assert: Exit code 0
      3. Assert: Output shows TS-OBS-3 and TS-OBS-4 passing
    Expected Result: All web tests green
    Evidence: Terminal output in .sisyphus/evidence/task-5-web-tests.txt
  ```

  **Commit**: YES (group with Tasks 1-4)

---

- [ ] 6. Full verification — lint, typecheck, build, all tests

  **What to do**:
  - Run in sequence, fix any failures:
    1. `bun x ultracite fix` → then `bun x ultracite check` → exit 0
    2. `bun run check-types` → exit 0
    3. `bun run build` → exit 0
    4. `cd packages/backend && bun run test` → exit 0
    5. `bun --cwd apps/web run test` → exit 0
  - Fix lint errors with `ultracite fix`. Fix type/build errors in modified files.

  **Must NOT do**:
  - DO NOT skip any step
  - DO NOT add `--no-verify`

  **Recommended Agent Profile**:
  - **Category**: `unspecified-low`
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: NO — sequential
  - **Blocks**: Task 8
  - **Blocked By**: Tasks 4, 5

  **Acceptance Criteria**:
  - [ ] All 5 commands exit 0
  - [ ] Zero regressions in existing tests

  **Agent-Executed QA Scenarios:**
  ```
  Scenario: Full verification suite passes
    Tool: Bash
    Steps:
      1. bun x ultracite check → exit 0
      2. bun run check-types → exit 0
      3. bun run build → exit 0
      4. cd packages/backend && bun run test → exit 0
      5. bun --cwd apps/web run test → exit 0
    Expected Result: All green
    Evidence: .sisyphus/evidence/task-6-verification.txt
  ```

  **Commit**: NO (verification only)

---

- [ ] 7. Document dashboard specs + manual smoke test

  **What to do**:
  - Run smoke test:
    ```bash
    curl -sS -X POST http://localhost:3001/api/telemetry \
      -H 'content-type: application/json' \
      -d '{"op":"manual.smoke","level":"info","traceId":"00000000000000000000000000000000"}'
    ```
  - Document dashboard specs + smoke results as comment on issue #92 via `gh issue comment`.
  - Dashboard specs:
    1. **SKETCHI Observability**: errors by service, errors by function, GenAI counts + p95
    2. **SKETCHI Logs**: volume, warn/error count, missing-message ratio, severity breakdown, top messages
    3. **SKETCHI Diagram Pipeline** (optional): failure count, GenAI p95 trend

  **Must NOT do**:
  - DO NOT create dashboards via API
  - DO NOT modify source code

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: `[]`

  **Parallelization**:
  - **Can Run In Parallel**: YES (with Task 6)
  - **Blocks**: Task 8
  - **Blocked By**: Tasks 2, 3

  **Acceptance Criteria**:
  - [ ] Smoke curl returns `{"status":"ok","traceId":"..."}`
  - [ ] Issue #92 has dashboard specs + smoke results comment

  **Commit**: NO

---

- [ ] 8. Create branch, commit, push, open PR

  **What to do**:
  - Branch: `feature/sentry-observability-logs`
  - Stage all modified/new files:
    - `packages/backend/convex/lib/observability.ts` (modified — added logger calls)
    - `packages/backend/convex/lib/observability.test.ts` (new)
    - `apps/web/sentry.server.config.ts` (modified — enableLogs)
    - `apps/web/sentry.edge.config.ts` (modified — enableLogs)
    - `apps/web/src/lib/observability.ts` (modified — added logger calls)
    - `apps/web/src/lib/observability.test.ts` (new)
    - `apps/web/vitest.config.ts` (new)
    - `apps/web/package.json` (modified — vitest deps + script)
    - `bun.lock` (modified)
  - Commit: `feat(observability): send structured logs to Sentry Logs dataset + add tests`
  - Push with `-u`, create PR via `gh pr create`
  - PR body: link to #92, explain the root cause (captureMessage vs logger), list changes
  - Include `Closes #92` in body

  **Must NOT do**:
  - DO NOT mention anthropic/claude
  - DO NOT add emojis
  - DO NOT force push

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: `["git-master"]`

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocks**: Task 9
  - **Blocked By**: Tasks 6, 7

  **Acceptance Criteria**:
  - [ ] Branch has `feature/` prefix
  - [ ] PR open, links to #92
  - [ ] CI running

  **Commit**: YES (this IS the commit)
  - Message: `feat(observability): send structured logs to Sentry Logs dataset + add tests`
  - Pre-commit: `bun x ultracite check && bun run check-types`

---

- [ ] 9. Handle CR feedback loop until merge

  **What to do**:
  - Monitor PR for review comments via `gh`
  - For each comment: fix → verify (lint/type/build/test) → commit → push
  - If reviewer questions the `logger.*` approach, consult Oracle for architectural confidence
  - Repeat until approved + CI green

  **Must NOT do**:
  - DO NOT force push
  - DO NOT merge without explicit approval

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: `["git-master"]`

  **Parallelization**:
  - **Can Run In Parallel**: NO — terminal task
  - **Blocked By**: Task 8

  **Acceptance Criteria**:
  - [ ] All review comments addressed
  - [ ] CI green
  - [ ] PR approved or ready for merge

---

## Commit Strategy

| After Tasks | Message | Key Files |
|-------------|---------|-----------|
| 1-5 (combined) | `feat(observability): send structured logs to Sentry Logs dataset + add tests` | observability.ts (both), sentry configs, vitest setup, test files |
| 9 (per fix) | `fix(observability): address CR — [description]` | varies |

---

## Success Criteria

### Verification Commands
```bash
bun x ultracite check            # exit 0
bun run check-types               # exit 0
bun run build                     # exit 0
cd packages/backend && bun run test  # exit 0, all pass
bun --cwd apps/web run test       # exit 0, all pass

# Smoke
curl -sS -X POST http://localhost:3001/api/telemetry \
  -H 'content-type: application/json' \
  -d '{"op":"manual.smoke","level":"info","traceId":"00000000000000000000000000000000"}'
# Expected: {"status":"ok","traceId":"..."}
```

### Final Checklist
- [ ] `Sentry.logger.*` calls present in both backend and web sendToSentry
- [ ] `enableLogs: true` in web server + edge sentry configs
- [ ] All 4 test scenarios passing (TS-OBS-1..4) covering captureMessage + logger
- [ ] Vitest running in apps/web
- [ ] No regressions in existing backend tests
- [ ] Lint/typecheck/build green
- [ ] PR created, CI green
- [ ] Smoke + dashboard specs documented in issue #92
- [ ] All CR feedback addressed
