# Draft: Switch Excalidraw Export to Line Elements

## Problem Statement
Excalidraw freedraw elements look "rougher" than preview because perfect-freehand library applies heavy post-processing (smoothing, streamline, thinning).

## Root Cause
- `freedraw` elements → perfect-freehand processing (0.5 smoothing, 0.5 streamline, 0.6 thinning)
- `roughness: 0` only affects fill, not stroke on freedraw
- `simulatePressure: true` causes variable width

## Solution
Switch to `line` element type which:
- Uses RoughJS `linearPath()` instead of perfect-freehand
- `roughness: 0` actually disables roughness on stroke
- No variable width/pressure simulation
- More faithful point rendering

## Research Findings
- Line elements require: `startBinding`, `endBinding`, `startArrowhead`, `endArrowhead`
- Need to add `ExcalidrawLineElement` interface
- Can use `roundness` property for smooth curves if needed

## Files to Change
- `apps/web/src/lib/icon-library/svg-to-excalidraw.ts`

## Open Questions
- None - approach is clear
