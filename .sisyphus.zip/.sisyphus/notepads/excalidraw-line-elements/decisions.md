# Decisions

Architectural choices and rationale.

