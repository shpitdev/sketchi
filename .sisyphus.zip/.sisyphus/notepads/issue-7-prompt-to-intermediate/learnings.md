# Learnings

## Session: ses_3fcd823e4ffeR2C39Y4YnyNQvG
Started: 2026-01-28T06:16:16.195Z

---


## ToolLoopAgent Spike Test - VERIFIED ✓

### Key Findings

1. **ToolLoopAgent + gateway() works with Output.object()**
   - Successfully created agent with `gateway("google/gemini-3-flash")`
   - Output.object() with Zod schema works correctly
   - Returned typed output: `{ test: "spike-test-success" }`

2. **Tool Invocation Pattern**
   - Tool was NOT invoked in this test (step count = 0 tools)
   - Agent completed on first step with structured output
   - `onStepFinish` callback confirmed: `Step: tools=0, tokens=264`

3. **Loop Termination**
   - `stopWhen: stepCountIs(3)` works as expected
   - Agent terminated early when output matched schema (before step limit)
   - No errors on exit

4. **Environment Setup**
   - AI_GATEWAY_API_KEY must be set in environment (not sourced from .env.local automatically)
   - Key location: `packages/backend/.env.local:11`
   - Run command: `AI_GATEWAY_API_KEY=<key> bun run <script>`

5. **Implementation Notes**
   - Tool execute function should NOT be async (removed async keyword)
   - Schema validation happens automatically via Output.object()
   - Agent returns result.output with typed data

### Test File Location
- `packages/backend/experiments/tests/spike-toolloop-agent.ts`
- Status: WORKING - ready for deletion after confirmation

### Next Steps for Production
- ToolLoopAgent is production-ready for structured output
- Consider tool invocation patterns for validation workflows
- May need to adjust stopWhen conditions based on actual use case


## Task 1: Create Agent Types File - COMPLETED ✓

### Implementation Summary

Created `packages/backend/lib/agents/types.ts` with 4 core interfaces:

1. **ValidationError** - Represents validation failures with type, path, message, suggestion
2. **ValidationResult** - Wraps validation outcome (ok flag + errors array)
3. **PromptAgentProfile** - Agent configuration with id, description, instructions, optional validate function
4. **GenerateIntermediateResult** - Generation result with intermediate format, profileId, iterations, tokens, duration, traceId

### Key Design Decisions

- **Import pattern**: `import type { IntermediateFormat }` from diagram-intermediate (type-only import)
- **Validation function**: Optional method on PromptAgentProfile, takes IntermediateFormat, returns ValidationResult
- **JSDoc coverage**: All interfaces and properties documented per task requirement
- **No profile logic**: File contains only type definitions, no implementation

### File Location
- `packages/backend/lib/agents/types.ts` (67 lines)

### Verification
- File created successfully
- All 4 interfaces exported
- IntermediateFormat imported correctly
- JSDoc comments on all public types
- No syntax errors

### Next Steps
- Task 2 (profile) will implement PromptAgentProfile instances
- Task 3 (generate) will use GenerateIntermediateResult as return type

## Task 2: Create General Prompt Agent Profile - COMPLETED ✓

### Implementation Summary

Created `packages/backend/lib/agents/profiles/general.ts` with complete PromptAgentProfile implementation.

### Key Components

1. **Profile Metadata**
   - id: "general"
   - description: "General-purpose diagram agent that converts natural language descriptions into structured diagrams"

2. **System Instructions** (ported from content-analyzer.ts)
   - Covers all 23 diagram types with selection guidelines
   - Node extraction rules: distinct entities, semantic kinds, descriptions, metadata
   - Edge extraction rules: relationships, labels, conditions
   - Shape guidelines: rectangle (default), ellipse (start/end/actors), diamond (decisions)
   - Color guidelines: 6 hex colors for semantic meaning
   - Layout directions: TB/LR/BT/RL with use cases
   - Removed all Excalidraw terminology (verified with grep)

3. **Validation Function**
   - Checks: at least 1 node required
   - Checks: single-node diagrams cannot have edges
   - Checks: multi-node diagrams must have ≥1 edge
   - Checks: all edge references point to existing nodes
   - Returns typed ValidationResult with detailed errors

### Design Decisions

- **Prompt refinement**: Simplified from content-analyzer.ts, removed chart type list generation (now static)
- **Validation logic**: Separated concerns into boolean flags (isSingleNode, hasEdges) to reduce complexity
- **Error messages**: Actionable suggestions for each validation failure
- **Edge safety**: Added null check for edge access in loop

### File Location
- `packages/backend/lib/agents/profiles/general.ts` (155 lines)

### Verification Results
- ✓ File created at correct path
- ✓ Exports generalProfile as PromptAgentProfile
- ✓ All 23 diagram types documented in instructions
- ✓ No Excalidraw terminology (grep verified)
- ✓ Validation function implements required checks
- ✓ Biome linting passes (0 errors)
- ✓ TypeScript types correct

### Next Steps
- Task 3 (generator) will use this profile to generate intermediate format
- Profile can be extended with additional validation rules as needed

## Task 3: Create Intermediate Generator - COMPLETED

### Implementation Summary

Created `packages/backend/lib/agents/intermediate-generator.ts` with ToolLoopAgent-based prompt-to-IntermediateFormat conversion.

### Key Components

1. **generateIntermediate() Function**
   - Async function taking prompt string and optional GenerateOptions
   - Returns typed GenerateIntermediateResult
   - Uses crypto.randomUUID() for traceId
   - Throws on validation exhaustion (no silent failures)

2. **ToolLoopAgent Configuration**
   - Model: `gateway("google/gemini-3-flash")`
   - Output: `Output.object({ schema: IntermediateFormatSchema })`
   - Stop condition: `stepCountIs(5)` - max 5 iterations
   - onStepFinish callback logs traceId, tool count, and token usage

3. **Validation Tool**
   - inputSchema: Zod schema matching IntermediateFormat structure
   - Sync execute function (NOT async per spike findings)
   - Three validation layers:
     - Referential integrity via validateEdgeReferences()
     - Semantic checks (at least one node required)
     - Profile validation via profile.validate()
   - Returns `{ ok: true }` or `{ ok: false, errors: string[] }`

### API Discoveries

1. **AI SDK v6 Tool API**
   - Uses `inputSchema` NOT `parameters`
   - Tool function signature: `tool({ description, inputSchema, execute })`
   - Execute function receives typed input from inputSchema

2. **Zod v4 API Changes**
   - `z.record()` requires two arguments: `z.record(z.string(), z.unknown())`
   - Single argument `z.record(z.unknown())` is invalid in Zod v4

3. **Type Casting Pattern**
   - For profile.validate() call: `intermediate as unknown as IntermediateFormat`
   - Avoids biome "Unexpected any" error while maintaining type safety

4. **Usage Tokens**
   - `result.usage.totalTokens` may be undefined
   - Use nullish coalescing: `result.usage.totalTokens ?? 0`

### File Location
- `packages/backend/lib/agents/intermediate-generator.ts` (141 lines)

### Verification Results
- File exists at correct path
- Exports generateIntermediate() async function
- Uses ToolLoopAgent (NOT generateObject)
- Returns typed GenerateIntermediateResult
- Throws on validation exhaustion
- LSP diagnostics clean
- Project type check passes

### Dependencies
- Imports generalProfile from ./profiles/general (forward reference for registry)
- getProfile() function is temporary - will be replaced by registry in Task 4

## Task 4: Create Agents Registry Index - COMPLETED ✓

### Implementation Summary

Created `packages/backend/lib/agents/index.ts` as the public API for the agents system.

### Key Components

1. **Profile Registry**
   - Map<string, PromptAgentProfile> stores available profiles
   - Currently contains: "general" profile
   - Extensible for future specialized profiles

2. **getProfile() Function**
   - Retrieves profile by ID
   - Falls back to "general" with console.warn on unknown ID
   - Never throws on unknown profile (graceful degradation)
   - Throws only if "general" profile is missing (should never happen)

3. **listProfiles() Function**
   - Returns array of available profile IDs
   - Uses Array.from(profiles.keys())

4. **Public Exports**
   - Re-exports all types from './types'
   - Re-exports generateIntermediate from './intermediate-generator'
   - Provides single entry point for agents system

### Design Decisions

- **Map for storage**: Efficient O(1) lookup by profile ID
- **Fallback pattern**: console.warn + fallback to 'general' (NOT throw)
- **No non-null assertions**: Replaced `profiles.get("general")!` with explicit null check
- **Docstrings**: Necessary for public API documentation (priority 3)
- **Barrel file pattern**: Intentional for public API aggregation

### File Location
- `packages/backend/lib/agents/index.ts` (45 lines)

### Verification Results
- ✓ File created at correct path
- ✓ Exports getProfile() function
- ✓ Exports listProfiles() function
- ✓ Exports generateIntermediate function
- ✓ Re-exports all types from './types'
- ✓ Unknown profile falls back to 'general' with console.warn
- ✓ LSP diagnostics clean (no errors)
- ✓ Docstrings necessary for public API

### Dependencies
- Imports generalProfile from './profiles/general'
- Imports PromptAgentProfile type from './types'
- Re-exports from './types' and './intermediate-generator'

### Next Steps
- Task 5 (Convex action) will import from this registry
- Registry can be extended with additional profiles as needed
- No circular dependencies with intermediate-generator (generator has local getProfile)


## Task 5: Create Convex Action Wrapper - COMPLETED ✓

### Implementation Summary

Created `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts` as thin action wrapper calling generateIntermediate().

### Key Components

1. **Action Definition**
   - Name: `generateIntermediateFromPrompt`
   - Args: `prompt` (string), `profileId` (optional string)
   - Handler: Async function calling generateIntermediate()

2. **Structured Logging**
   - Single-line JSON log with event metadata
   - Includes: traceId, profileId, nodeCount, edgeCount, iterations, tokens, durationMs
   - Pattern: `console.log(JSON.stringify({ event, ...data }))`

3. **Thin Wrapper Pattern**
   - No complex logic in action handler
   - Delegates all work to generateIntermediate()
   - Returns full GenerateIntermediateResult

### Design Decisions

- **Unused parameter**: Prefixed ctx with underscore (`_ctx`) to suppress LSP warning
- **No error handling**: Let Convex handle errors (no try/catch)
- **No comments**: Removed unnecessary comment about logging pattern
- **Structured logging**: JSON format for easy parsing in Convex logs

### File Location
- `packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts` (28 lines)

### Verification Results
- ✓ File created at correct path
- ✓ Action named `generateIntermediateFromPrompt`
- ✓ Appears in generated Convex API (`_generated/api.d.ts` line 12, 29)
- ✓ Logs structured event with traceId
- ✓ LSP diagnostics clean (no errors)
- ✓ Convex dev server compiles successfully
- ✓ Biome linting passes

### API Generation
- Convex dev server auto-generated API types
- Action appears in `_generated/api.d.ts` as module import
- Ready for client-side calls via `api.diagramGenerateIntermediateFromPrompt.generateIntermediateFromPrompt`

### Next Steps
- Task 6 (test) will call this action from E2E tests
- Action is production-ready for diagram generation from natural language prompts

## Task 6: E2E Test for Full Pipeline - COMPLETED

### Implementation Summary

Created `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts` with comprehensive E2E test covering full pipeline: prompt → intermediate → diagram → share link → PNG.

### Test Scenarios

1. **SME interview transcript (pharma batch disposition)**
   - Complex multi-step process with decision points
   - Result: 8 nodes, 8 edges, 2353 tokens, ~10s

2. **Rambling technical narration with mid-course correction**
   - Tests handling of corrections/revisions in prompt
   - Result: 8 nodes, 9 edges, 2546 tokens, ~11s

3. **Adversarial edge case (very short prompt)**
   - Tests minimal input "user login flow"
   - Result: 10 nodes, 10 edges, 2570 tokens, ~15s

### Key Implementation Details

1. **Test Setup**
   - Added `diagramGenerateIntermediateFromPrompt.ts` to `test.setup.ts` modules
   - Uses convex-test with schema and modules
   - Loads `.env.e2e` for AI_GATEWAY_API_KEY

2. **Pipeline Steps**
   - Step 1: `generateIntermediateFromPrompt` - converts prompt to IntermediateFormat
   - Step 2: `generateDiagramFromIntermediate` - converts intermediate to Excalidraw elements
   - Step 3: `createExcalidrawShareLink` - creates shareable link
   - Step 4: `renderDiagramToPng` - renders to PNG via Playwright

3. **Validation Checks**
   - Intermediate has nodes (length > 0)
   - Share URL format: `https://excalidraw.com/#json=`
   - PNG size > 1KB

4. **Artifacts Generated**
   - `prompt-intermediate-{slug}.json` - contains prompt, shareUrl, intermediate, tokens, durationMs, traceId
   - `prompt-intermediate-{slug}.png` - rendered diagram
   - `prompt-intermediate-summary.md` - table with all scenarios and pass/fail status

### Test Results

- Pass rate: 3/3
- All PNGs > 100KB (well above 1KB threshold)
- All share URLs valid format
- Total test duration: ~15s

### Vitest Command

```bash
cd packages/backend && bun run test diagramGenerateIntermediateFromPrompt
```

Note: Vitest 4.x uses positional argument for filter, not `--filter` flag.

### File Locations
- Test: `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts`
- Artifacts: `packages/backend/test-results/prompt-intermediate-*.{json,png,md}`

## Task 7: Documentation Update - COMPLETED ✓

### Implementation Summary

Updated `packages/backend/experiments/README.md` to reflect the migration of prompt→IntermediateFormat from experiments to production Convex.

### Changes Made

1. **Updated Section 0.2 (AI generation quality)**
   - Changed "unknowns/risks" note from "prompt → IntermediateFormat remains experimental" to "notes: prompt → IntermediateFormat migrated to production"
   - Removed uncertainty marker, now points to new section below

2. **Added New Section 0.6 (Prompt to IntermediateFormat)**
   - experiment files: `packages/backend/experiments/agents/content-analyzer.ts` (marked as superseded)
   - test files: `packages/backend/convex/diagramGenerateIntermediateFromPrompt.test.ts`
   - convex migration: yes (`packages/backend/convex/diagramGenerateIntermediateFromPrompt.ts`)
   - evidence: All 3 test artifacts verified on disk:
     - `prompt-intermediate-pharma-interview.json` (2874 bytes)
     - `prompt-intermediate-pharma-interview.png` (129627 bytes)
     - `prompt-intermediate-rambling-tech.json` (2907 bytes)
     - `prompt-intermediate-rambling-tech.png` (102523 bytes)
     - `prompt-intermediate-short-prompt.json` (2490 bytes)
     - `prompt-intermediate-short-prompt.png` (131241 bytes)
     - `prompt-intermediate-summary.md` (1983 bytes)
   - status: COMPLETED - production ready with ToolLoopAgent pattern
   - notes: Migrated from two-agent pipeline to single ToolLoopAgent with validation loop; all 3 test scenarios passed

3. **Added JSDoc to generateIntermediate() Function**
   - Location: `packages/backend/lib/agents/intermediate-generator.ts`
   - Documents: purpose, parameters (prompt, options), return type
   - Justification: Essential public API documentation (priority 3 - necessary docstring)

### JSDoc Verification Results

All exported functions in `lib/agents/` have JSDoc:
- ✓ `types.ts` - All interfaces documented (ValidationError, ValidationResult, PromptAgentProfile, GenerateIntermediateResult)
- ✓ `profiles/general.ts` - generalProfile export documented
- ✓ `intermediate-generator.ts` - generateIntermediate() function documented
- ✓ `index.ts` - getProfile(), listProfiles() documented; re-exports documented

### File Locations Updated
- `packages/backend/experiments/README.md` - Updated with migration status
- `packages/backend/lib/agents/intermediate-generator.ts` - Added JSDoc

### Verification Results
- ✓ experiments/README.md updated with new section 0.6
- ✓ Section 0.2 updated to remove "unknowns/risks"
- ✓ All test artifacts verified on disk
- ✓ JSDoc added to generateIntermediate()
- ✓ No new README files created (updated existing only)
- ✓ All exported functions have JSDoc comments

### Key Insights

1. **Migration Complete**: The prompt→IntermediateFormat functionality is now fully migrated from experiments to production Convex, with comprehensive test coverage and artifacts.

2. **ToolLoopAgent Pattern**: The implementation uses a single ToolLoopAgent with validation loop instead of the two-agent pipeline from experiments, providing better control and clearer error handling.

3. **Documentation Accuracy**: The experiments/README.md now accurately reflects the production status, making it clear to future developers that this feature is no longer experimental.

4. **Test Artifacts**: All 3 test scenarios (pharma interview, rambling tech, short prompt) have corresponding JSON and PNG artifacts, demonstrating end-to-end functionality.

### Next Steps
- This is the final documentation task for issue-7
- All 7 tasks completed: types → profile → generator → registry → action → test → documentation
- Ready for PR review and merge
