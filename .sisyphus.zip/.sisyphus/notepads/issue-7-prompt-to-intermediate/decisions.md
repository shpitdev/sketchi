# Architectural Decisions

## Session: ses_3fcd823e4ffeR2C39Y4YnyNQvG
Started: 2026-01-28T06:16:16.195Z

---

## Task 3: getProfile Implementation Location

**Context**: Plan specified importing getProfile from './index', but this creates circular dependency (index imports generateIntermediate, generateIntermediate imports getProfile).

**Decision**: Implement getProfile() locally in intermediate-generator.ts.

**Rationale**:
- Avoids circular dependency
- Keeps generator self-contained for Task 3
- Registry (Task 4) can still provide public getProfile API
- Better module separation

**Impact**: Task 4 registry will need to export its own getProfile, which delegates to profiles. This is cleaner than circular imports.

---

