## Task 2: Add tests/e2e/artifacts/ to .gitignore

**Completed**: Added `tests/e2e/artifacts/` to `.gitignore` in the Testing section (line 48).

**Placement Strategy**: Grouped with other test-related ignore patterns (coverage, .nyc_output) for logical organization.

**Verification**:
- `grep "tests/e2e/artifacts" .gitignore` ✅ Returns: `tests/e2e/artifacts/`
- `git check-ignore tests/e2e/artifacts/test.txt` ✅ Returns: `tests/e2e/artifacts/test.txt`

**Key Learning**: Git ignore patterns work immediately after adding to .gitignore - no git cache clear needed for new patterns.

## Task 7: Reduce handleExportZip cognitive complexity

**Completed**: Refactored `handleExportZip` in `apps/web/src/components/icon-library/export-button.tsx` to reduce cognitive complexity.

**Extracted Helper Functions**:
1. `triggerBlobDownload(blob, fileName)` - Handles blob download via temporary link
2. `fetchIconSvg(icon)` - Fetches and validates SVG, returns null if invalid
3. `getUniqueFileName(baseName, usedNames)` - Handles name deduplication with counter

**Complexity Reduction Strategy**:
- Moved conditional logic (url check, response.ok, validation) into `fetchIconSvg`
- Moved while loop for name deduplication into `getUniqueFileName`
- Moved download trigger logic into `triggerBlobDownload`
- Main function now orchestrates: loop → fetch → dedupe → add to zip → download

**Verification**:
- `bun x ultracite check apps/web/src/components/icon-library/export-button.tsx` ✅ No errors
- `bun run build` ✅ Build successful

**Key Learning**: Biome's cognitive complexity counts nested conditionals, loops, and try-catch blocks. Extracting these into helper functions reduces the main function's complexity score while improving readability.

## Task 8: Bun Types Reference Resolution

**Problem:** `scripts/test-svg-conversion.ts` had undeclared `Bun` variable error from linter.

**Solution:** 
1. Added `/// <reference types="bun-types" />` as first line of script
2. Updated `packages/config/tsconfig.base.json` to include `"bun"` in types array
3. Updated `biome.jsonc` to add `"javascript": { "globals": ["Bun"] }` configuration

**Key Learning:** 
- Triple-slash directives alone don't resolve Biome linter errors
- Biome requires explicit global configuration via `javascript.globals` in biome.jsonc
- TypeScript types config and Biome config are separate concerns

**Result:** ✅ `bun x ultracite check scripts/test-svg-conversion.ts` now passes with 0 errors

## [2026-01-28T04:15:00Z] Task: lint-cleanup (COMPLETE)

### Key Learnings

**Biome Configuration**:
- Adding global variables requires both `biome.jsonc` (`javascript.globals`) AND `tsconfig` (`types` array)
- Triple-slash references (`/// <reference types="..." />`) work for script-specific type support

**Test Helper Patterns**:
- Assertions in helper functions called from `test()` blocks are valid
- Use `// biome-ignore lint/suspicious/noMisplacedAssertion: assertions in helper called from test()` to suppress false positives
- Always include reason text after colon in biome-ignore comments

**Performance Optimizations**:
- Moving regex to module scope prevents recompilation on every function call
- Use descriptive const names (e.g., `FILE_EXTENSION_REGEX`, `SVG_OPEN_TAG_REGEX`)

**Cognitive Complexity Reduction**:
- Extract validation logic into separate functions
- Extract file I/O operations into helpers
- Keep main function as orchestration flow
- Target 18 complexity (not exactly 20) for safety margin

**Framework Type Patterns**:
- Convex framework types use `any` in `Validator<any, "required", any>` - this is intentional
- Don't fight framework type patterns - skip these lint rules

### Gotchas

**Subagent Scope Creep**:
- Subagents frequently modify unrelated files (AGENTS.md, .ruler configs)
- Always verify `git status` and revert unauthorized changes
- Check actual file changes, not just subagent claims

**Parallel Delegation**:
- All 4 parallel tasks reported identical file changes (suspicious)
- Actual changes were correct, but reporting was misleading
- Always verify with own tool calls

### Metrics

- Lint errors: 74 → 10 (86% reduction)
- All remaining errors are intentionally skipped (framework types, false positives, architectural choices)
- 7 atomic commits created
- All tests passing (12/12)
- Build successful
- Zero functional changes to production code
