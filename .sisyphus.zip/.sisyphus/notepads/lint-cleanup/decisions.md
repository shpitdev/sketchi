
## [2026-01-28T04:15:00Z] Architectural Decisions

**Decision: Use biome-ignore for test helper assertions**
- Rationale: Helper function pattern is valid and readable
- Alternative considered: Restructure tests to inline assertions
- Rejected because: Would make tests more verbose and harder to maintain

**Decision: Skip framework type lint errors**
- Files: `packages/backend/convex/lib/logging.ts`
- Rationale: Convex framework requires `any` in Validator types
- Alternative considered: Create wrapper types
- Rejected because: Would break framework compatibility

**Decision: Skip barrel file warning**
- File: `packages/backend/lib/diagram-layout.ts`
- Rationale: Architectural choice for clean public API
- Alternative considered: Direct imports everywhere
- Rejected because: Would expose internal implementation details

**Decision: Skip shadcn label component warning**
- File: `apps/web/src/components/ui/label.tsx`
- Rationale: Reusable component receives `htmlFor` via props spread
- Alternative considered: Add explicit `htmlFor` prop
- Rejected because: Would break shadcn component pattern
