
## Bidirectional Arrow-Shape Binding Fix

**Date**: 2026-02-02

**Problem**: Arrows had `startBinding`/`endBinding` pointing to shapes, but shapes didn't have arrow IDs in their `boundElements` array. This broke drag behavior in Excalidraw web - arrows wouldn't follow shapes when dragged.

**Root Cause**: `buildShapeElements()` runs BEFORE `buildArrowElements()` in `convertLayoutedToExcalidraw()` - arrows don't exist when shapes are built, so shapes can't reference arrows.

**Solution**: Post-processing normalization pass via `normalizeArrowBindings()` function:

1. **Build arrow-to-shape map** (`buildArrowShapeMap()`):
   - Iterate all arrow elements
   - Extract `startBinding.elementId` and `endBinding.elementId`
   - Store in `Map<shapeId, Set<arrowId>>` (Set handles deduplication)

2. **Update shape elements** (`normalizeArrowBindings()`):
   - Iterate all shape elements (rectangle, ellipse, diamond)
   - Lookup arrow IDs from map
   - Merge arrow bindings into existing `boundElements` (preserves text bindings)

**Edge Cases Handled**:
- ✅ Self-referencing arrows: `Set` automatically deduplicates (arrow appears once)
- ✅ Multiple arrows between shapes: All arrow IDs added to `boundElements`
- ✅ Dangling arrows (missing shape): Skipped gracefully via optional chaining
- ✅ Preserve text bindings: Existing `boundElements` preserved before adding arrows

**Test Coverage**:
- `convex/excalidraw-elements.test.ts`: Unit tests for all edge cases
- `convex/diagramGenerateFromIntermediate.test.ts`: Integration test verifies end-to-end

**Files Modified**:
- `packages/backend/lib/excalidraw-elements.ts`: Added `normalizeArrowBindings()`, `buildArrowShapeMap()`, `addArrowToShape()`
- `packages/backend/convex/excalidraw-elements.test.ts`: TDD tests for normalization logic

**Key Insight**: Using `Set<string>` for arrow IDs elegantly handles both self-referencing arrows (deduplication) and multiple arrows (accumulation) without special-case logic.

