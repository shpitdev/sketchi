# Decisions

## [2026-01-28T00:28:10.725Z] Planning Phase

### Schema Mismatch Resolution
- **Decision**: Keep frontend settings (bowing, randomize, pencilFilter, showLabel, labelSize) as session-only
- **Rationale**: Persistence deferred until user authentication is implemented
- **Impact**: Add documentation, no schema changes

### Export Validation Failure Mode
- **Decision**: Skip problematic icons with warning, don't abort entire export
- **Rationale**: More resilient user experience
