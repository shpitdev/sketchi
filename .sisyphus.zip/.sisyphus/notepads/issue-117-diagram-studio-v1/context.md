# Issue 117: Diagram Studio v1 — Execution Context

## Current Repo State (as of 2026-02-10)
- Branch: `117-v1---diagram-studio-ai-diagram-generation`
- Status: No Issue #117 implementation files have been created yet.
- There are currently uncommitted changes on the branch in:
  - `.opencode/package.json`
  - `bun.lock`
  Treat these as *unrelated* until proven otherwise; avoid mixing into Issue #117 commits.

## Plan
- Active plan: `.sisyphus/plans/issue-117-diagram-studio-v1.md`
- Wave 1 targets (backend foundations):
  - `diagramSessions` table + CRUD + OCC + size guard
  - `diagrams.restructureFromScene` action + deterministic tests

## Codebase Reference Patterns (Wave 1)
- Schema + indexes style:
  - `packages/backend/convex/schema.ts` (`defineTable(...).index("by_x", ["x"])`)
- CRUD + index usage style:
  - `packages/backend/convex/iconLibraries.ts`
- Deterministic Convex tests (mock AI internals):
  - `packages/backend/convex/diagrams.test.ts` (mocks `generateIntermediate` / `modifyIntermediate`)
- Size guard patterns:
  - `packages/backend/convex/lib/excalidrawShareLinks.ts` has explicit MAX_* byte limits
  - For sessions, plan calls for `MAX_SCENE_BYTES = 900_000` (buffer below Convex 1MB doc limit)

## Excalidraw + Next.js App Router Integration Notes
- Excalidraw requires client-only rendering:
  - Use `next/dynamic` with `{ ssr: false }`.
- CSS import constraints:
  - Prefer importing `@excalidraw/excalidraw/index.css` inside a client wrapper component ("use client"), or in `apps/web/src/app/layout.tsx` if global.
  - Avoid importing global CSS from server components or nested layouts if Next.js rejects it.
- PNG export:
  - Use `exportToBlob({ elements, appState, files, mimeType: "image/png" })` in the browser.
