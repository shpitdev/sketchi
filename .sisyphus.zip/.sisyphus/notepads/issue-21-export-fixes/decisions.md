# Architectural Decisions - Issue #21 Export Fixes

## Design Choices
