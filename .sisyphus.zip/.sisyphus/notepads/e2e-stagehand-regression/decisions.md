## [2026-01-28T09:15:00Z] E2E Stagehand Regression - Decisions

### Test Approach: Hybrid LLM + Deterministic
**Decision**: Use LLM (Stagehand.act) for navigation/verification, deterministic methods for file operations.
**Rationale**: 
- Early-stage project needs flexible tests that adapt to UI changes
- File uploads require deterministic approach (LLM can't interact with file dialogs)
- Balance between maintainability and reliability

### Fixture Strategy: Copy vs Reference
**Decision**: Copy 3 Palantir icons to `tests/e2e/fixtures/svgs/` (not symlink or reference).
**Rationale**:
- Decouples tests from seed data changes
- Ensures test stability if seed icons are modified/removed
- Small duplication (3 files, <1KB total) acceptable for test isolation

### Workflow Execution: Sequential vs Parallel
**Decision**: Run scenarios sequentially (visual-sanity → happy-path).
**Rationale**:
- Fail-fast: If visual-sanity fails, no need to run happy-path
- visual-sanity checks basic functionality first
- happy-path tests full workflow after sanity check passes

### Dark Mode Investigation: Re-enable with Data Collection
**Decision**: Re-enable tests with `STAGEHAND_VISUAL_STRICT: "false"`.
**Rationale**:
- ModeToggle component has correct `data-testid="theme-toggle"`
- Test has fallback logic (localStorage if toggle unavailable)
- Issue likely timing-related (React hydration vs Stagehand speed)
- Collect data in CI before investigating further

### Package.json Scripts: Individual vs Runner
**Decision**: Add individual scripts for each scenario, not just run-scenarios.ts.
**Rationale**:
- Allows running scenarios independently during development
- Workflow can choose sequential execution or use run-scenarios.ts
- More flexible for debugging individual scenarios
