## [2026-01-28T09:15:00Z] E2E Stagehand Regression - Learnings

### Path Resolution Gotcha
**Issue**: Initial implementation used `../../../../fixtures/svgs` which resolved incorrectly.
**Fix**: Changed to `../../../fixtures/svgs` - verified by testing from test file location.
**Lesson**: Always verify relative paths with actual `ls` commands from the source file's directory.

### Stagehand File Upload Limitation
**Discovery**: Stagehand/LLM cannot interact with native OS file dialogs (browser security).
**Solution**: Use Playwright's `setInputFiles()` for deterministic file uploads.
**Pattern**: Hybrid approach - LLM for navigation/verification, deterministic methods for file operations.

### Test Infrastructure Requirements
**Local execution**: Requires `.env.e2e` with `OPENROUTER_API_KEY` (not in repo for security).
**CI execution**: Uses GitHub Secrets (OPENROUTER_API_KEY, BROWSERBASE_*, etc.).
**Dev server**: Must be running at localhost:3001 for local tests.

### Component Instrumentation
**Added**: `data-testid="svg-file-input"` to hidden file input in svg-uploader.tsx.
**Rationale**: Provides stable selector for E2E tests, avoids fragile attribute-based selectors.
**Pattern**: Follow existing pattern from mode-toggle.tsx (`data-testid="theme-toggle"`).

### Workflow Configuration
**Removed**: `exit 0` bypass that disabled tests (lines 47-50 in e2e-web.yml).
**Replaced with**: Sequential execution of both scenarios (visual-sanity → happy-path).
**Preserved**: `STAGEHAND_VISUAL_STRICT: "false"` for data collection phase.

### Fixture Management
**Location**: `tests/e2e/fixtures/svgs/` (3 Palantir icons copied, not symlinked).
**Size**: All under 256KB (upload limit in svg-uploader.tsx).
**Decoupling**: Copied from seed directory to avoid test dependency on seed data changes.
