# Issues & Gotchas - PR #90 CR Fixes

## Problems Encountered
- Backend tests timed out in `convex/diagramGenerateIntermediateFromPrompt.test.ts` (full pipeline across prompts) after 300000ms; underlying AI timeout `SKETCHI_AI_INTERMEDIATE_FAILED` despite retries.
